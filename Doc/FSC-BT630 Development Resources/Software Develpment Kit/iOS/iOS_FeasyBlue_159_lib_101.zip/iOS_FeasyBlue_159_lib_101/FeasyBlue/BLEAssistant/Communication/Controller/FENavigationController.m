//
//  FENavigationController.m
//  BLEAssistant
//
//  Created by ericj on 2018/4/9.
//  Copyright © 2018年 feasycom. All rights reserved.
//

#import "FENavigationController.h"
#import "Masonry.h"

@interface FENavigationController ()


@end

@implementation FENavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self createCustomView];
}

//设置状态栏颜色
- (void)setStatusBarBackgroundColor:(UIColor *)color {
    UIView *statusBar = [[[UIApplication sharedApplication] valueForKey:@"statusBarWindow"] valueForKey:@"statusBar"];
    if ([statusBar respondsToSelector:@selector(setBackgroundColor:)]) {
        statusBar.backgroundColor = color;
    }
}

- (void)createCustomView {
    UIView *customView = [[UIView alloc] initWithFrame:CGRectMake(0, 44, self.view.frame.size.width, 44)];
    customView.backgroundColor = [UIColor colorWithRed:249/255.0 green:249/255.0 blue:249/255.0 alpha:1];
    [self.view addSubview:customView];
    
    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.text = FELocalizedString(@"communication");
    [titleLabel setFont:[UIFont fontWithName:@"Arial-BoldItalicMT" size:17]];
    [customView addSubview:titleLabel];
    
    UIView *lineView = [[UIView alloc] init];
    lineView.backgroundColor = [UIColor lightGrayColor];
    [customView addSubview:lineView];
    
    UILabel *bleLabel = [[UILabel alloc] init];
    bleLabel.text = @"BLE";
    bleLabel.font = [UIFont systemFontOfSize:11];
    [customView addSubview:bleLabel];
    
    UILabel *mfiLabel = [[UILabel alloc] init];
    mfiLabel.text = @"MFI";
    mfiLabel.font = [UIFont systemFontOfSize:11];
    [customView addSubview:mfiLabel];
    
    UISwitch *bleSwitch = [[UISwitch alloc] init];
    bleSwitch.transform = CGAffineTransformMakeScale(0.5, 0.5);
    bleSwitch.on = YES;
    bleSwitch.tag = 100;
    [customView addSubview:bleSwitch];
    
    UISwitch *mfiSwitch = [[UISwitch alloc] init];
    mfiSwitch.transform = CGAffineTransformMakeScale(0.5, 0.5);
    mfiSwitch.tag = 101;
    [customView addSubview:mfiSwitch];
    
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.equalTo(customView);
    }];
    [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.equalTo(customView);
        make.height.mas_equalTo(1/[UIScreen mainScreen].scale);
    }];
    [bleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.bottom.equalTo(customView).offset(-8);
    }];
    [mfiLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(bleLabel);
        make.bottom.equalTo(bleLabel.mas_top).offset(-5);
    }];
    [bleSwitch mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(bleLabel.mas_left);
        make.centerY.equalTo(bleLabel);
    }];
    [mfiSwitch mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(bleSwitch);
        make.centerY.equalTo(mfiLabel);
    }];
    
    self.switch_mfi = mfiSwitch;
    self.switch_ble = bleSwitch;
    
}

- (void)clickToSearchPeripherals:(UIViewController *)vc {
    [self.switch_ble addTarget:vc action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [self.switch_mfi addTarget:vc action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)click:(UISwitch *)sender {
    if (sender.tag == 100) {
//        NSLog(@"点击ble");
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATIONBLE object:nil userInfo:@{@"ble":@(sender.on)}];
        if (sender.on) {
            if (self.switch_mfi.on) {
                self.switch_mfi.on = NO;
            }
        } else {
            if (!self.switch_mfi.on) {
                self.switch_ble.on = YES;
            }
        }
    } else {
//        NSLog(@"点击mfi");
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATIONMFI object:nil userInfo:@{@"mfi":@(sender.on)}];
        if (sender.on) {
            if (self.switch_ble.on) {
                self.switch_ble.on = NO;
            }
        } else {
            if (!self.switch_ble.on) {
                self.switch_mfi.on = YES;
            }
        }
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
