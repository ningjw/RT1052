//
//  FEDFUSelectionListTableViewController.h
//  BLEAssistant
//
//  Created by ericj on 2018/1/26.
//  Copyright © 2018年 feasycom. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FscBleCentralApi.h"
@interface FEDFUSelectionListTableViewController : UIViewController

@property (nonatomic, copy) void(^moduleBlock)(CBPeripheral *module);
@property (nonatomic, strong) NSArray *infoArray;
@property (nonatomic, assign) BOOL isChange;

@end
