//
//  FESettingModel.m
//  BLEAssistant
//
//  Created by yumingyue on 2016/12/9.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import "FESettingModel.h"
#import <AVFoundation/AVFoundation.h>

@interface FESettingModel()
@property (nonatomic, strong) NSUserDefaults *def;
//音频(本地音频)
@property (nonatomic, strong) AVAudioPlayer *playerOK;
@property (nonatomic, strong) AVAudioPlayer *playerAllarm;
@end

@implementation FESettingModel
singleton_implementation(FESettingModel)
-(id)init{
    if (self = [super init]) {
        //选择模式
        self.tag_setting_selectBtn     = [self.def integerForKey:@"tag_setting_selectBtn"];
        self.tag_setting_selectBtn      = self.tag_setting_selectBtn >=21000 && self.tag_setting_selectBtn <22000?  self.tag_setting_selectBtn:COMMUNICATIONTAG;
        //通讯
        self.comm_serviceUUID                 = [self.def valueForKey:@"comm_serviceUUID"];
        self.comm_notiUUID                      = [self.def valueForKey:@"comm_notiUUID"];
        self.comm_writeUUID                    = [self.def valueForKey:@"comm_writeUUID"];
        self.comm_isAppointServiceUUID = [self.def boolForKey:@"comm_isAppointServiceUUID"];
        self.comm_isAppointNotiUUID       = [self.def boolForKey:@"comm_isAppointNotiUUID"];
        self.comm_isAppointWriteUUID     = [self.def boolForKey:@"comm_isAppointWriteUUID"];
        //更改设备信息
        self.change_name                 = [self.def valueForKey:@"change_name"];
        self.change_pin                     = [self.def valueForKey:@"change_pin"];
        self.change_baud                  = [self.def valueForKey:@"change_baud"];
        self.change_isChangeName = [self.def boolForKey:@"change_isChangeName"];
        self.change_isChangePin     = [self.def boolForKey:@"change_isChangePin"];
        self.change_isChangeBaud  = [self.def boolForKey:@"change_isChangeBaud"];
        //固件升级
        self.dfu_selectedUrl               = [self.def URLForKey:@"dfu_selectedUrl"];
        self.dfu_selectedUrlName      = self.dfu_selectedUrl ? [[self.dfu_selectedUrl lastPathComponent] stringByDeletingPathExtension] : FELocalizedString(@"noSelectFirmware");
        self.dfu_isFactory                   = [self.def boolForKey:@"dfu_isFactory"];
        //设备过滤
        self.filter_name                       = [self.def valueForKey:@"filter_name"];
        self.filter_rssi                           = [self.def valueForKey:@"filter_rssi"];
        self.filter_serviceUUID            = [self.def valueForKey:@"filter_serviceUUID"];
        self.filter_notiUUID                  = [self.def valueForKey:@"filter_notiUUID"];
        self.filter_writeUUID                = [self.def valueForKey:@"filter_writeUUID"];
        self.filter_isFilter                      = [self.def boolForKey:@"filter_isFilter"];
        self.filter_isFilterName             = [self.def boolForKey:@"filter_isFilterName"];
        self.filter_isFilterRssi                = [self.def boolForKey:@"filter_isFilterRssi"];
        self.filter_isFilterServiceUUID  = [self.def boolForKey:@"filter_isFilterServiceUUID"];
        self.filter_isFilterNotiUUID        = [self.def boolForKey:@"filter_isFilterNotiUUID"];
        self.filter_isFilterWriteUUID      = [self.def boolForKey:@"filter_isFilterWriteUUID"];
        //其它设置
        self.other_okVoice                    = [self.def boolForKey:@"other_okVoice"];
        self.other_failVoice                 = [self.def boolForKey:@"other_failVoice"];
        
//        //1.音频文件路径
//        NSString *audioPath = [[NSBundle mainBundle] pathForResource:@"allarm" ofType:@"mp3"];
//        //2.创建对象(执行文件)
//        self.playerAllarm = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:audioPath] error:nil];
//        //1.音频文件路径
//        audioPath = [[NSBundle mainBundle] pathForResource:@"OK" ofType:@"mp3"];
//        //2.创建对象(执行文件)
//        self.playerOK = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:audioPath] error:nil];
    }
    return self;
}

-(void)okVoice{
    if (self.other_okVoice) {
        NSLog(@"成功响了");
        [self.playerOK play];
    }else{
        NSLog(@"成功no响");
    }
}

-(void)failVoice{
    if (self.other_failVoice) {
        NSLog(@"失败响了");
        [self.playerAllarm play];
    }
}

-(void)setDfu_selectedUrl:(NSURL *)dfu_selectedUrl{
    _dfu_selectedUrl = dfu_selectedUrl;
    self.dfu_selectedUrlName      = _dfu_selectedUrl ? [[_dfu_selectedUrl lastPathComponent] stringByDeletingPathExtension] : FELocalizedString(@"noSelectFirmware");
}
-(void)setTag_setting_selectBtn:(NSInteger)tag_setting_selectBtn{
    _tag_setting_selectBtn = tag_setting_selectBtn;
    switch (tag_setting_selectBtn) {
        case COMMUNICATIONTAG:
            self.selectModelName = FELocalizedString(@"communication");
            break;
        case PROPERITIESDEFININGTAG:
            self.selectModelName = FELocalizedString(@"properitiesDefining");
            break;
        case FIRMWAREUPGRADETAG:
            self.selectModelName = FELocalizedString(@"firmwareUpgrade");
            break;
        default:
            break;
    }
}
//懒加载
-(NSUserDefaults *)def{
    if (!_def) {
        _def = [NSUserDefaults standardUserDefaults];
    }
    return _def;
}

@end
