//
//  FEDFUSendDataViewController.h
//  BLEAssistant
//
//  Created by ericj on 2017/12/14.
//  Copyright © 2017年 feasycom. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FscBleCentralApi.h"

@interface FEDFUSendDataViewController : UIViewController

@property (nonatomic, assign) BOOL restore;

- (instancetype)initWithFileName:(NSString *)fileName withPeripheral:(CBPeripheral *)peripheral;

@end
