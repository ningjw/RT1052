//
//  FESettingSearchTableViewCell.m
//  BLEAssistant
//
//  Created by 余明悦 on 16/9/28.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import "FESettingSearchTableViewCell.h"
@interface FESettingSearchTableViewCell()
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *RSSILabel;
@property (weak, nonatomic) IBOutlet UILabel *changeLabel;
@property (weak, nonatomic) IBOutlet UIImageView *changeImageView;
@property (weak, nonatomic) IBOutlet UILabel *successLabel;
@property (weak, nonatomic) IBOutlet UIImageView *sucessImageView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *progressLayout;

@end
@implementation FESettingSearchTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)reflashName:(NSString *)name{
    if (name) {
        self.nameLabel.textColor = [UIColor blueColor];
        self.nameLabel.text = name;
    }else{
        self.nameLabel.textColor = [UIColor redColor];
        self.nameLabel.text = FELocalizedString(@"unname");
    }
}

- (void)reflashRSSI:(NSInteger)RSSI {
    self.RSSILabel.text = [NSString stringWithFormat:@"%ld", RSSI];
}

- (void)changeOK:(BOOL)success{
    if (success) {
        self.changeImageView.image = [UIImage imageNamed:@"button OK"];
        [self.changeLabel setTextColor:[UIColor blackColor]];
        self.changeLabel.text = FELocalizedString(@"ok");
    }else{
        self.changeImageView.image = [UIImage imageNamed:@"button Faile"];
        [self.changeLabel setTextColor:[UIColor whiteColor]];
        self.changeLabel.text = FELocalizedString(@"fail");
    }
}

-(void)clear{
    self.nameBeforeLabel.text = @"";
    self.pinBeforeLabel.text = @"";
    self.baudBeforeLabel.text = @"";
    self.nameAfterLabel.text = @"";
    self.pinAfterLabel.text = @"";
    self.baudAfterLabel.text = @"";
    [self.changeLabel setTextColor:[UIColor whiteColor]];
    self.changeImageView.image = [UIImage imageNamed:@"button"];
    self.changeLabel.text = FELocalizedString(@"select");
}

-(void)successed:(BOOL)success{
    self.successLabel.hidden = !success;
    self.sucessImageView.hidden = !success;
}

-(void)progressPersend:(NSInteger)persend{
    CGFloat end = self.frame.size.width * 0.01 * persend;
    self.progressLayout.constant = end;
}
@end
