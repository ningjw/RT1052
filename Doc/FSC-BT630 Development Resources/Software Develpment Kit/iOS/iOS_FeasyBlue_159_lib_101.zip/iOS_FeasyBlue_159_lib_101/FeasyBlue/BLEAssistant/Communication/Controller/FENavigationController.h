//
//  FENavigationController.h
//  BLEAssistant
//
//  Created by ericj on 2018/4/9.
//  Copyright © 2018年 feasycom. All rights reserved.
//

#import <UIKit/UIKit.h>

#define NOTIFICATIONBLE     @"notificationBle"
#define NOTIFICATIONMFI     @"notificationMfi"

@interface FENavigationController : UIViewController

@property (nonatomic, weak) UISwitch *switch_mfi;

@property (nonatomic, weak) UISwitch *switch_ble;

- (void)setStatusBarBackgroundColor:(UIColor *)color;
- (void)clickToSearchPeripherals:(UIViewController *)vc;

@end
