//
//  FEFilterRSSITableViewCell.m
//  BLEAssistant
//
//  Created by ericj on 2018/6/5.
//  Copyright © 2018年 feasycom. All rights reserved.
//

#import "FEFilterRSSITableViewCell.h"

@implementation FEFilterRSSITableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
//    NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
//    BOOL en;
//    if (self.type == COMMUNICATION) {
//        en = [user boolForKey:@"enable"];
//    } else if (self.type == PARAMETER) {
//        en = [user boolForKey:@"enable_parameter"];
//    } else {
//        en = [user boolForKey:@"enable_update"];
//    }
//    self.filterEnableSwitch.on = en;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
