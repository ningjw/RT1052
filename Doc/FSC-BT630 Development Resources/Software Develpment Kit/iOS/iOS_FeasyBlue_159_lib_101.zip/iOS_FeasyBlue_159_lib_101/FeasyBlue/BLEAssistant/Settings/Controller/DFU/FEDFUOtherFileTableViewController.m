//
//  FEDFUOtherFileTableViewController.m
//  BLEAssistant
//
//  Created by yumingyue on 2016/11/22.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import "FEDFUOtherFileTableViewController.h"
#import "FEDFUSendDataViewController.h"
#import "FEDFUUpdateDetailViewController.h"
#import "ServiceInfo.h"

@interface FEDFUOtherFileTableViewController ()
@property (nonatomic, strong) NSMutableArray<NSURL*> *allUrls;
@property (nonatomic, strong) NSMutableArray<NSString*>*allFileNames;
@property (nonatomic, strong) NSFileManager *manager;
@property (nonatomic, strong) NSString *fileBassPath;
@end

@implementation FEDFUOtherFileTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.allUrls = [NSMutableArray array];
    self.manager = [NSFileManager defaultManager];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.allFileNames.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"dfu_fileNameCell"];
    if(cell ==nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"dfu_fileNameCell"];
    }
    cell.textLabel.numberOfLines = 0;
    cell.textLabel.font = [UIFont systemFontOfSize:14];
    cell.textLabel.text = self.allFileNames[indexPath.row];
    cell.backgroundColor = [UIColor whiteColor];
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATIONFILENAME object:nil userInfo:@{@"fileName":self.allFileNames[indexPath.row]}];
    for (UINavigationController *vc in self.navigationController.childViewControllers) {
        if ([vc isKindOfClass:[FEDFUUpdateDetailViewController class]]) {
            [self.navigationController popToViewController:vc animated:YES];
        }
    }
}

// 自定义行高
-(CGFloat)tableView:(UITableView*)tableView heightForRowAtIndexPath:(NSIndexPath*)indexPath{
    return 60;
}

// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}



// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        //删除文件
        NSError *error;
        [self.manager removeItemAtURL:self.allUrls[indexPath.row] error:&error];
        if (!error) {
            [self.allFileNames removeObjectAtIndex:indexPath.row];
            [self.allUrls removeObjectAtIndex:indexPath.row];
            [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
        }
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}

-(void)dealloc{
    NSLog(@"销毁FEDFUOtherFileTableViewController");
}
@end
