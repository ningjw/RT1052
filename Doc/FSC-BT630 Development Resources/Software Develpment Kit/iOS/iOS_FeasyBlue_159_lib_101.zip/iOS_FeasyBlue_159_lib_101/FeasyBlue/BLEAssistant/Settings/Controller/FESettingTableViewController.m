//
//  FESettingTableViewController.m
//  BLEAssistant
//
//  Created by yumingyue on 2016/12/5.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import "FESettingTableViewController.h"
#import "FEDFUOtherFileTableViewController.h"
#import "FEDFUUpdateDetailViewController.h"
#import "FEDFUSelectionListTableViewController.h"
#import "FEChangeATCommandsViewController.h"

//每区行数
#define ROW_PROPERITIESDESFINING     14
#define ROW_UPDATE                   3
#define ROW_FILTER                   6
#define ROW_OTHERSETTING             1

//每个区
typedef NS_ENUM(NSInteger, Section) {
    ProperitiesDefining = 0,
    Update,
    Filter,
    OtherSetting
};

@interface FESettingTableViewController ()<FEDFUOtherFileTableViewControllerDelegate>
//每区行数
@property (nonatomic) NSInteger row_communication;
@property (nonatomic) NSInteger row_properitiesDefining;
@property (nonatomic) NSInteger row_update;
@property (nonatomic) NSInteger row_filter;
@property (nonatomic) NSInteger row_otherSetting;

@property (nonatomic, strong) NSUserDefaults *def;
@property (nonatomic, strong) NSMutableArray *infoArrayM;

@end

@implementation FESettingTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    self.settingModel = [FESettingModel sharedFESettingModel];
    self.infoArrayM = [NSMutableArray array];
    self.navigationItem.backBarButtonItem.title = FELocalizedString(@"goBack");
    //初始化每区行数
    [self initRowCount];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.barStyle = UIStatusBarStyleLightContent;
}

-(void)viewDidAppear:(BOOL)animated{
    //初始化数据
    [self initData];
}

-(void)initRowCount{
    self.row_properitiesDefining = 1;
    self.row_update = 1;
}

-(void)initData{
    //选择模式
    UIButton *selectedBtn = [self.view viewWithTag:self.settingModel.tag_setting_selectBtn];
    selectedBtn.selected = YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    switch (section) {
        case ProperitiesDefining:
            return self.row_properitiesDefining;
        case Update:
            return self.row_update;
        default:
            break;
    }
    return 0;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    [cell setSelected:NO animated:YES];
    if (0 == indexPath.row) {
        switch (indexPath.section) {
            case ProperitiesDefining:{
                UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"FEChangeATCommandsViewController" bundle:nil];
                FEChangeATCommandsViewController *vc = [storyboard instantiateViewControllerWithIdentifier:@"sto_ATCommandsTV"];
                vc.hidesBottomBarWhenPushed = YES;
                [self.navigationController pushViewController:vc animated:YES];
            }
                break;
            case Update:{
                FEDFUUpdateDetailViewController *vc = [[FEDFUUpdateDetailViewController alloc] init];
                vc.hidesBottomBarWhenPushed = YES;
                [self.navigationController pushViewController:vc animated:YES];
            }
                break;
                
            default:
                break;
        }
    }
}

//改变行数
-(void)changRowsAtSection:(NSInteger)section withRows:(NSInteger)rows byMaxRows:(NSInteger)maxRows{
    NSMutableArray *rowsIndex = [NSMutableArray array];
    for (int i=1; i<maxRows; i++) {
        NSIndexPath*newIndexPath = [NSIndexPath indexPathForRow:i inSection:section];
        [rowsIndex addObject:newIndexPath];
    }
    if (1 == rows) {
        [self.tableView deleteRowsAtIndexPaths:rowsIndex withRowAnimation:UITableViewRowAnimationTop];
    }else{
        [self.tableView insertRowsAtIndexPaths:rowsIndex withRowAnimation:UITableViewRowAnimationTop];
    }
}

#pragma FEDFUOtherFileTableViewControllerDelegate
-(void)selectFirmwareUrl:(NSURL *)url{
    [self.def setURL:url forKey:@"dfu_selectedUrl"];
}

#pragma 懒加载
-(NSUserDefaults *)def{
    if (!_def) {
        _def = [NSUserDefaults standardUserDefaults];
    }
    return _def;
}
@end
