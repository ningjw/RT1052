//
//  FELocalizable.h
//  BLEAssistant
//
//  Created by 余明悦 on 16/9/17.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FELocalizable : NSObject
//获取当前资源文件
+(NSBundle *)bundle;
//初始化语言文件
+(void)initUserLanguage;
//获取应用当前语言
+(NSString *)userLanguage;
//设置当前语言
+(void)setUserlanguage:(NSString *)language;
@end
