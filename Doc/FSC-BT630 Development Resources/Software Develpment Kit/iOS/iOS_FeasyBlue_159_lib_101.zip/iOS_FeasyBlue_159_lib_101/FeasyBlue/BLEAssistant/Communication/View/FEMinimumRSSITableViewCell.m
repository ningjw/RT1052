//
//  FEMinimumRSSITableViewCell.m
//  BLEAssistant
//
//  Created by ericj on 2018/6/5.
//  Copyright © 2018年 feasycom. All rights reserved.
//

#import "FEMinimumRSSITableViewCell.h"

@implementation FEMinimumRSSITableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.minimumRSSISlider.minimumValue = -100;
    self.minimumRSSISlider.maximumValue = -30;
    NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
    float f = [user floatForKey:@"minimumRSSI"];
    if ([user valueForKey:@"minimumRSSI"]) {
        self.minimumRSSILabel.text = [NSString stringWithFormat:@"%.f dB",f];
        self.minimumRSSISlider.value = f;
    } else {
        self.minimumRSSILabel.text = @"-50 dB";
        self.minimumRSSISlider.value = -50;
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
