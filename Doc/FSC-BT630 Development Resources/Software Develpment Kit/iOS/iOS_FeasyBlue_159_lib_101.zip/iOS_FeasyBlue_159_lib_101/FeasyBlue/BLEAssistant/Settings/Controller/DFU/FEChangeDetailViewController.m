//
//  FEChangeDetailViewController.m
//  BLEAssistant
//
//  Created by ericj on 2018/2/8.
//  Copyright © 2018年 feasycom. All rights reserved.
//

#define NAVIGATIONHEIGHT 64
#define IPHONEXNAVIGATIONHEIGHT 88
#define IsiPhoneX ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1125, 2436), [[UIScreen mainScreen] currentMode].size) : NO)

#import "FEChangeDetailViewController.h"
#import "FscBleCentralApi.h"
#import "MemoryInfo.h"
#import "NSString+FscKit.h"
#import "Masonry.h"
#import "ServiceInfo.h"

@interface FEChangeDetailViewController ()

@property (nonatomic, strong) FscBleCentralApi *api;
@property (nonatomic, assign) NSInteger index;
@property (nonatomic, strong) MemoryInfo *memoryInfo;
@property (nonatomic, strong) NSMutableArray *labelArrM;
@property (nonatomic, assign) BOOL modifyComplete;
@property (nonatomic, assign) BOOL changeColor;

@end

@implementation FEChangeDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.index = 0;
    self.modifyComplete = NO;
    self.changeColor = NO;
    self.api = [FscBleCentralApi defaultFscBleCentralApi];
    self.api.moduleType = BLEMODULE;
    self.memoryInfo = [MemoryInfo shareMemoryInfo];
    self.labelArrM = [NSMutableArray array];
    [self setDelegate];
    [self setupUI];
    [self sendATCommands];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = NO;
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATIONRELODATA object:nil userInfo:nil];
}

// 设置代理
- (void)setDelegate {
    __weak typeof(self) weakself = self;
    // 参数修改回调函数
    [self.api fscAtResponse:^(NSString *type, int status) {
        NSLog(@"type = %@",type);
        NSLog(@"status = %d",status);
        [weakself reflashView:type withStatus:status];
        weakself.index++;
    }];
    
    [self.api blePeripheralDisonnected:^(CBCentralManager *central, CBPeripheral *peripheral, NSError *error) {
        if (weakself.modifyComplete) {
            [[NSNotificationCenter defaultCenter] postNotificationName:@"notifycationModify" object:nil];
        }
        UILabel *label = [weakself createLabelWithText:[NSString stringWithFormat:@"[%@] %@",[NSString getNowTimeTimestamp],@"连接断开"] withFontOfSize:14];
        [weakself.view addSubview:label];
//        if (weakself.labelArrM.count == 0) {
//            [label mas_makeConstraints:^(MASConstraintMaker *make) {
//                make.left.equalTo(weakself.view).offset(8);
//                make.top.equalTo(weakself.view).offset(8+8+30+(IsiPhoneX?IPHONEXNAVIGATIONHEIGHT:NAVIGATIONHEIGHT));
//                make.right.equalTo(weakself.view).offset(-8);
//            }];
//        } else {
            [label mas_makeConstraints:^(MASConstraintMaker *make) {
                make.left.equalTo(weakself.labelArrM.lastObject);
                make.top.equalTo([weakself.labelArrM.lastObject mas_bottom]).offset(8);
                make.right.equalTo(weakself.labelArrM.lastObject);
            }];
//        }
        weakself.index++;
        if (weakself.changeColor) {
            for (UILabel *label in weakself.view.subviews) {
                label.textColor = [UIColor greenColor];
            }
            weakself.changeColor = NO;
            NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:2 target:weakself selector:@selector(comeback) userInfo:nil repeats:NO];
        } else {
            for (UILabel *label in weakself.view.subviews) {
                label.textColor = [UIColor redColor];
            }
        }
    }];
    
}

- (void)comeback {
    [self.navigationController popViewControllerAnimated:YES];
}

// 参数修改
- (void)sendATCommands {
    // 发送参数修改的命令
    [self.api sendFscAtCommands:self.commandsArray];
}

- (void)reflashView:(NSString *)string withStatus:(int)status {
    NSString *str = @"";
    if (status == 0) {
        str = FELocalizedString(@"modifiedCompleted");
        self.changeColor = YES;
        self.modifyComplete = YES;
    } else if (status == 1) {
        str = FELocalizedString(@"modifiedFailed");
    } else {
        str = @"";
    }
    NSString *text = [NSString stringWithFormat:@"[%@] %@%@",[NSString getNowTimeTimestamp],string,str];
    [self.memoryInfo.commandArray_record addObject:text];
    UILabel *label = [self createLabelWithText:text withFontOfSize:14];
    [self.view addSubview:label];
    [self.labelArrM addObject:label];
    [self layoutSubviews];
}

- (void)setupUI {
    NSLog(@"%@",[NSString getNowTimeTimestamp]);
    self.view.backgroundColor = [UIColor whiteColor];
    UILabel *nameLabel = [self createLabelWithText:[NSString stringWithFormat:@"设备名 %@",self.name] withFontOfSize:14];
    [self.view addSubview:nameLabel];
    [self.labelArrM addObject:nameLabel];
}

- (void)layoutSubviews {
    for (int i = 0; i < self.labelArrM.count; i++) {
        if (i == 0) {
            [self.labelArrM[i] mas_makeConstraints:^(MASConstraintMaker *make) {
                make.left.equalTo(self.view).offset(8);
                make.top.equalTo(self.view).offset(8+(IsiPhoneX?IPHONEXNAVIGATIONHEIGHT:NAVIGATIONHEIGHT));
                make.right.equalTo(self.view).offset(-8);
            }];
        } else {
            [self.labelArrM[i] mas_makeConstraints:^(MASConstraintMaker *make) {
                make.left.equalTo(self.labelArrM[i-1]);
                make.top.equalTo([self.labelArrM[i-1] mas_bottom]).offset(8);
                make.right.equalTo(self.labelArrM[i-1]);
            }];
        }
    }
    
}

- (UILabel *)createLabelWithText:(NSString *)text withFontOfSize:(CGFloat)size {
    UILabel *label = [[UILabel alloc] init];
    label.text = text;
    label.font = [UIFont systemFontOfSize:size];
    label.numberOfLines = 0;
    return label;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [self.api disconnect];
    NSLog(@"销毁控制器");
}

@end
