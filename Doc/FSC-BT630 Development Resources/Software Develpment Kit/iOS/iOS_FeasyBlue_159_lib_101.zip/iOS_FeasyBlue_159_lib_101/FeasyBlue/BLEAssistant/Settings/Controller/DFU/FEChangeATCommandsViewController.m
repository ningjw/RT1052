//
//  FEChangeATCommandsViewController.m
//  BLEAssistant
//
//  Created by ericj on 2018/2/9.
//  Copyright © 2018年 feasycom. All rights reserved.
//

#import "FEChangeATCommandsViewController.h"
#import "FEDFUSelectionListTableViewController.h"

@interface FEChangeATCommandsViewController ()<UITextFieldDelegate>
//更改设备信息
@property (weak, nonatomic) IBOutlet UITextField *changeNameTF;
@property (weak, nonatomic) IBOutlet UITextField *changePinTF;
@property (weak, nonatomic) IBOutlet UITextField *changeBaudTF;
@property (weak, nonatomic) IBOutlet UISwitch *changeNameSwitch;
@property (weak, nonatomic) IBOutlet UISwitch *changePinSwitch;
@property (weak, nonatomic) IBOutlet UISwitch *changeBaudSwitch;
@property (weak, nonatomic) IBOutlet UITextField *changeTextField_1_1;
@property (weak, nonatomic) IBOutlet UITextField *changeTextField_1_2;
@property (weak, nonatomic) IBOutlet UITextField *changeTextField_2_1;
@property (weak, nonatomic) IBOutlet UITextField *changeTextField_2_2;
@property (weak, nonatomic) IBOutlet UITextField *changeTextField_3_1;
@property (weak, nonatomic) IBOutlet UITextField *changeTextField_3_2;
@property (weak, nonatomic) IBOutlet UITextField *changeTextField_4_1;
@property (weak, nonatomic) IBOutlet UITextField *changeTextField_4_2;
@property (weak, nonatomic) IBOutlet UITextField *changeTextField_5_1;
@property (weak, nonatomic) IBOutlet UITextField *changeTextField_5_2;
@property (weak, nonatomic) IBOutlet UITextField *changeTextField_6_1;
@property (weak, nonatomic) IBOutlet UITextField *changeTextField_6_2;
@property (weak, nonatomic) IBOutlet UITextField *changeTextField_7_1;
@property (weak, nonatomic) IBOutlet UITextField *changeTextField_7_2;
@property (weak, nonatomic) IBOutlet UITextField *changeTextField_8_1;
@property (weak, nonatomic) IBOutlet UITextField *changeTextField_8_2;
@property (weak, nonatomic) IBOutlet UITextField *changeTextField_9_1;
@property (weak, nonatomic) IBOutlet UITextField *changeTextField_9_2;
@property (weak, nonatomic) IBOutlet UISwitch *changeSwitch_1;
@property (weak, nonatomic) IBOutlet UISwitch *changeSwitch_2;
@property (weak, nonatomic) IBOutlet UISwitch *changeSwitch_3;
@property (weak, nonatomic) IBOutlet UISwitch *changeSwitch_4;
@property (weak, nonatomic) IBOutlet UISwitch *changeSwitch_5;
@property (weak, nonatomic) IBOutlet UISwitch *changeSwitch_6;
@property (weak, nonatomic) IBOutlet UISwitch *changeSwitch_7;
@property (weak, nonatomic) IBOutlet UISwitch *changeSwitch_8;
@property (weak, nonatomic) IBOutlet UISwitch *changeSwitch_9;

@property (nonatomic, strong) NSMutableArray *infoArrayM;
@property (nonatomic, strong) NSUserDefaults *def;

@end

@implementation FEChangeATCommandsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.infoArrayM = [NSMutableArray array];
    self.def = [NSUserDefaults standardUserDefaults];
    self.navigationItem.title = FELocalizedString(@"parametricModify");
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:FELocalizedString(@"back") style:UIBarButtonItemStylePlain target:nil action:nil];
    
    UIButton * btn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 40, 20)];
    [btn setTitle:FELocalizedString(@"start") forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateHighlighted];
    btn.titleLabel.font = [UIFont systemFontOfSize:17];
//    [btn setTitleColor:[UIColor colorWithRed:21/255.0 green:126/255.0 blue:251/255.0 alpha:1] forState:UIControlStateNormal];
//    [btn setTitleColor:[UIColor colorWithRed:210/255.0 green:230/255.0 blue:245/255.0 alpha:1] forState:UIControlStateHighlighted];
    [btn addTarget:self action:@selector(clickSelectBtn:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem * button = [[UIBarButtonItem alloc] initWithCustomView:btn];
    self.navigationItem.rightBarButtonItem = button;
    
    [self setupUI];
}

- (void)setupUI {
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    //赋值
    self.changeNameTF.text = [self.def valueForKey:@"change_name"];
    self.changePinTF.text = [self.def valueForKey:@"change_pin"];
    self.changeBaudTF.text = [self.def valueForKey:@"change_baud"];
    self.changeTextField_1_1.text = [self.def valueForKey:@"changeTextField_1_1"];
    self.changeTextField_1_2.text = [self.def valueForKey:@"changeTextField_1_2"];
    self.changeTextField_2_1.text = [self.def valueForKey:@"changeTextField_2_1"];
    self.changeTextField_2_2.text = [self.def valueForKey:@"changeTextField_2_2"];
    self.changeTextField_3_1.text = [self.def valueForKey:@"changeTextField_3_1"];
    self.changeTextField_3_2.text = [self.def valueForKey:@"changeTextField_3_2"];
    self.changeTextField_4_1.text = [self.def valueForKey:@"changeTextField_4_1"];
    self.changeTextField_4_2.text = [self.def valueForKey:@"changeTextField_4_2"];
    self.changeTextField_5_1.text = [self.def valueForKey:@"changeTextField_5_1"];
    self.changeTextField_5_2.text = [self.def valueForKey:@"changeTextField_5_2"];
    self.changeTextField_6_1.text = [self.def valueForKey:@"changeTextField_6_1"];
    self.changeTextField_6_2.text = [self.def valueForKey:@"changeTextField_6_2"];
    self.changeTextField_7_1.text = [self.def valueForKey:@"changeTextField_7_1"];
    self.changeTextField_7_2.text = [self.def valueForKey:@"changeTextField_7_2"];
    self.changeTextField_8_1.text = [self.def valueForKey:@"changeTextField_8_1"];
    self.changeTextField_8_2.text = [self.def valueForKey:@"changeTextField_8_2"];
    self.changeTextField_9_1.text = [self.def valueForKey:@"changeTextField_9_1"];
    self.changeTextField_9_2.text = [self.def valueForKey:@"changeTextField_9_2"];
    self.changeNameSwitch.on = [self.def boolForKey:@"changeNameSwitch"];
    self.changePinSwitch.on = [self.def boolForKey:@"changePinSwitch"];
    self.changeBaudSwitch.on = [self.def boolForKey:@"changeBaudSwitch"];
    self.changeSwitch_1.on = [self.def boolForKey:@"changeSwitch_1"];
    self.changeSwitch_2.on = [self.def boolForKey:@"changeSwitch_2"];
    self.changeSwitch_3.on = [self.def boolForKey:@"changeSwitch_3"];
    self.changeSwitch_4.on = [self.def boolForKey:@"changeSwitch_4"];
    self.changeSwitch_5.on = [self.def boolForKey:@"changeSwitch_5"];
    self.changeSwitch_6.on = [self.def boolForKey:@"changeSwitch_6"];
    self.changeSwitch_7.on = [self.def boolForKey:@"changeSwitch_7"];
    self.changeSwitch_8.on = [self.def boolForKey:@"changeSwitch_8"];
    self.changeSwitch_9.on = [self.def boolForKey:@"changeSwitch_9"];
}

#pragma 控件事件
//修改
- (void)clickSelectBtn:(UIButton *)sender {
    [self.infoArrayM removeAllObjects];
    if (self.changeNameSwitch.on) {
        NSString *name = [NSString stringWithFormat:@"AT+NAME=%@",self.changeNameTF.text];
        [self.infoArrayM addObject:name];
    }
    if (self.changePinSwitch.on) {
        NSString *pin = [NSString stringWithFormat:@"AT+PIN=%@",self.changePinTF.text];
        [self.infoArrayM addObject:pin];
    }
    if (self.changeBaudSwitch.on) {
        NSString *baud = [NSString stringWithFormat:@"AT+BAUD=%@",self.changeBaudTF.text];
        [self.infoArrayM addObject:baud];
    }
    if (self.changeSwitch_1.on) {
        NSString *str1 = [NSString stringWithFormat:@"AT+%@=%@",self.changeTextField_1_1.text,self.changeTextField_1_2.text];
        [self.infoArrayM addObject:str1];
    }
    if (self.changeSwitch_2.on) {
        NSString *str2 = [NSString stringWithFormat:@"AT+%@=%@",self.changeTextField_2_1.text,self.changeTextField_2_2.text];
        [self.infoArrayM addObject:str2];
    }
    if (self.changeSwitch_3.on) {
        NSString *str3 = [NSString stringWithFormat:@"AT+%@=%@",self.changeTextField_3_1.text,self.changeTextField_3_2.text];
        [self.infoArrayM addObject:str3];
    }
    if (self.changeSwitch_4.on) {
        NSString *str4 = [NSString stringWithFormat:@"AT+%@=%@",self.changeTextField_4_1.text,self.changeTextField_4_2.text];
        [self.infoArrayM addObject:str4];
    }
    if (self.changeSwitch_5.on) {
        NSString *str5 = [NSString stringWithFormat:@"AT+%@=%@",self.changeTextField_5_1.text,self.changeTextField_5_2.text];
        [self.infoArrayM addObject:str5];
    }
    if (self.changeSwitch_6.on) {
        NSString *str6 = [NSString stringWithFormat:@"AT+%@=%@",self.changeTextField_6_1.text,self.changeTextField_6_2.text];
        [self.infoArrayM addObject:str6];
    }
    if (self.changeSwitch_7.on) {
        NSString *str7 = [NSString stringWithFormat:@"AT+%@=%@",self.changeTextField_7_1.text,self.changeTextField_7_2.text];
        [self.infoArrayM addObject:str7];
    }
    if (self.changeSwitch_8.on) {
        NSString *str8 = [NSString stringWithFormat:@"AT+%@=%@",self.changeTextField_8_1.text,self.changeTextField_8_2.text];
        [self.infoArrayM addObject:str8];
    }
    if (self.changeSwitch_9.on) {
        NSString *str9 = [NSString stringWithFormat:@"AT+%@=%@",self.changeTextField_9_1.text,self.changeTextField_9_2.text];
        [self.infoArrayM addObject:str9];
    }
    
    //保存
    [self.def setValue:self.changeNameTF.text forKey:@"change_name"];
    [self.def setValue:self.changePinTF.text forKey:@"change_pin"];
    [self.def setValue:self.changeBaudTF.text forKey:@"change_baud"];
    [self.def setValue:self.changeTextField_1_1.text forKey:@"changeTextField_1_1"];
    [self.def setValue:self.changeTextField_1_2.text forKey:@"changeTextField_1_2"];
    [self.def setValue:self.changeTextField_2_1.text forKey:@"changeTextField_2_1"];
    [self.def setValue:self.changeTextField_2_2.text forKey:@"changeTextField_2_2"];
    [self.def setValue:self.changeTextField_3_1.text forKey:@"changeTextField_3_1"];
    [self.def setValue:self.changeTextField_3_2.text forKey:@"changeTextField_3_2"];
    [self.def setValue:self.changeTextField_4_1.text forKey:@"changeTextField_4_1"];
    [self.def setValue:self.changeTextField_4_2.text forKey:@"changeTextField_4_2"];
    [self.def setValue:self.changeTextField_5_1.text forKey:@"changeTextField_5_1"];
    [self.def setValue:self.changeTextField_5_2.text forKey:@"changeTextField_5_2"];
    [self.def setValue:self.changeTextField_6_1.text forKey:@"changeTextField_6_1"];
    [self.def setValue:self.changeTextField_6_2.text forKey:@"changeTextField_6_2"];
    [self.def setValue:self.changeTextField_7_1.text forKey:@"changeTextField_7_1"];
    [self.def setValue:self.changeTextField_7_2.text forKey:@"changeTextField_7_2"];
    [self.def setValue:self.changeTextField_8_1.text forKey:@"changeTextField_8_1"];
    [self.def setValue:self.changeTextField_8_2.text forKey:@"changeTextField_8_2"];
    [self.def setValue:self.changeTextField_9_1.text forKey:@"changeTextField_9_1"];
    [self.def setValue:self.changeTextField_9_2.text forKey:@"changeTextField_9_2"];
    [self.def setBool:self.changeNameSwitch.on forKey:@"changeNameSwitch"];
    [self.def setBool:self.changePinSwitch.on forKey:@"changePinSwitch"];
    [self.def setBool:self.changeBaudSwitch.on forKey:@"changeBaudSwitch"];
    [self.def setBool:self.changeSwitch_1.on forKey:@"changeSwitch_1"];
    [self.def setBool:self.changeSwitch_2.on forKey:@"changeSwitch_2"];
    [self.def setBool:self.changeSwitch_3.on forKey:@"changeSwitch_3"];
    [self.def setBool:self.changeSwitch_4.on forKey:@"changeSwitch_4"];
    [self.def setBool:self.changeSwitch_5.on forKey:@"changeSwitch_5"];
    [self.def setBool:self.changeSwitch_6.on forKey:@"changeSwitch_6"];
    [self.def setBool:self.changeSwitch_7.on forKey:@"changeSwitch_7"];
    [self.def setBool:self.changeSwitch_8.on forKey:@"changeSwitch_8"];
    [self.def setBool:self.changeSwitch_9.on forKey:@"changeSwitch_9"];
    
    FEDFUSelectionListTableViewController *vc = [[FEDFUSelectionListTableViewController alloc] init];
    vc.isChange = YES;
    vc.infoArray = self.infoArrayM.copy;
    [self.navigationController pushViewController:vc animated:YES];
}

//修改设备信息
- (IBAction)changeNameTF:(UITextField *)sender {
    //    self.settingModel.change_name = sender.text;
    //    [self.def setValue:sender.text forKey:@"change_name"];
    //    if (self.changeNameTF.text.length == 0) {
    //        self.changeNameSwitch.on = NO;
    //    }
}
- (IBAction)changePinTF:(UITextField *)sender {
    //    self.settingModel.change_pin = sender.text;
    //    [self.def setValue:sender.text forKey:@"change_pin"];
    //    if (self.changePinTF.text.length == 0) {
    //        self.changePinSwitch.on = NO;
    //    }
}
- (IBAction)changeBaudTF:(UITextField *)sender {
    //    self.settingModel.change_baud = sender.text;
    //    [self.def setValue:sender.text forKey:@"change_baud"];
    //    if (self.changeBaudTF.text.length == 0) {
    //        self.changeBaudSwitch.on = NO;
    //    }
}
- (IBAction)changNameSwitch:(UISwitch *)sender {
    if (self.changeNameTF.text.length == 0) {
        self.changeNameSwitch.on = NO;
    }
}
- (IBAction)changePinSwitch:(UISwitch *)sender {
    if (self.changePinTF.text.length == 0) {
        self.changePinSwitch.on = NO;
    }
}
- (IBAction)changeBaudSwitch:(UISwitch *)sender {
    if (self.changeBaudTF.text.length == 0) {
        self.changeBaudSwitch.on = NO;
    }
}
- (IBAction)changeSwitch_1:(UISwitch *)sender {
    if (self.changeTextField_1_1.text.length == 0 || self.changeTextField_1_2.text.length == 0) {
        self.changeSwitch_1.on = NO;
    }
}
- (IBAction)changeSwitch_2:(UISwitch *)sender {
    if (self.changeTextField_2_1.text.length == 0 || self.changeTextField_2_2.text.length == 0) {
        self.changeSwitch_2.on = NO;
    }
}
- (IBAction)changeSwitch_3:(UISwitch *)sender {
    if (self.changeTextField_3_1.text.length == 0 || self.changeTextField_3_2.text.length == 0) {
        self.changeSwitch_3.on = NO;
    }
}
- (IBAction)changeSwitch_4:(UISwitch *)sender {
    if (self.changeTextField_4_1.text.length == 0 || self.changeTextField_4_2.text.length == 0) {
        self.changeSwitch_4.on = NO;
    }
}
- (IBAction)changeSwitch_5:(UISwitch *)sender {
    if (self.changeTextField_5_1.text.length == 0 || self.changeTextField_5_2.text.length == 0) {
        self.changeSwitch_5.on = NO;
    }
}
- (IBAction)changeSwitch_6:(UISwitch *)sender {
    if (self.changeTextField_6_1.text.length == 0 || self.changeTextField_6_2.text.length == 0) {
        self.changeSwitch_6.on = NO;
    }
}
- (IBAction)changeSwitch_7:(UISwitch *)sender {
    if (self.changeTextField_7_1.text.length == 0 || self.changeTextField_7_2.text.length == 0) {
        self.changeSwitch_7.on = NO;
    }
}
- (IBAction)changeSwitch_8:(UISwitch *)sender {
    if (self.changeTextField_8_1.text.length == 0 || self.changeTextField_8_2.text.length == 0) {
        self.changeSwitch_8.on = NO;
    }
}
- (IBAction)changeSwitch_9:(UISwitch *)sender {
    if (self.changeTextField_9_1.text.length == 0 || self.changeTextField_9_2.text.length == 0) {
        self.changeSwitch_9.on = NO;
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
//    if (indexPath.row == 4) {
        [self.view endEditing:YES];
//    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
