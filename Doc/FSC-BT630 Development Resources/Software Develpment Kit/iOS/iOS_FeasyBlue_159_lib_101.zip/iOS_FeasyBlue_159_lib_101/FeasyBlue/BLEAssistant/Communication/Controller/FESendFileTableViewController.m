//
//  FESendFileTableViewController.m
//  BLEAssistant
//
//  Created by yumingyue on 2016/11/20.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import "FESendFileTableViewController.h"
#import "MemoryInfo.h"
#import "NSData+FscKit.h"

#define BTN1  1000*10
#define BTN2  1000*50
#define BTN3  1000*100
#define BTN4  1000*200
#define BTN5  1000*500
#define BTN6  1000*1000
#define BTN7  1000*1000*2
#define BTN8  1000*1000*5
#define BTN9  1000*1000*10
#define BTN10 1000*1000*20

@interface FESendFileTableViewController ()<UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITextField *byteCountTF;
@property (weak, nonatomic) IBOutlet UISegmentedControl *byteTypeSC;
//@property (nonatomic, strong) NSData *srcData;
@property (nonatomic, strong) NSData *data;
//@property (nonatomic, strong) MemoryInfo *memoryInfo;
@end

@implementation FESendFileTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = FELocalizedString(@"sendFile");
    
}

- (void)loadData:(NSUInteger)length {
#if 0
    unsigned char buffer[102400] = { 0 };
    unsigned int buffer_size = sizeof(buffer)/sizeof(buffer[0]);
    NSMutableData *data_m = [NSMutableData data];
    NSInteger count = (length % buffer_size == 0) ? (length / buffer_size) : (length / buffer_size + 1);
    unsigned int index = 0;
    for (int i = 0; i < count; i++) {
        index = generateTestFileData(index,buffer,buffer_size);
        if ([self.delegate respondsToSelector:@selector(loadFileData:)]) {
            [data_m appendBytes:buffer length:buffer_size];
            [self.delegate loadFileData:data_m];
            [data_m replaceBytesInRange:NSMakeRange(0, data_m.length) withBytes:nil length:0];
        }
    }
#else
    NSMutableData *data = [[NSMutableData alloc] initWithLength:length];
    generateTestFileData(0, (unsigned char*)[data bytes], (unsigned int)length);
    [self.delegate loadFileData:data];
#endif
}

unsigned int generateTestFileData(unsigned int index,
                                  unsigned char *buffer,
                                  unsigned int buffer_size)
{
    unsigned char *buffw = buffer;
    char char_table[17] = "0123456789ABCDEF";
    unsigned int i;
    
    if (!buffw) { return 0; }
    if (buffer_size % 10 != 0) { return 0; }
    
    for (i = 0; i < buffer_size; i += 10)
    {
        buffw[i] = '[';
        buffw[i+8] = char_table[(index >> 0) & 0x0000000F];
        buffw[i+7] = char_table[(index >> 4) & 0x0000000F];
        buffw[i+6] = char_table[(index >> 8) & 0x0000000F];
        buffw[i+5] = char_table[(index >> 12) & 0x0000000F];
        buffw[i+4] = char_table[(index >> 16) & 0x0000000F];
        buffw[i+3] = char_table[(index >> 20) & 0x0000000F];
        buffw[i+2] = char_table[(index >> 24) & 0x0000000F];
        buffw[i+1] = char_table[(index >> 28) & 0x0000000F];
        buffw[i+9] = ']';
        index += 1;
    }
    
    return index;
}


//10进制转为16进制
- (NSString *)turnStringToSignedHex:(int)number {
    if (number == 0) {
        return @"0";
    } else {
        char hexChar[20];
        sprintf(hexChar, "%x", number);
        NSString *hexStr = [NSString stringWithCString:hexChar encoding:NSUTF8StringEncoding];
        for (int i = 0; i < hexStr.length; i++) {
            UniChar s1 = [hexStr characterAtIndex:i];
            if (s1 >= 'a' && s1 <= 'z') {
                hexStr = (NSMutableString *)[hexStr stringByReplacingCharactersInRange:NSMakeRange(i, 1) withString:[NSString stringWithFormat:@"%c",s1-32]];
            }
        }
        return hexStr;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    self.byteCountTF.text = [def valueForKey:@"sf_byteCount"];
    self.byteCountTF.delegate = self;
    //    NSLog(@"%@,%ld",[def valueForKey:@"sf_byteCount"],[def integerForKey:@"sf_byteTypeSC"]);
    if ([self.byteCountTF.text isEqualToString:@""]) {
        self.byteCountTF.text = [NSString stringWithFormat:@"%d", 50];
    }
    self.byteTypeSC.selectedSegmentIndex = [def integerForKey:@"sf_byteTypeSC"];
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    if ([textField.text integerValue]*10 >= 50) {
        if ([string isEqualToString:@""]) {
            return YES;
        }
        if ([textField.text isEqualToString:@"5"] && [string isEqualToString:@"0"]) {
            return YES;
        }
        return NO;
    } else {
        return YES;
    }
}

-(void)viewWillDisappear:(BOOL)animated{
    [[NSUserDefaults standardUserDefaults] setValue:self.byteCountTF.text forKey:@"sf_byteCount"];
    [[NSUserDefaults standardUserDefaults] setInteger:self.byteTypeSC.selectedSegmentIndex forKey:@"sf_byteTypeSC"];
}
- (IBAction)OKBtn:(UIButton *)sender {
    NSInteger number = [self.byteCountTF.text integerValue];
    NSInteger multiple;
    switch (self.byteTypeSC.selectedSegmentIndex) {
        case 0:
            multiple = 1024;
            break;
        case 1:
            multiple = 1024*1024;
            break;
        case 2:
            multiple = 1000;
            break;
        case 3:
            multiple = 1000*1000;
            break;
        default:
            multiple = 1024;
            break;
    }
    number = number*multiple;
    [self.delegate sendFileByData:self.data sendLength:number];
    //加载数据
    [self loadData:number];
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)clickBtn:(UIButton *)sender {
    NSInteger stringSendLength = 0;
    switch (sender.tag) {
        case 1001:
            stringSendLength = BTN1;
            break;
        case 1002:
            stringSendLength = BTN2;
            break;
        case 1003:
            stringSendLength = BTN3;
            break;
        case 1004:
            stringSendLength = BTN4;
            break;
        case 1005:
            stringSendLength = BTN5;
            break;
        case 1006:
            stringSendLength = BTN6;
            break;
        case 1007:
            stringSendLength = BTN7;
            break;
        case 1008:
            stringSendLength = BTN8;
            break;
        case 1009:
            stringSendLength = BTN9;
            break;
        case 1010:
            stringSendLength = BTN10;
            break;
        default:
            break;
    }
    [self.delegate sendFileByData:self.data sendLength:stringSendLength];
    //加载数据
    [self loadData:stringSendLength];
    [self.navigationController popViewControllerAnimated:YES];
}
//- (IBAction)clivkToSend:(id)sender {
//    [self.navigationController popViewControllerAnimated:YES];
//    [self.delegate sendFileByData:self.srcData sendLength:self.srcData.length];
//}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)dealloc{
    NSLog(@"销毁FESendFileTableViewController");
}
@end
