//
//  FESettingTableViewController.h
//  BLEAssistant
//
//  Created by yumingyue on 2016/12/5.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FESettingModel.h"

@interface FESettingTableViewController : UITableViewController
@property (nonatomic, strong) FESettingModel *settingModel;
@end
