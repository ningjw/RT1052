//
//  FEWeChatViewController.m
//  BLEAssistant
//
//  Created by yumingyue on 2016/11/25.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import "FEWeChatViewController.h"
#import "WXApi.h"
#import "WXApiObject.h"

@interface FEWeChatViewController ()<WXApiDelegate>

@end

@implementation FEWeChatViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"weixin://qr/izpIUDPECG53rXcz92_Z"]];
//    NSLog(@"dian");
//    JumpToBizProfileReq *req = [[JumpToBizProfileReq alloc]init];
//    req.username=@"gh_98dad7d38bb5";
//    req.extMsg = @"";
//    req.profileType = WXBizProfileType_Normal;
//    [WXApi sendReq:req];
}

@end
