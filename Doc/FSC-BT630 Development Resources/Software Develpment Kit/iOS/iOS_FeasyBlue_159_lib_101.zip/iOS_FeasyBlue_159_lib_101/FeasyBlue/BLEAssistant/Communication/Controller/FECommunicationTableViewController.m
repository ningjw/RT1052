//
//  FECommunicationTableViewController.m
//  FeasycomLE
//
//  Created by 余明悦 on 16/7/20.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import "FECommunicationTableViewController.h"
#import "FECommunicationTableViewCell.h"
#import "FECommunicationChatViewController.h"
#import <MJRefresh.h>
#import <SVProgressHUD.h>
#import "AppDelegate.h"
#import "NSString+FEString.h"
#import "FscBleCentralApi.h"
#import "FENavigationController.h"
#import "ServiceInfo.h"
#import <ExternalAccessory/ExternalAccessory.h>
#import "FEFilterViewController.h"
#import "UIColor+FEColor.h"
#import "MemoryInfo.h"
#import "Masonry.h"

#define NONERE            0
#define CONNETING         1
#define OPENINGEN         2
#define GETNAINFO         3
#define ERRORDATA         4
#define GETPININFO        5
#define GETBAUDINFO       6
#define CHANGEINFO        7

typedef enum {
    BLE_TYPE = 0,
    MFI_TYPE,
} SEARCH_TYPE;

static NSString *headString = @"headString";

@interface FECommunicationTableViewController ()<UITableViewDelegate, UITableViewDataSource>
//外设数组
@property (nonatomic, strong) NSMutableArray *peripherals;
@property (nonatomic, strong) NSMutableArray *advertisementDatas;
@property (nonatomic, strong) NSMutableArray *pwds;
@property (nonatomic, strong) NSDictionary *advertisementData;
//中心管理者
@property (nonatomic, strong) FscBleCentralApi *api;
//信号数组
@property (nonatomic, strong) NSMutableArray *RSSIs;
@property (nonatomic, strong) NSTimer *reflashRSSITimer;
@property (nonatomic) NSInteger tag_setting_selectBtn;
@property (nonatomic, strong) FECommunicationTableViewCell *selectCell;
@property (nonatomic, strong) NSUserDefaults *def;
@property (nonatomic, strong) NSIndexPath *nIndexPath;
//修改信息
@property (nonatomic, strong) NSData *sendData;
//计时器
@property (nonatomic, strong) NSTimer *timerForOpenAT;
//接收状态
@property (nonatomic) NSInteger reState;
@property (nonatomic, strong) NSMutableArray * isChangeInfos;
@property (nonatomic, strong) NSMutableArray *changeInfos;
@property (nonatomic, strong) NSMutableArray *succesDrivers;
@property (nonatomic, strong) NSMutableArray *infosAfter;
@property (nonatomic) NSInteger changeWitchOne;

@property (nonatomic, assign) SEARCH_TYPE search_type;
@property (nonatomic, strong) NSMutableArray *peripherals_mfi;
@property (nonatomic, strong) EAAccessory *accessory;
@property (nonatomic, assign) NSInteger minimumRSSI;
@property (nonatomic, strong) UIBarButtonItem *btn;
@property (nonatomic, strong) MemoryInfo *info;

@property (nonatomic, strong) UITableView *communicationTableView;

@end

@implementation FECommunicationTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.search_type = BLE_TYPE;
    // 设置界面
    [self setupUI];
    //初始化
    self.api = [FscBleCentralApi shareFscBleCentralApi];
    self.api.moduleType = BLEMODULE;
    //设置navigationItem
//    [self setNavigationItem];
    //设置返回按钮颜色
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    //刷新
    self.communicationTableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        self.communicationTableView.userInteractionEnabled = NO;
        if (self.search_type == MFI_TYPE) {
            [self.peripherals_mfi removeAllObjects];
            //刷新效果
            [self.communicationTableView reloadData];
            self.peripherals_mfi = [[NSMutableArray alloc] initWithArray:[[EAAccessoryManager sharedAccessoryManager] connectedAccessories]];
        } else {
            [self.peripherals removeAllObjects];
            [self.advertisementDatas removeAllObjects];
            [self.RSSIs removeAllObjects];
        }
        [self.communicationTableView reloadData];
        [self.communicationTableView.mj_header endRefreshing];
        if (self.search_type == BLE_TYPE) {
            [self.api startScan];
        }
        self.communicationTableView.userInteractionEnabled = YES;
    }];
    self.communicationTableView.mj_header.automaticallyChangeAlpha = YES;
    if (self.search_type == BLE_TYPE) {
        // 设置代理
        [self setDelegate];
    }
    NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
    BOOL enable = [user boolForKey:@"enable"];
    float f = [user floatForKey:@"minimumRSSI"];
    if ((int)f < 0 && enable) {
        self.minimumRSSI = (int)f;
    }
    self.info = [MemoryInfo shareMemoryInfo];
    self.info.firstConnect = YES;
}

- (void)setupUI {
    UIView *buttonView = [[UIView alloc] initWithFrame:CGRectMake(0, IsiPhoneX?NAVIGATIONHEIGHT_iPhoneX:NAVIGATIONHEIGHT, self.view.frame.size.width, 44)];
    buttonView.backgroundColor = [UIColor groupTableViewBackgroundColor];
    [self.view addSubview:buttonView];
    UIView *sortView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, buttonView.frame.size.width/2.0, buttonView.frame.size.height)];
    [buttonView addSubview:sortView];
    UITapGestureRecognizer *tapSort = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(sort)];
    [sortView addGestureRecognizer:tapSort];
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"排序"]];
    [sortView addSubview:imageView];
    UILabel *sortLable = [[UILabel alloc] init];
    sortLable.text = @"排序";
    sortLable.font = [UIFont systemFontOfSize:17];
    [sortView addSubview:sortLable];
    
    UIView *filterView = [[UIView alloc] initWithFrame:CGRectMake(buttonView.frame.size.width/2.0, 0, buttonView.frame.size.width/2.0, buttonView.frame.size.height)];
    [buttonView addSubview:filterView];
    UITapGestureRecognizer *tapFilter = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clickToFilter)];
    [filterView addGestureRecognizer:tapFilter];
    UIImageView *filterImageV = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"过滤2"]];
    [filterView addSubview:filterImageV];
    UILabel *filterLable = [[UILabel alloc] init];
    filterLable.text = @"过滤";
    filterLable.font = [UIFont systemFontOfSize:17];
    [filterView addSubview:filterLable];
    UIView *lineView = [[UIView alloc] init];
    lineView.backgroundColor = [UIColor blackColor];
    [buttonView addSubview:lineView];
    
//    UIButton *button_L = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, buttonView.frame.size.width/2.0, buttonView.frame.size.height)];
//    [button_L setTitle:@"排序" forState:UIControlStateNormal];
//    button_L.titleEdgeInsets = UIEdgeInsetsMake(-10, -500, -10, -150);
////    button_L.titleLabel.font = [UIFont systemFontOfSize:17];
//    [button_L setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
//    [button_L addTarget:self action:@selector(sort) forControlEvents:UIControlEventTouchUpInside];
//    [button_L setImage:[UIImage imageNamed:@"排序"] forState:UIControlStateNormal];
//    button_L.imageEdgeInsets = UIEdgeInsetsMake(10, 30, 10, 120);
//    [buttonView addSubview:button_L];
//    UIButton *button_R = [[UIButton alloc] initWithFrame:CGRectMake(buttonView.frame.size.width/2.0, 0, buttonView.frame.size.width/2.0, buttonView.frame.size.height)];
//    [button_R setTitle:@"过滤" forState:UIControlStateNormal];
//    button_R.titleLabel.font = [UIFont systemFontOfSize:17];
//    [button_R setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
//    [button_R addTarget:self action:@selector(clickToFilter) forControlEvents:UIControlEventTouchUpInside];
//    [buttonView addSubview:button_R];
    // 创建tableView
    self.communicationTableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    [self.view addSubview:self.communicationTableView];
    
    [self.communicationTableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(self.view);
        make.top.equalTo(buttonView.mas_bottom);
        make.bottom.equalTo(self.view).offset(-(IsiPhoneX?TABBARHEIGHT_iPhoneX:TABBARHEIGHT));
    }];
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(sortView).offset(12);
        make.bottom.equalTo(sortView).offset(-12);
        make.right.equalTo(sortView).offset(-(sortView.frame.size.width/2.0)-5);
        make.width.mas_equalTo(20*1.6);
    }];
    [sortLable mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(imageView);
        make.left.equalTo(sortView).offset((sortView.frame.size.width/2.0)+5);
    }];
    [filterImageV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.bottom.equalTo(imageView);
        make.right.equalTo(filterView).offset(-(filterView.frame.size.width/2.0)-8);
        make.width.mas_equalTo(20);
    }];
    [filterLable mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(filterImageV);
        make.left.equalTo(filterView).offset((filterView.frame.size.width/2.0)+5);
    }];
    [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(buttonView).offset(10);
        make.bottom.equalTo(buttonView).offset(-10);
        make.centerX.equalTo(buttonView);
        make.width.mas_equalTo(1);
    }];
    self.communicationTableView.delegate = self;
    self.communicationTableView.dataSource = self;
    //去掉列表分割线
    [self.communicationTableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    //注册cell
    [self.communicationTableView registerNib:[UINib nibWithNibName:@"FECommunicationTableViewCell"bundle:nil] forCellReuseIdentifier:@"CommCell"];
    [self.communicationTableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"MyCell"];
}

//设置navigationItem
- (void)setNavigationItem {
    UIBarButtonItem *buttonL = [[UIBarButtonItem alloc] initWithTitle:FELocalizedString(@"sort") style:UIBarButtonItemStylePlain target:self action:@selector(sort)];
    self.navigationItem.leftBarButtonItem = buttonL;
    UIButton * leftBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 40, 20)];
    [leftBtn setTitle:FELocalizedString(@"filter") forState:UIControlStateNormal];
    leftBtn.titleLabel.font = [UIFont systemFontOfSize:17];
    [leftBtn setTitleColor:[UIColor colorWithRed:21/255.0 green:126/255.0 blue:251/255.0 alpha:1] forState:UIControlStateNormal];
    [leftBtn setTitleColor:[UIColor colorWithRed:210/255.0 green:230/255.0 blue:245/255.0 alpha:1] forState:UIControlStateHighlighted];
    [leftBtn addTarget:self action:@selector(clickToFilter) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem * buttonL2 = [[UIBarButtonItem alloc] initWithCustomView:leftBtn];
    self.navigationItem.rightBarButtonItem = buttonL2;
}

- (void)clickToFilter {
    FEFilterViewController *filterVC = [[FEFilterViewController alloc] init];
    filterVC.typeRssi = COMMUNICATION;
    __weak typeof(self) weakself = self;
    filterVC.minimumRSSIBlock = ^(float RSSI) {
        weakself.minimumRSSI = (int)RSSI;
        [weakself.peripherals removeAllObjects];
        [weakself.communicationTableView reloadData];
        if (weakself.search_type == BLE_TYPE) {
            [weakself.api startScan];
        }
        NSLog(@"%d",weakself.btn.enabled);
    };
    [self.navigationController pushViewController:filterVC animated:YES];
}

//排序
- (void)sort {
    for (int i = 0; i < self.peripherals.count; ++i) {
        //遍历数组的每一个索引（不包括最后一个,因为比较的是j+1）
        for (int j = 0; j < self.peripherals.count-1; ++j) {
            //根据索引的相邻两位进行比较
            if ([self.RSSIs[j] integerValue] < [self.RSSIs[j+1] integerValue]) {
                [self.peripherals exchangeObjectAtIndex:j withObjectAtIndex:j+1];
                [self.RSSIs exchangeObjectAtIndex:j withObjectAtIndex:j+1];
                [self.advertisementDatas exchangeObjectAtIndex:j withObjectAtIndex:j+1];
            }
        }
    }
    [self.communicationTableView reloadData];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.barStyle = UIStatusBarStyleLightContent;
}

#pragma mark -蓝牙配置和操作
#pragma mark - CBCentralManagerDelegate
//扫描外设
- (void)openOrclosed{
    if([self.navigationItem.rightBarButtonItem.title isEqualToString:@"BLE"]) {
        //        NSLog(@"扫描");
        [self.navigationItem.rightBarButtonItem setTitle:@"MFI"];
        //        [self.api startScan];
        self.search_type = MFI_TYPE;
        [self.api stopScan];
        self.peripherals_mfi = [[NSMutableArray alloc] initWithArray:[[EAAccessoryManager sharedAccessoryManager] connectedAccessories]];
        [self.communicationTableView reloadData];
    }else {
        //        NSLog(@"停止扫描");
        //        [self.api stopScan];
        [self.navigationItem.rightBarButtonItem setTitle:@"BLE"];
        self.search_type = BLE_TYPE;
        //        [self.api startScan];
        [self.communicationTableView reloadData];
    }
}
#pragma mark - CBCentralManagerDelegate
- (void)setDelegate {

    __weak typeof(self) weakSelf = self;
    // 判断蓝牙是否打开
    [self.api isBtEnabled:^(CBCentralManager *central) {
        if (central.state == CBManagerStatePoweredOn) {
            [weakSelf.api startScan];
        }
    }];

    // 搜索设备
    [self.api blePeripheralFound:^(CBCentralManager *central, CBPeripheral *peripheral, NSDictionary *advertisementData, NSNumber *RSSI) {
        if (weakSelf.minimumRSSI) {
            if ([RSSI integerValue]<0 && [RSSI integerValue]>weakSelf.minimumRSSI) {
                if (![weakSelf.peripherals containsObject:peripheral]) {
                    [weakSelf insertTableView:peripheral advertisementData:advertisementData RSSI:RSSI];
                }else{
                    NSInteger index = [weakSelf.peripherals indexOfObject:peripheral];
                    weakSelf.RSSIs[index] = RSSI;
                }
            }
        } else {
            if ([RSSI integerValue]<0 && [RSSI integerValue]>-100) {
                if (![weakSelf.peripherals containsObject:peripheral]) {
                    [weakSelf insertTableView:peripheral advertisementData:advertisementData RSSI:RSSI];
                }else{
                    NSInteger index = [weakSelf.peripherals indexOfObject:peripheral];
                    weakSelf.RSSIs[index] = RSSI;
                }
            }
        }
    }];

    // 连接设备
    [self.api blePeripheralConnected:^(CBCentralManager *central, CBPeripheral *peripheral) {
        if (weakSelf.info.firstConnect) {
            weakSelf.info.firstConnect = NO;
            [weakSelf.api stopScan];
            FECommunicationChatViewController *chatVC = [[FECommunicationChatViewController alloc] initWithAdvertisementData:weakSelf.advertisementData type:0];
            chatVC.hidesBottomBarWhenPushed = YES;
            chatVC.sto = weakSelf.storyboard;
            [weakSelf.navigationController pushViewController:chatVC animated:YES];
        }
    }];

    // 设备返回信息的回调函数
    [self.api packetReceived:^(CBPeripheral *peripheral, CBCharacteristic *characteristic, NSError *error) {
        NSString *stringByBuf = [[NSString alloc] initWithData:characteristic.value encoding:NSUTF8StringEncoding];
        if ([stringByBuf rangeOfString:@"ERROR"].location != NSNotFound) weakSelf.reState = ERRORDATA;
        switch (weakSelf.reState) {
            case OPENINGEN:
                if ([stringByBuf rangeOfString:@"$OK,Opened$"].location != NSNotFound) {
                    [weakSelf.timerForOpenAT invalidate];
                    NSData *data = [@"AT+NAME\r\n" dataUsingEncoding:NSUTF8StringEncoding];
                    [weakSelf.api send:data withResponse:NO withSendStatusBlock:^(NSData *data) {

                    }];
                    weakSelf.reState = GETNAINFO;
                }
                break;
            case GETNAINFO:
                if ([stringByBuf rangeOfString:@"+NAME="].location != NSNotFound) {
                    NSData *data = [@"AT+PIN\r\n" dataUsingEncoding:NSUTF8StringEncoding];
                    [weakSelf.api send:data withResponse:NO withSendStatusBlock:^(NSData *data) {

                    }];
                    weakSelf.reState = GETPININFO;
                }
                break;
            case ERRORDATA:
                [weakSelf changeInfoFail];
                [weakSelf.api disconnect];
                break;
            case GETPININFO:
                if ([stringByBuf rangeOfString:@"+PIN="].location != NSNotFound) {
                    NSData *data = [@"AT+BAUD\r\n" dataUsingEncoding:NSUTF8StringEncoding];
                    [weakSelf.api send:data withResponse:NO withSendStatusBlock:^(NSData *data) {

                    }];
                    weakSelf.reState = GETBAUDINFO;
                }
                break;
            case GETBAUDINFO:
                if ([stringByBuf rangeOfString:@"+BAUD="].location != NSNotFound) {
                    weakSelf.reState = CHANGEINFO;
                    if ([weakSelf.isChangeInfos[weakSelf.changeWitchOne] boolValue]) {
                        [weakSelf send:weakSelf.changeInfos[weakSelf.changeWitchOne]];
                    }else{
                        [weakSelf nextChangeInfo];
                    }
                }
                break;
            case CHANGEINFO:
                if ([stringByBuf rangeOfString:@"OK"].location != NSNotFound) {
                    [weakSelf nextChangeInfo];
                }
                break;
            default:
                break;
        }
    }];

}


- (void)send:(NSString*)string{
    self.sendData = [string dataUsingEncoding:NSUTF8StringEncoding];
    [self.api send:self.sendData withResponse:NO withSendStatusBlock:^(NSData *data) {

    }];
}

-(void)openATTimeout{
    //    NSLog(@"超时");
    //    NSLog(@"尝试断开");
    [self changeInfoFail];
    [self.api disconnect];
}
- (NSString *)getStringBy:(NSString *)reString cut:(NSString *)cutString{
    NSString *strTemp;
    NSRange r1 = [reString rangeOfString:cutString];
    if (r1.location >= reString.length || r1.length <= 0) return FELocalizedString(@"forFail");
    strTemp = [reString substringWithRange:NSMakeRange(r1.location + r1.length, reString.length-r1.location-r1.length)];
    r1 = [strTemp rangeOfString:@"\r\n"];
    if (r1.location >= reString.length || r1.length <= 0) return FELocalizedString(@"forFail");
    NSRange range = NSMakeRange(0, r1.location);
    strTemp = [strTemp substringWithRange:range];
    return strTemp;
}
- (void)nextChangeInfo{
    //    NSLog(@"下一个");
    self.changeWitchOne++;
    if (self.changeWitchOne < self.changeInfos.count) {
        if ([self.isChangeInfos[self.changeWitchOne] boolValue]) {
            [self send:self.changeInfos[self.changeWitchOne]];
        }else{
            [self nextChangeInfo];
        }
    }else if (self.changeWitchOne == self.changeInfos.count){
        [self.succesDrivers addObject:self.selectCell.serviceUUIDsLabel.text];
        //        NSLog(@"尝试断开");
        [self changeInfoOk];
        [self.api disconnect];
    }
}
//插入table数据
-(void)insertTableView:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI{
    if ([RSSI integerValue]<-100 && [RSSI integerValue]>0) return;
    if(![self.peripherals containsObject:peripheral]) {
        if (!self.communicationTableView.isDragging && !self.communicationTableView.isTracking && !self.communicationTableView.isDecelerating) {
            NSMutableArray *indexPaths = [[NSMutableArray alloc] init];
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:self.peripherals.count inSection:0];
            [indexPaths addObject:indexPath];
            [self.peripherals addObject:peripheral];
            [self.advertisementDatas addObject:advertisementData];
            [self.RSSIs addObject:RSSI];
            [self.communicationTableView insertRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationAutomatic];
        }
    }else{
        NSInteger index = [self.peripherals indexOfObject:peripheral];
        self.RSSIs[index] = RSSI;
    }
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (self.search_type == BLE_TYPE) {
        return self.peripherals.count;
    } else {
        return self.peripherals_mfi.count;
    }
}

- (FECommunicationTableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    FECommunicationTableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    if(cell == nil) {
        cell = [tableView dequeueReusableCellWithIdentifier:@"CommCell"];
    }
    if (self.search_type == MFI_TYPE) {
        CBPeripheral *peripheral = [self.peripherals_mfi objectAtIndex:indexPath.row];
        cell.serviceUUIDsLabel.hidden = YES;
        cell.UUIDLabel.hidden = YES;
        [cell reflashName:[peripheral name]];
    } else {
        CBPeripheral *peripheral = [self.peripherals objectAtIndex:indexPath.row];
        NSDictionary *advertisementData = self.advertisementDatas[indexPath.row];
        if (advertisementData[CBAdvertisementDataLocalNameKey]) {
            [cell reflashName:[NSString stringWithFormat:@"%@",advertisementData[CBAdvertisementDataLocalNameKey]]];
        }else{
            [cell reflashName:peripheral.name];
        }
        [cell reflashRSSI:[self.RSSIs[indexPath.row] integerValue]];
        cell.UUIDLabel.text = peripheral.identifier.UUIDString;
        if ([advertisementData[@"kCBAdvDataServiceUUIDs"] componentsJoinedByString:@","]) {
            cell.serviceUUIDsLabel.text = [[NSString alloc] initWithFormat:@"%@",[advertisementData[@"kCBAdvDataServiceUUIDs"] componentsJoinedByString:@","]];
        }else{
            cell.serviceUUIDsLabel.text = @"";
        }
    }
    return cell;
}

// 选择列表
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    self.selectCell = [tableView cellForRowAtIndexPath:indexPath];
    if (self.search_type == MFI_TYPE) {
        self.accessory = [[EAAccessoryManager sharedAccessoryManager] connectedAccessories][indexPath.row];
        FECommunicationChatViewController *chatVC = [[FECommunicationChatViewController alloc] initWithAdvertisementData:self.advertisementData type:MFI_TYPE];
        chatVC.hidesBottomBarWhenPushed = YES;
        chatVC.sto = self.storyboard;
        chatVC.accessory = self.accessory;
        [self.navigationController pushViewController:chatVC animated:YES];
    } else {
        self.api.peripheral = self.peripherals[indexPath.row];
        NSDictionary *advertisementData = self.advertisementDatas[indexPath.row];
        self.advertisementData = advertisementData;
        [FEShareBt sharedFEShareBt].connetedName = advertisementData[CBAdvertisementDataLocalNameKey] ? [NSString stringWithFormat:@"%@",advertisementData[CBAdvertisementDataLocalNameKey]] : self.api.peripheral.name;
        [self.api connect:self.peripherals[indexPath.row]];
    }
}

- (CGFloat)tableView:(UITableView*)tableView heightForRowAtIndexPath:(NSIndexPath*)indexPath{
    return 60;
}


#pragma 自己写的方法
-(void)reflashRSSI{
    for (int i=0; i<self.RSSIs.count; i++) {
        FECommunicationTableViewCell *cell = [self.communicationTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:i inSection:0]];
        [cell reflashRSSI:[self.RSSIs[i] integerValue]];
    }
}

- (void)createAlertController {
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"PIN" message:@"" preferredStyle:UIAlertControllerStyleAlert];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.placeholder = @"Please input a password";
    }];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"cancel" style:UIAlertActionStyleCancel handler:nil];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self.api connect:self.peripherals[self.nIndexPath.row]];
    }];
    [alertController addAction:cancelAction];
    [alertController addAction:okAction];
    [self presentViewController:alertController animated:YES completion:nil];
}

- (void)changeInfoOk{
    [SVProgressHUD showInfoWithStatus:FELocalizedString(@"success")];
    [self.communicationTableView.mj_header beginRefreshing];
}

- (void)changeInfoFail{
    [SVProgressHUD showInfoWithStatus:FELocalizedString(@"fail")];
    [self.communicationTableView.mj_header beginRefreshing];
}

#pragma 视图状态
- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:YES];
    [self.communicationTableView reloadData];
    if (self.search_type == BLE_TYPE) {
        [self.api startScan];
        if (!self.reflashRSSITimer) {
            self.reflashRSSITimer = [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(reflashRSSI) userInfo:nil repeats:YES];
        }
    }
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [self.api stopScan];
    if (self.reflashRSSITimer) {
        [self.reflashRSSITimer invalidate];
        self.reflashRSSITimer = nil;
    }
    //必须清除数组数据，否则无法更新设置的数据
    if (self.isChangeInfos) {
        [self.isChangeInfos removeAllObjects];
        self.isChangeInfos = nil;
    }
    if (self.changeInfos) {
        [self.changeInfos removeAllObjects];
        self.changeInfos = nil;
    }
}

// 十六进制数据转字符串
-(NSString *)fan_dataToHexString:(NSData *)data{
    Byte *bytehex =(Byte *) data.bytes;
    NSMutableString *hexString=[[NSMutableString alloc]init];
    for (int i=0; i<data.length; i++) {
        Byte b=bytehex[i];
        [hexString appendFormat:@"%02x",b];
    }
    return hexString;
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    [self.api stopScan];
}

#pragma 懒加载
-(NSMutableArray *)peripherals{
    if (!_peripherals) {
        _peripherals = [NSMutableArray array];
        [FEShareBt sharedFEShareBt].peripherals = _peripherals;
    }
    return _peripherals;
}
-(NSMutableArray *)advertisementDatas{
    if (!_advertisementDatas) {
        _advertisementDatas = [NSMutableArray array];
    }
    return _advertisementDatas;
}
-(NSMutableArray *)RSSIs{
    if (!_RSSIs) {
        _RSSIs = [NSMutableArray array];
        [FEShareBt sharedFEShareBt].RSSIs = _RSSIs;
    }
    return _RSSIs;
}
- (NSMutableArray *)isChangeInfos{
    if (!_isChangeInfos) {
        _isChangeInfos = [NSMutableArray array];
        [_isChangeInfos addObject:[NSString stringWithFormat:@"%d", [self.def boolForKey:@"change_isChangeName"]]];
        [_isChangeInfos addObject:[NSString stringWithFormat:@"%d", [self.def boolForKey:@"change_isChangePin"]]];
        [_isChangeInfos addObject:[NSString stringWithFormat:@"%d", [self.def boolForKey:@"change_isChangeBaud"]]];
    }
    return _isChangeInfos;
}
-(NSMutableArray *)changeInfos{
    if (!_changeInfos) {
        _changeInfos = [NSMutableArray array];
        [_changeInfos     addObject:[NSString stringWithFormat:@"AT+NAME=%@\r\n", [self.def valueForKey:@"change_name"]]];
        [_changeInfos     addObject:[NSString stringWithFormat:@"AT+PIN=%@\r\n", [self.def valueForKey:@"change_pin"]]];
        [_changeInfos     addObject:[NSString stringWithFormat:@"AT+BAUD=%@\r\n", [self.def valueForKey:@"change_baud"]]];
    }
    return _changeInfos;
}
- (NSMutableArray *)succesDrivers{
    if (!_succesDrivers) {
        _succesDrivers = [NSMutableArray array];
    }
    return _succesDrivers;
}
- (NSMutableArray *)infosAfter{
    if (!_infosAfter) {
        _infosAfter = [NSMutableArray array];
    }
    return _infosAfter;
}
-(NSUserDefaults *)def{
    if (!_def) {
        _def = [NSUserDefaults standardUserDefaults];
    }
    return _def;
}

@end

