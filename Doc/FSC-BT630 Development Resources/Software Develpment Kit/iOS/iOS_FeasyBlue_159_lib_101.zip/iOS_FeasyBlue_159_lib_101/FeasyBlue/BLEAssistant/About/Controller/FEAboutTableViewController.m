//
//  FEAboutTableViewController.m
//  BLEAssistant
//
//  Created by yumingyue on 16/10/31.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import "FEAboutTableViewController.h"
#import <MessageUI/MessageUI.h>
#import "NSString+FscKit.h"

@interface FEAboutTableViewController ()<MFMailComposeViewControllerDelegate >
@property (weak, nonatomic) IBOutlet UIImageView *logoImageView;
@property (weak, nonatomic) IBOutlet UILabel *appVersion;

@end

@implementation FEAboutTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //bundle版本
    self.appVersion.text = [NSString getLocalAppVersion];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.barStyle = UIStatusBarStyleLightContent;
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.logoImageView.clipsToBounds = YES;
    self.logoImageView.contentMode = UIViewContentModeScaleAspectFill;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (0 == indexPath.section) {
        switch (indexPath.row) {
            case 0:
                break;
            case 1:
                break;
            case 2:
            {
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"telprompt://075527924639"]];
            }
                break;
            case 3:
            {
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://www.feasycom.com"]];
            }
                break;
            case 4:
            {
                if([MFMailComposeViewController canSendMail]){
                    MFMailComposeViewController *mailCon = [MFMailComposeViewController new];
                    [mailCon setSubject:FELocalizedString(@"question")];
                    [mailCon setToRecipients:@[@"support@feasycom.com"]];
                    // 设置发邮件的代理
                    [mailCon setMailComposeDelegate:self];
                    [self presentViewController:mailCon animated:YES completion:nil];
                    
                }else{
//                    NSLog(@"不能发邮件");
                }
            }
                break;
            default:
                break;
        }

    }else if (1 == indexPath.section) {
        switch (indexPath.row) {
            case 1:
                if([MFMailComposeViewController canSendMail]){
                    MFMailComposeViewController *mailCon = [MFMailComposeViewController new];
                    [mailCon setSubject:FELocalizedString(@"softwareProblem")];
                    [mailCon setToRecipients:@[@"support@feasycom.com"]];
                    [mailCon setMessageBody:FELocalizedString(@"helloyu") isHTML:YES];
                    // 设置发邮件的代理
                    [mailCon setMailComposeDelegate:self];
                    [self presentViewController:mailCon animated:YES completion:nil];
                    
                }else{
//                    NSLog(@"不能发邮件");
                }
                break;
        }
    }
}


#pragma MFMailComposeViewControllerDelegate
- (void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error{
    switch (result) {
        case MFMailComposeResultSent:
//            NSLog(@"发送成功");
            break;
        case MFMailComposeResultFailed:
//            NSLog(@"发送失败");
            break;
        case MFMailComposeResultCancelled:
//            NSLog(@"取消发送");
            break;
        default:
            break;
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}
/*
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:<#@"reuseIdentifier"#> forIndexPath:indexPath];
    
    // Configure the cell...
    
    return cell;
}
*/

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
