//
//  FEDFUFileTableViewController.m
//  BLEAssistant
//
//  Created by ericj on 2018/4/10.
//  Copyright © 2018年 feasycom. All rights reserved.
//

#define cellID       @"cellID"

#import "FEDFUFileTableViewController.h"
#import "FEDFUOtherFileTableViewController.h"

@interface FEDFUFileTableViewController ()

@property (nonatomic, strong) NSArray *typeArray;

@end

@implementation FEDFUFileTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.typeArray = [NSArray arrayWithObjects:@"从QQ获取文件",@"从微信获取文件",@"从本地获取文件", nil];
    
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:cellID];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.typeArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID forIndexPath:indexPath];
    cell.textLabel.text = self.typeArray[indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0) {
        if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"mqq://"]]) {
            if ([[UIDevice currentDevice].systemVersion doubleValue] >= 10.0) {
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"mqq://"] options:@{} completionHandler:nil];
            } else {
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"mqq://"]];
            }
        }
        [self.navigationController popViewControllerAnimated:YES];
    } else if (indexPath.row == 1) {
        if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"weixin://"]]) {
            if ([[UIDevice currentDevice].systemVersion doubleValue] >= 10.0) {
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"weixin://"] options:@{} completionHandler:nil];
            } else {
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"weixin://"]];
            }
        }
        [self.navigationController popViewControllerAnimated:YES];
    } else if (indexPath.row == 2) {
        FEDFUOtherFileTableViewController *fileVC = [[FEDFUOtherFileTableViewController alloc] init];
        [self.navigationController pushViewController:fileVC animated:YES];
    }
    
}

-(CGFloat)tableView:(UITableView*)tableView heightForRowAtIndexPath:(NSIndexPath*)indexPath{
    return 60;
}


@end
