//
//  FESettingModel.h
//  BLEAssistant
//
//  Created by yumingyue on 2016/12/9.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Singleton.h"

@interface FESettingModel : NSObject
singleton_interface(FESettingModel)
//选择模式
@property (nonatomic) NSInteger tag_setting_selectBtn;
@property (nonatomic, strong) NSString *selectModelName;
//通讯
@property (nonatomic, strong) NSString *comm_serviceUUID;
@property (nonatomic, strong) NSString *comm_notiUUID;
@property (nonatomic, strong) NSString *comm_writeUUID;
@property (nonatomic) BOOL comm_isAppointServiceUUID;
@property (nonatomic) BOOL comm_isAppointNotiUUID;
@property (nonatomic) BOOL comm_isAppointWriteUUID;
//更改设备信息
@property (nonatomic, strong) NSString *change_name;
@property (nonatomic, strong) NSString *change_pin;
@property (nonatomic, strong) NSString *change_baud;
@property (nonatomic) BOOL change_isChangeName;
@property (nonatomic) BOOL change_isChangePin;
@property (nonatomic) BOOL change_isChangeBaud;
//固件升级
@property (nonatomic, strong) NSURL *dfu_selectedUrl;
@property (nonatomic, strong) NSString *dfu_selectedUrlName;
@property (nonatomic) BOOL dfu_isFactory;

//设备过滤
@property (nonatomic) BOOL filter_isFilter;
@property (nonatomic, strong) NSString *filter_name;
@property (nonatomic, strong) NSString *filter_rssi;
@property (nonatomic, strong) NSString *filter_serviceUUID;
@property (nonatomic, strong) NSString *filter_notiUUID;
@property (nonatomic, strong) NSString *filter_writeUUID;
@property (nonatomic) BOOL filter_isFilterName;
@property (nonatomic) BOOL filter_isFilterRssi;
@property (nonatomic) BOOL filter_isFilterServiceUUID;
@property (nonatomic) BOOL filter_isFilterNotiUUID;
@property (nonatomic) BOOL filter_isFilterWriteUUID;
//其它设置
@property (nonatomic) BOOL other_okVoice;
@property (nonatomic) BOOL other_failVoice;

-(id)init;
-(void)okVoice;
-(void)failVoice;
@end
