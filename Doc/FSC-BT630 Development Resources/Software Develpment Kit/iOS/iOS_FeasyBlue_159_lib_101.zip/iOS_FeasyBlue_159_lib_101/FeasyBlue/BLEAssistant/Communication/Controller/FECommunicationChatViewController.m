//
//  FECommunicationChatViewController.m
//  FeasycomLE
//
//  Created by 余明悦 on 16/7/20.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#define INFODEVICE @"180A"
#define RECONNECT  2

#import "FECommunicationChatViewController.h"
#import <zlib.h>
#import <SVProgressHUD.h>
#import "NSString+FEString.h"
#import "ServiceInfo.h"
#import "FESendFileTableViewController.h"
#import "FEChangeServiceTableViewController.h"
#import "UIViewController+BackButtonHandler.h"
#import "FEServiceDetailedTableViewController.h"
#import "MemoryInfo.h"

static NSInteger reByte;
static NSInteger rePackage;
static NSMutableData *reData;
static NSInteger crcRe;

@interface FECommunicationChatViewController ()<UITextViewDelegate, UITextFieldDelegate,FESendFileTableViewControllerDelegate,FEChangeServiceTableViewControllerDelegate,UINavigationBarDelegate>

//上下约束
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *safeLayoutConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bottomSafeLayoutConstraint;

@property (nonatomic) NSInteger sendByte;
@property (nonatomic) NSInteger sendPackage;
@property (nonatomic) NSInteger sendedFileCount;
//@property (nonatomic, strong) NSMutableData *reData;
@property (nonatomic, strong) NSMutableArray *reDataArr;
@property (nonatomic, strong) NSMutableArray *servicesArrM;
@property (nonatomic, strong) NSData *sendData;
@property (nonatomic, strong) NSThread *reflashViewThread;
@property (nonatomic) BOOL isStopReViTread;
@property (nonatomic) BOOL isClickHexSendSwitch;
@property (nonatomic) BOOL isSendingFile;
@property (nonatomic) BOOL isConnected;
@property (nonatomic, assign) BOOL interval;
@property (nonatomic, assign) BOOL isIntervalSend;
//@property (nonatomic) NSUInteger crcRe;
@property (nonatomic) NSUInteger crcSe;
@property (nonatomic) NSUInteger sendBytesPackage;
@property (nonatomic, strong) UIButton *rightBtn;
@property (nonatomic, strong) UILabel *rightLabel;
@property (nonatomic, strong) NSTimer *readRssiTimer;
@property (nonatomic, strong) NSTimer *reDataTimer;
@property (nonatomic) BOOL isClickBack;
@property (nonatomic) BOOL isSendBytes;
//速率
@property (nonatomic, strong) NSTimer *speed_timer;
@property (nonatomic, strong) NSTimer *byte_speed_timer;
@property (nonatomic, strong) NSThread *intervalSendThread;
@property (nonatomic, strong) NSTimer *intervalSendTimer;
@property (nonatomic) NSInteger speed_timeS;//秒数
@property (nonatomic) NSInteger speed_bytesCount;
@property (nonatomic) NSInteger speed_bytesCount2;
@property (nonatomic) NSInteger speed_bytesCount3;
@property (nonatomic) NSInteger speed_bytesCount4;
@property (nonatomic) NSInteger speed_bytesCount5;
@property (nonatomic, assign) NSInteger bytesIndex;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *layout_bottom;
@property (weak, nonatomic) IBOutlet UIButton *clearBtn;
@property (weak, nonatomic) IBOutlet UILabel *reByteLabel;
@property (weak, nonatomic) IBOutlet UILabel *rePackageLabel;
@property (weak, nonatomic) IBOutlet UILabel *crcReLabel;
@property (weak, nonatomic) IBOutlet UITextView *reTextView;
@property (weak, nonatomic) IBOutlet UILabel *sendByteLabel;
@property (weak, nonatomic) IBOutlet UILabel *sendPackageLabel;
@property (weak, nonatomic) IBOutlet UILabel *crcSeLabel;
@property (weak, nonatomic) IBOutlet UITextView *sendTextView;
@property (weak, nonatomic) IBOutlet UITextField *intervalTextField;
@property (weak, nonatomic) IBOutlet UISwitch *intervalSwitch;
@property (weak, nonatomic) IBOutlet UISwitch *hexSend;
@property (weak, nonatomic) IBOutlet UIButton *changeServicesBtn;
@property (weak, nonatomic) IBOutlet UILabel *sfBytesRunTimeLabel;
@property (weak, nonatomic) IBOutlet UILabel *textBytesLabel;
@property (weak, nonatomic) IBOutlet UIButton *sendButton;
@property (weak, nonatomic) IBOutlet UIButton *sendFileBtn;
//发送文件
@property (weak, nonatomic) IBOutlet UIView *sendFileView;
@property (weak, nonatomic) IBOutlet UIProgressView *sfProgressView;
@property (weak, nonatomic) IBOutlet UILabel *sfPercenLabel;
@property (weak, nonatomic) IBOutlet UILabel *sfSendedLabel;
@property (weak, nonatomic) IBOutlet UILabel *sfSendCountLabel;
@property (weak, nonatomic) IBOutlet UILabel *sfSpeedLabel;
@property (weak, nonatomic) IBOutlet UILabel *sfRunTimeLabel;
@property (weak, nonatomic) IBOutlet UILabel *totalLabel;
@property (nonatomic, assign) NSInteger data_count;
//服务
@property (nonatomic, strong) NSMutableArray *services;
@property (nonatomic, copy) NSString *serviceUUIDString;
@property (nonatomic, assign) BOOL selectRead;
@property (nonatomic, assign) BOOL selectNotify;
@property (nonatomic, assign) BOOL selectIndicate;
@property (nonatomic, assign) BOOL selectWrite;
@property (nonatomic, assign) BOOL selectWriteWithoutResponse;
@property (nonatomic, assign) BOOL read;
@property (nonatomic, assign) BOOL notify;
@property (nonatomic, assign) BOOL response;
@property (nonatomic, assign) BOOL notify_re;
@property (nonatomic, assign) BOOL priority;
@property (nonatomic, assign) BOOL notify_new;
@property (nonatomic, strong) NSMutableArray *characteristicReceiveArrM;
@property (nonatomic, strong) NSDictionary *advertisementData;
@property (nonatomic, strong) UIActivityIndicatorView * activityIndicator;
@property (nonatomic, strong) MemoryInfo *memoryInfo;
@property (nonatomic, strong) ServiceInfo *serviceInfo;
@property (nonatomic, assign) BOOL shouldPriority;
@property (nonatomic, assign) BOOL isFirst;
@property (nonatomic, assign) BOOL isFirstConnect;
@property (nonatomic, assign) BOOL isBack;
@property (nonatomic, assign) NSInteger chineseCount;
@property (nonatomic, strong) NSTimer *writeDataTimer;
@property (nonatomic, strong) NSMutableData *data_all;
@property (nonatomic, assign) NSInteger packCount;
@property (nonatomic, assign) NSInteger data_recount;
@property (nonatomic, strong) NSMutableData *fileData;
@property (nonatomic, assign) BOOL send_sync;
@property (nonatomic, assign) NSInteger reconnect_count;
@property (nonatomic, assign) BOOL shouldReconnect;
//@property (nonatomic, assign) NSInteger peripherals_type;

// --------------------- MFI -------------------- //
@property(nonatomic) uint32_t totalBytesRead;
//@property(nonatomic, strong) EAAccessory *accessory;
//@property(nonatomic, strong) IBOutlet UILabel *receivedBytesCountLabel;
//@property(nonatomic, strong) IBOutlet UITextField *stringToSendText;
//@property(nonatomic, strong) IBOutlet UITextField *hexToSendText;
//@property (nonatomic, strong) FscEaSessionApi *eaSessionController;

@end

@implementation FECommunicationChatViewController

////////////////////////////////////////////////////  全局变量  ////////////////////////////////////////////////////////
//接收模式
NSInteger sendStata = 0;
NSInteger sendWhenError = 0;//发送错误重试计数
//BOOL isFirstConnect = YES;

//发送文件
NSInteger fileLength = 0;
NSInteger packageCount = 0;
NSInteger sendWitchPlace = 0;
NSData *fileSendingData;
NSUInteger reDataLength = 0;
BOOL isFlashView = NO;
BOOL isReing = NO;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

- (instancetype)initWithAdvertisementData:(NSDictionary *)advertisementData type:(NSInteger)type {
    if (self == [super init]) {
        self.advertisementData = advertisementData;
//        self.peripherals_type = type;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.isClickBack = NO;
    self.isSendBytes = NO;
    self.isBack = NO;
    self.bytesIndex = 0;
    self.data_recount = 0;
    self.reconnect_count = 0;
    self.isIntervalSend = NO;
    self.api = [FscBleCentralApi shareFscBleCentralApi];
    self.api.moduleType = BLEMODULE;
    self.memoryInfo = [MemoryInfo shareMemoryInfo];
    self.memoryInfo.write_select = YES;
    self.memoryInfo.writeResponse = NO;
    self.memoryInfo.writeCharacteristicUUID = nil;
    self.shouldReconnect = YES;
    //调整视图
    if (IsiPhoneX) {
        self.safeLayoutConstraint.constant = NAVIGATIONHEIGHT_iPhoneX+4;
        self.bottomSafeLayoutConstraint.constant = TABBARHEIGHT_iPhoneX;
    }
    // 创建一个使用本来的样式进行渲染的图片
    UIImage *rightImage = [[UIImage imageNamed:@"rssi 5"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    self.rightBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 35, 35)];
    [self.rightBtn setBackgroundImage:rightImage forState:UIControlStateNormal];
    UIView *rView1= [[UIView alloc]initWithFrame:CGRectMake(0, 0, 35, 35)];
    [rView1 addSubview:self.rightBtn];
    UIBarButtonItem *rb_rssi_image = [[UIBarButtonItem alloc] initWithCustomView:rView1];
    self.rightLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 30, 30)];
    UIView *rView2= [[UIView alloc]initWithFrame:CGRectMake(0, 0, 30, 30)];
    [rView2 addSubview:self.rightLabel];
    UIBarButtonItem *rb_rssi_text = [[UIBarButtonItem alloc] initWithCustomView:rView2];
    //在导航栏右侧添加按钮
    self.navigationItem.rightBarButtonItems=@[rb_rssi_image, rb_rssi_text];
    
    self.sendTextView.delegate = self;
    self.intervalTextField.delegate = self;
    self.isStopReViTread = NO;
    self.isClickHexSendSwitch = NO;
    self.isSendingFile = NO;
    self.isConnected = YES;
    self.selectRead = NO;
    self.selectNotify = NO;
    self.selectIndicate = NO;
    self.selectWrite = NO;
    self.selectWriteWithoutResponse = NO;
    self.priority = NO;
    self.response = YES;
    self.shouldPriority = NO;
    self.isFirstConnect = YES;
    reData = [[NSMutableData alloc] init];
    self.characteristicReceiveArrM = [NSMutableArray array];
    self.data_all = [NSMutableData data];
    self.fileData = [NSMutableData data];
    
    [reData setLength:0];
    [[UIApplication sharedApplication] setIdleTimerDisabled:YES];
    [SVProgressHUD showInfoWithStatus:FELocalizedString(@"connected")];
    //读取上一次设置
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    self.hexSend.on = [def boolForKey:@"hexSendSwitch"];
    self.send_sync = [def boolForKey:@"sync"];
    self.rightLabel.hidden = [def boolForKey:@"rightLabelHidden"];
    NSString *intervalText = [def stringForKey:@"intervalTime"];
    self.intervalTextField.text = intervalText.length>0 ? intervalText : FELocalizedString(@"hundred");
    self.crcSe = crc32(0L, Z_NULL, 0);
    crcRe = crc32(0L, Z_NULL, 0);
    self.sendData = [def dataForKey:@"sendData"];
    self.sendTextView.text = self.hexSend.isOn ? [self.sendTextView.text dataToHex:self.sendData] : [self.sendTextView.text dataToUTF8:self.sendData];
    self.servicesArrM = [NSMutableArray array];
    self.serviceUUIDString = [def stringForKey:@"UUIDString"];
    //记录发送字节
    if (!self.hexSend.on) {
        self.textBytesLabel.text = [NSString stringWithFormat:@"%lu",(unsigned long)self.sendTextView.text.length];
    } else {
        //检测字符,找出空格数量
        [self checkBytes];
        self.textBytesLabel.text = [NSString stringWithFormat:@"%lu",(self.sendTextView.text.length-self.bytesIndex)/2];
    }
    //设置代理
    [self setDelegate];
    self.navigationItem.title = [FEShareBt sharedFEShareBt].connetedName;
    //注册通知
    [self setNotification];
    self.changeServicesBtn.userInteractionEnabled = NO;
    NSTimer *timer_reconnect = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(changeReconnect) userInfo:nil repeats:NO];
    
}

#pragma 蓝牙部分
- (void)setDelegate {
    
    __weak typeof(self) weakself = self;
    // 判断蓝牙是否打开
    [self.api isBtEnabled:^(CBCentralManager *central) {
        if (central.state == CBManagerStatePoweredOn) {
            [weakself.api startScan];
        }
    }];
    
    //搜索服务的回调函数
    [self.api servicesFound:^(NSArray<CBService *> *services, NSError *error) {
        for (CBService *service in services) {
            if ([service.UUID.UUIDString isEqualToString:@"FFF0"]) {
                weakself.priority = YES;
                for (CBCharacteristic *c in service.characteristics) {
                    if (c.properties & CBCharacteristicPropertyWriteWithoutResponse) {
                        weakself.response = NO;
                        weakself.shouldPriority = YES;
                    }
                }
            } else if (weakself.priority && !weakself.shouldPriority) {
                for (CBCharacteristic *characteristic in service.characteristics) {
                    if (characteristic.properties & CBCharacteristicPropertyWriteWithoutResponse) {
                        weakself.response = NO;
                    }
                }
            } else {
                for (CBService *s in services) {
                    for (CBCharacteristic *characteristic in s.characteristics) {
                        if (characteristic.properties & CBCharacteristicPropertyWriteWithoutResponse) {
                            weakself.response = NO;
                        }
                    }
                }
            }
            if (![weakself.servicesArrM containsObject:service]) {
                [weakself.servicesArrM addObject:service];
                ServiceInfo *info = [[ServiceInfo alloc] initWithService:service];
                if (![weakself.services containsObject:info]) {
                    [weakself.services addObject:info];
                }
            }
        }
        if (weakself.isFirstConnect) {
            [weakself reflashCharacteristics];
        }
    }];
    
    // 断开连接的回调函数
    [self.api blePeripheralDisonnected:^(CBCentralManager *central, CBPeripheral *peripheral, NSError *error) {
        if (peripheral != weakself.api.peripheral) return;
        if (weakself.reconnect_count < RECONNECT && weakself.shouldReconnect) {
            [weakself.api connect:peripheral];
            weakself.reconnect_count ++;
            NSLog(@"重连");
        } else {
            weakself.isConnected = NO;
            weakself.navigationItem.title = FELocalizedString(@"disconnected");
            [weakself.readRssiTimer invalidate];
            [weakself.rightBtn setBackgroundImage:[UIImage imageNamed:@"rssi 0"] forState:UIControlStateNormal];
            weakself.rightLabel.hidden = YES;
            if (!weakself.isClickBack && !weakself.isBack) {
                UIAlertView *lock =[[UIAlertView alloc]initWithTitle:FELocalizedString(@"disconnected") message:nil delegate:weakself cancelButtonTitle:FELocalizedString(@"ok") otherButtonTitles: nil];
                [lock show];
            }else{
                [SVProgressHUD showInfoWithStatus:FELocalizedString(@"disconnected")];
            }
        }
    }];
    
    // 发送数据成功的回调函数
    [self.api sendCompleted:^(CBCharacteristic *characteristic, NSData *data, NSError *error) {
        dispatch_async(dispatch_queue_create("sendFileConcurrentQueue", DISPATCH_QUEUE_SERIAL), ^{
            isFlashView = YES;
            sendWitchPlace++;
            if (weakself.send_sync && !weakself.isSendingFile) {
                weakself.crcSe = crc32(weakself.crcSe, weakself.sendData.bytes, (uint32_t)weakself.sendData.length);
                weakself.sendByte += weakself.sendData.length;
                weakself.sendedFileCount += weakself.sendData.length;
                weakself.speed_bytesCount += weakself.sendData.length;
                weakself.data_count += weakself.sendData.length;
                weakself.sendPackage++;
                NSString *crcShow = [[NSString alloc] initWithFormat:@"%02lX",weakself.crcSe];
                dispatch_async(dispatch_get_main_queue(),^{
                    weakself.sendByteLabel.text = [NSString stringWithFormat:@"%ld", weakself.sendByte];
                    weakself.sendPackageLabel.text = [NSString stringWithFormat:@"%ld", weakself.sendPackage];
                    weakself.crcSeLabel.text = crcShow;
                    isFlashView = NO;
                    if (weakself.data_count == fileLength) {
                        [weakself stopSendingFile];
                    }
                    [weakself reflashSendFileView:weakself.data_count];
                });
            } else {
                weakself.crcSe = crc32(weakself.crcSe, data.bytes, (uint32_t)data.length);
                weakself.sendByte += data.length;
                weakself.sendedFileCount += data.length;
                weakself.speed_bytesCount += data.length;
                weakself.data_count += data.length;
                weakself.sendPackage++;
                NSString *crcShow = [[NSString alloc] initWithFormat:@"%02lX",weakself.crcSe];
                dispatch_async(dispatch_get_main_queue(),^{
                    weakself.sendByteLabel.text = [NSString stringWithFormat:@"%ld", weakself.sendByte];
                    weakself.sendPackageLabel.text = [NSString stringWithFormat:@"%ld", weakself.sendPackage];
                    weakself.crcSeLabel.text = crcShow;
                    isFlashView = NO;
                    if (weakself.data_count == fileLength) {
                        [weakself stopSendingFile];
                    }
                    [weakself reflashSendFileView:weakself.data_count];
                });
            }
        });
    }];
    
    // 设备返回信息的回调函数
    [self.api packetReceived:^(CBPeripheral *peripheral, CBCharacteristic *characteristic, NSError *error) {
        [NSThread sleepForTimeInterval:0.001];
        reDataLength = reData.length;
        if (reDataLength > 2000){
            [reData setLength:0];
        }
        [reData appendData:characteristic.value];
        NSUInteger reLength = characteristic.value.length;
        reByte += reLength;
        rePackage ++;
        crcRe = crc32(crcRe, characteristic.value.bytes, (uint32_t)reLength);
        isFlashView = YES;
        NSString *stringR = @"";
        stringR = weakself.hexSend.isOn ? [stringR dataToHex:reData] : [stringR dataToUTF8:reData];
        NSString *stringB = [NSString stringWithFormat:@"%ld", reByte];
        NSString *stringP = [NSString stringWithFormat:@"%ld", rePackage];
        NSString *crcShow = [[NSString alloc] initWithFormat:@"%02lX",crcRe];
        weakself.reByteLabel.text = stringB;
        weakself.rePackageLabel.text = stringP;
        weakself.reTextView.text = stringR;
        weakself.crcReLabel.text = crcShow;
        [weakself.reTextView scrollRectToVisible:CGRectMake(0, weakself.reTextView.contentSize.height-15, weakself.reTextView.contentSize.width, 10) animated:YES];
        isFlashView = NO;
    }];
    
    // 读取设备信息的回调函数
    [self.api readResponse:^(CBCharacteristic *characteristic) {
        if (characteristic) {
            if (![weakself.characteristicReceiveArrM containsObject:characteristic] && [characteristic.service.UUID.UUIDString isEqualToString:INFODEVICE]) {
                [weakself.characteristicReceiveArrM addObject:characteristic];
                weakself.memoryInfo.characteristicArray = weakself.characteristicReceiveArrM.copy;
            }
        }
    }];
}

- (void)changeReconnect {
    self.reconnect_count = RECONNECT;
}

#pragma FESendFileTableViewControllerDelegate
-(void)sendFileByData:(NSData *)data sendLength:(NSInteger)length{
    self.sendedFileCount = 0;
    self.speed_bytesCount  = 0;
    self.speed_bytesCount2  = 0;
    self.speed_bytesCount3  = 0;
    self.speed_bytesCount4  = 0;
    self.speed_bytesCount5  = 0;
    self.speed_timeS = 0;
    self.data_count = 0;
    self.sendFileView.hidden = NO;
    self.sfPercenLabel.text = @"0%";
    self.sfSendedLabel.text = @"0";
    self.sfSendCountLabel.text = [NSString stringWithFormat:@"%ld", length];
    self.sfSendedLabel.text = @"0 b/s";
    self.sfSendCountLabel.hidden = NO;
    fileLength = length;
    self.speed_timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(speedTimerGoing) userInfo:nil repeats:YES];//开启速率计时器
    __weak typeof(self) weakself = self;
    dispatch_queue_t q = dispatch_queue_create(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_async(q, ^{
        weakself.isSendingFile = YES;
        dispatch_async(dispatch_get_main_queue(),^{
            weakself.totalLabel.text = FELocalizedString(@"total");
            [weakself.sendFileBtn setTitle:FELocalizedString(@"stopSend") forState:UIControlStateNormal];
        });
        packageCount = ((length-1)/PACKAGE_LENGTH)+1;
        sendWitchPlace = 0;
        sendStata = 1;
        fileSendingData = [data subdataWithRange:NSMakeRange(0, length)];
    });
}

- (void)loadFileData:(NSData *)data {
//        NSLog(@"data = %@",data);
    if (data.length > 0) {
        [self.fileData appendData:data];
        if (self.fileData.length == fileLength) {
            [self sendFile];
            [self.fileData replaceBytesInRange:NSMakeRange(0, self.fileData.length) withBytes:nil length:0];
        } else if (self.fileData.length > fileLength && fileLength != 0) {
            self.fileData = [[self.fileData subdataWithRange:NSMakeRange(0, fileLength)] mutableCopy];
            [self sendFile];
            [self.fileData replaceBytesInRange:NSMakeRange(0, self.fileData.length) withBytes:nil length:0];
        }
    }
}

#pragma FEChangeServiceTableViewControllerDelegate
-(void)noRightCharacteristic{
    [SVProgressHUD showInfoWithStatus:FELocalizedString(@"noRightCharacteristic")];
}
#pragma 控件事件

- (IBAction)clickChangeService:(UIButton *)sender {
    if (self.isSendingFile || (!self.isConnected && self.memoryInfo.index == 0)) return;
    FEChangeServiceTableViewController *changeServiceVC = [FEChangeServiceTableViewController new];
    [self.api stopSend];
    changeServiceVC.services = self.services;
    changeServiceVC.delegate = self;
    changeServiceVC.peripheral = self.api.peripheral;
    changeServiceVC.serviceUUID = self.serviceUUIDString;
    changeServiceVC.priority = self.shouldPriority?self.priority:NO;
    changeServiceVC.characteristicReceiveArray = self.memoryInfo.characteristicArray.copy;
    changeServiceVC.advertisementData = self.advertisementData;
    [self.navigationController pushViewController:changeServiceVC animated:YES];
}

- (IBAction)clearData:(UIButton *)sender {
    reByte = 0;
    rePackage = 0;
    crcRe = 0;
    self.sendByte = 0;
    self.sendPackage = 0;
    self.crcSe = 0;
    self.speed_timeS = 0;
    //清空数据
    [reData setLength:0];
    [self reflashView];
    [self.reDataArr removeAllObjects];
    self.sendByteLabel.text = [NSString stringWithFormat:@"%ld", self.sendByte];
    self.sendPackageLabel.text = [NSString stringWithFormat:@"%ld", self.sendPackage];
    self.sfRunTimeLabel.text = @"00:00:00";
    self.sfBytesRunTimeLabel.text = @"00:00:00";
}

- (IBAction)clickSend:(UIButton *)sender {
    if ([self.sendTextView.text isEqualToString:@""] || !self.isConnected) return;
    [self.api setSendInterval:[self.intervalTextField.text integerValue]];
    [self send];
}

- (IBAction)clickSendFile:(UIButton *)sender {
    if (!self.isConnected) return;
    if (self.isSendingFile) {
        self.isSendingFile = NO;
        self.sfSendCountLabel.hidden = YES;
        self.totalLabel.text = FELocalizedString(@"clickToHidden");
        [self.speed_timer invalidate];
        [self.api stopSend];
        [self.api clearCache];
        [self.sendFileBtn setTitle:FELocalizedString(@"sendFile") forState:UIControlStateNormal];
    }else{
        FESendFileTableViewController *VC = [self.sto instantiateViewControllerWithIdentifier:@"sto_sendFileVC"];
        VC.delegate = self;
        [self.navigationController pushViewController:VC animated:YES];
    }
}


- (IBAction)hexReSwitch:(UISwitch *)sender {
    [[NSUserDefaults standardUserDefaults] setBool:sender.isOn forKey:@"hexReSwitch"];
}

- (IBAction)hexSendSwitch:(UISwitch *)sender {
    [[NSUserDefaults standardUserDefaults] setBool:sender.isOn forKey:@"hexSendSwitch"];
    self.isClickHexSendSwitch = YES;
    self.sendTextView.text = sender.isOn ? [self.sendTextView.text dataToHex:self.sendData] : [self.sendTextView.text dataToUTF8:self.sendData];
}
- (IBAction)intervalSwitch:(UISwitch *)sender {
    self.isSendBytes = YES;
    self.isIntervalSend = YES;
    self.sendBytesPackage = 0;
    if ([self.sendTextView.text isEqualToString:@""]) sender.on = NO;
    if (sender.isOn) {
        if (!self.isConnected) return;
        self.sendButton.userInteractionEnabled = NO;
        self.sendFileBtn.userInteractionEnabled = NO;
        self.intervalTextField.userInteractionEnabled = NO;
        self.changeServicesBtn.userInteractionEnabled = NO;
        self.byte_speed_timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(byteSpeedTimerGoing) userInfo:nil repeats:YES];//开启速率计时器
        if (!self.response && !self.send_sync) {
            [self.api setSendInterval:[self.intervalTextField.text integerValue]];
        }
        self.writeDataTimer = [NSTimer scheduledTimerWithTimeInterval:self.send_sync?[self.intervalTextField.text integerValue]*0.001:0.005 target:self selector:@selector(intervalSend) userInfo:nil repeats:YES];//0.012
    }else{
        self.sendButton.userInteractionEnabled = YES;
        self.sendFileBtn.userInteractionEnabled = YES;
        self.intervalTextField.userInteractionEnabled = YES;
        self.changeServicesBtn.userInteractionEnabled = YES;
        [self.byte_speed_timer invalidate];
        [self.writeDataTimer invalidate];
        self.interval = NO;
        [self.api stopSend];
        [self.api clearCache];
    }
}

- (IBAction)clickResponseSwitch:(UISwitch *)sender {
    [[NSUserDefaults standardUserDefaults] setBool:sender.isOn forKey:@"responseSwitch"];
}

- (void)textViewDidChangeSelection:(UITextView *)textView{
    if (self.isClickHexSendSwitch) {
        self.isClickHexSendSwitch = NO;
        return;
    }
    if (self.hexSend.isOn) {
        self.sendData = [textView.text hexToData];
    }else{
        self.sendData = [textView.text UTF8ToData];
    }
}

#pragma 自己写的方法
// 单次发送
- (void)send {
    dispatch_async(dispatch_queue_create("send", DISPATCH_QUEUE_SERIAL), ^{
        if (self.send_sync) {
            // 同步发送
            [self.api syncSend:self.sendData withResponse:self.response];
        } else {
            // 异步发送
            [self.api send:self.sendData withResponse:self.response withSendStatusBlock:^(NSData *data) {
                
            }];
        }
        if (!self.response) {
            self.crcSe = crc32(self.crcSe, self.sendData.bytes, (uint32_t)self.sendData.length);
            self.sendByte += self.sendData.length;
            self.sendPackage++;
            NSString *crcShow = [[NSString alloc] initWithFormat:@"%02lX",self.crcSe];
            dispatch_async(dispatch_get_main_queue(),^{
                self.sendByteLabel.text = [NSString stringWithFormat:@"%ld", self.sendByte];
                self.sendPackageLabel.text = [NSString stringWithFormat:@"%ld", self.sendPackage];
                self.crcSeLabel.text = crcShow;
            });
        }
    });
}

//循环发送
- (void)intervalSend {
    if (self.send_sync) {
        // 同步发送
        [self.api syncSend:self.sendData withResponse:self.response];
        NSLog(@"停了吗");
        if (!self.response) {
            self.crcSe = crc32(self.crcSe, self.sendData.bytes, (uint32_t)self.sendData.length);
            self.sendByte += self.sendData.length;
            self.sendPackage++;
            self.packCount++;
        }
    } else {
        __weak typeof(self) weakself = self;
        dispatch_async(dispatch_queue_create("send_interval", DISPATCH_QUEUE_SERIAL), ^{
            // 异步发送
            [self.api send:self.sendData withResponse:self.response withSendStatusBlock:^(NSData *data) {
                if (!weakself.response) {
                    weakself.crcSe = crc32(weakself.crcSe, data.bytes, (uint32_t)data.length);
                    weakself.sendByte += data.length;
                    weakself.sendPackage++;
                    weakself.packCount++;
                }
            }];
        });
    }
}

// 发送文件
- (void)sendFile{
    // 清除缓存
    [self.api clearCache];
    if (!self.response) {
        // 设置发送间隔
        [self.api setSendInterval:[self.intervalTextField.text integerValue]];
    }
    __weak typeof(self) weakself = self;
    // 异步发送
    [self.api send:self.fileData withResponse:self.response withSendStatusBlock:^(NSData *data) {
        dispatch_async(dispatch_queue_create("sendFile", DISPATCH_QUEUE_SERIAL), ^{
            if (!weakself.response) {
                isFlashView = YES;
                sendWitchPlace++;
                weakself.crcSe = crc32(weakself.crcSe, data.bytes, (uint32_t)data.length);
                weakself.sendByte += data.length;
                weakself.sendedFileCount += data.length;
                weakself.speed_bytesCount += data.length;
                weakself.data_count += data.length;
                weakself.sendPackage++;
                NSString *crcShow = [[NSString alloc] initWithFormat:@"%02lX",weakself.crcSe];
                dispatch_async(dispatch_get_main_queue(),^{
                    weakself.sendByteLabel.text = [NSString stringWithFormat:@"%ld", weakself.sendByte];
                    weakself.sendPackageLabel.text = [NSString stringWithFormat:@"%ld", weakself.sendPackage];
                    weakself.crcSeLabel.text = crcShow;
                    isFlashView = NO;
                    if (weakself.data_count == fileLength) {
                        [weakself stopSendingFile];
                    }
                    [weakself reflashSendFileView:weakself.data_count];
                });
            }
        });
    }];
}

- (void)reflashIntervalSend {
    dispatch_async(dispatch_queue_create("intervalSend", DISPATCH_QUEUE_SERIAL), ^{
        if (!self.response && self.isIntervalSend) {
            NSString *crcShow = [[NSString alloc] initWithFormat:@"%02lX",(unsigned long)self.crcSe];
            dispatch_async(dispatch_get_main_queue(),^{
                self.sendByteLabel.text = [NSString stringWithFormat:@"%ld", (long)self.sendByte];
                self.sendPackageLabel.text = [NSString stringWithFormat:@"%ld", (long)self.sendPackage];
                self.crcSeLabel.text = crcShow;
            });
        }
    });
}

- (void)stopSendingFile{
    [self.speed_timer invalidate];
    sendStata = 0;
    self.isSendingFile = NO;
    dispatch_async(dispatch_get_main_queue(),^{
        self.sfSendCountLabel.hidden = YES;
        self.totalLabel.text = FELocalizedString(@"clickToHidden");
        [self.sendFileBtn setTitle:FELocalizedString(@"sendFile") forState:UIControlStateNormal];
        self.sfSpeedLabel.text = [NSString stringWithFormat:@"%ld b/s",  self.sendedFileCount / self.speed_timeS];
    });
}


-(void)reflashSendFileView:(NSInteger)length{
    dispatch_async(dispatch_get_main_queue(),^{
        [self.sfProgressView setProgress:(double)length / (double)fileLength animated:NO];
        self.sfPercenLabel.text = [NSString stringWithFormat:@"%.1f %%", self.sfProgressView.progress * 100.0];
        self.sfSendedLabel.text = [NSString stringWithFormat:@"%ld", self.sendedFileCount];
    });
}

-(void)speedTimerGoing{
    if (0 == self.speed_bytesCount5) {
        self.speed_bytesCount2 = self.speed_bytesCount;
        self.speed_bytesCount3 = self.speed_bytesCount;
        self.speed_bytesCount4 = self.speed_bytesCount;
        self.speed_bytesCount5 = self.speed_bytesCount;
    }
    //    NSLog(@"秒%ld",self.speed_timeS);
    self.speed_timeS ++;
    dispatch_async(dispatch_get_main_queue(),^{
        NSInteger totalCount = self.speed_bytesCount + self.speed_bytesCount2 + self.speed_bytesCount3 + self.speed_bytesCount4 + self.speed_bytesCount5;
        self.sfSpeedLabel.text = [NSString stringWithFormat:@"%ld b/s", totalCount / 5];
        self.speed_bytesCount2 = self.speed_bytesCount;
        self.speed_bytesCount3 = self.speed_bytesCount2;
        self.speed_bytesCount4 = self.speed_bytesCount3;
        self.speed_bytesCount5 = self.speed_bytesCount4;
        self.speed_bytesCount = 0;
        self.sfRunTimeLabel.text = [self secondToTime:self.speed_timeS];
    });
}

- (void)byteSpeedTimerGoing {
    //    NSLog(@"秒%ld",self.speed_timeS);
    self.speed_timeS ++;
    dispatch_async(dispatch_get_main_queue(),^{
        self.sfBytesRunTimeLabel.text = [self secondToTime:self.speed_timeS];
    });
}

- (NSString *)secondToTime:(NSInteger)second{
    return [NSString stringWithFormat:@"%02ld:%02ld:%02ld",second / 3600, (second % 3600) / 60, second%60];
}

-(void)reflashView{
    dispatch_sync(dispatch_queue_create("readConcurrentQueue", DISPATCH_QUEUE_SERIAL), ^{
        //        NSLog(@"最后刷新界面");
        NSString *stringR = @"";
        stringR = self.hexSend.isOn ? [stringR dataToHex:reData] : [stringR dataToUTF8:reData];
        NSString *stringB = [NSString stringWithFormat:@"%ld", reByte];
        NSString *stringP = [NSString stringWithFormat:@"%ld", rePackage];
        NSString *crcShow = [[NSString alloc] initWithFormat:@"%02lX",crcRe];
        NSString *crcSend = [[NSString alloc] initWithFormat:@"%02lX",self.crcSe];
        dispatch_async(dispatch_get_main_queue(),^{
            self.reByteLabel.text = stringB;
            self.rePackageLabel.text = stringP;
            self.reTextView.text = stringR;
            self.crcReLabel.text = crcShow;
            self.crcSeLabel.text = crcSend;
            [self.reTextView scrollRectToVisible:CGRectMake(0, self.reTextView.contentSize.height-15, self.reTextView.contentSize.width, 10) animated:YES];
        });
    });
}

//弹框
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 0) return;
}


#pragma mark - notification
- (void)setNotification {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(notificationChangeService:) name:NOTIFICATIONCHANGECHARACTERISTICS object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(notificationRead:) name:NOTIFICATIONREAD object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(notificationNotify:) name:NOTIFICATIONNOTIFY object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(notificationIndicate:) name:NOTIFICATIONINDICATE object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(notificationWrite:) name:NOTIFICATIONWRITE object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(notificationWriteWithoutResponse:) name:NOTIFICATIONWRITEWITHOUTRESPONSE object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(notificationUpdateCharacteristic:) name:NOTIFICATIONUPDATECHARACTERISTICS object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(notificationChangeMtu:) name:NOTIFICATIONCHANGEMTU object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(notificationSync:) name:NOTIFICATIONSYNC object:nil];
}
- (void)notificationChangeService:(NSNotification *)noti {
    self.priority = NO;
    NSString *str = noti.userInfo[@"characteristic"];
    for (ServiceInfo *info in self.services) {
        for (CBCharacteristic *characteristic in info.service.characteristics) {
            if ([str isEqualToString:characteristic.UUID.UUIDString]) {
                self.serviceUUIDString = info.service.UUID.UUIDString;
                NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
                [userDefaults setValue:info.service.UUID.UUIDString forKey:@"UUIDString"];
            }
        }
    }
}
- (void)notificationUpdateCharacteristic:(NSNotification *)noti {
    NSArray *characteristics = noti.userInfo[@"characteristics"];
    for (CBCharacteristic *characteristic in characteristics) {
        [self.api read:characteristic];
    }
}
- (void)notificationRead:(NSNotification *)noti {
    self.selectRead = YES;
    CBCharacteristic *characteristic = noti.userInfo[@"characteristic"];
    [self.api read:characteristic];
}
- (void)notificationNotify:(NSNotification *)noti {
    self.selectNotify = YES;
    self.selectIndicate = NO;
    NSString *serviceUUID = noti.userInfo[@"serviceUUID"];
    NSString *characteristicUUID = noti.userInfo[@"characteristicUUID"];
    self.notify_new = [noti.userInfo[@"notify"] integerValue];
    [self.api setCharacteristic:serviceUUID withCharacteristicUUID:characteristicUUID withNotify:self.notify_new infoBlock:^(BOOL result) {
        //        NSLog(@"result = %d",result);
    }];
}
- (void)notificationIndicate:(NSNotification *)noti {
    self.selectIndicate = YES;
    self.selectNotify = NO;
    NSString *serviceUUID = noti.userInfo[@"serviceUUID"];
    NSString *characteristicUUID = noti.userInfo[@"characteristicUUID"];
    self.notify_new = [noti.userInfo[@"indicate"] integerValue];
    [self.api setCharacteristic:serviceUUID withCharacteristicUUID:characteristicUUID withNotify:self.notify_new infoBlock:^(BOOL result) {
        //        NSLog(@"result = %d",result);
    }];
}
- (void)notificationWrite:(NSNotification *)noti {
    self.response = noti.userInfo[@"write"];
    NSString *serviceUUID = noti.userInfo[@"serviceUUID"];
    NSString *characteristicUUID = noti.userInfo[@"characteristicUUID"];
    [self.api setCharacteristic:serviceUUID withCharacteristicUUID:characteristicUUID withNotify:self.notify_new infoBlock:^(BOOL result) {
        //        NSLog(@"result = %d",result);
    }];
}
- (void)notificationWriteWithoutResponse:(NSNotification *)noti {
    self.response = !(noti.userInfo[@"write_without"]);
    NSString *serviceUUID = noti.userInfo[@"serviceUUID"];
    NSString *characteristicUUID = noti.userInfo[@"characteristicUUID"];
    [self.api setCharacteristic:serviceUUID withCharacteristicUUID:characteristicUUID withNotify:self.notify_new infoBlock:^(BOOL result) {
        //        NSLog(@"result = %d",result);
    }];
}

- (void)notificationChangeMtu:(NSNotification *)noti {
    NSInteger value = [noti.userInfo[@"mtu"] integerValue];
    [self.api setAttMtu:value];
}

- (void)notificationSync:(NSNotification *)noti {
    BOOL sync = [noti.userInfo[@"sync"] intValue];
    self.send_sync = sync;
}

- (void)reflashCharacteristics {
    for (ServiceInfo *info in self.services) {
        if ([info.service.UUID.UUIDString isEqualToString:@"180A"]) {
            for (CBCharacteristic *characteristic in info.service.characteristics) {
                //                NSLog(@"走了几次");
                [self.api read:characteristic];
            }
        }
    }
}

#pragma mark - UITextFieldDelegate
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    if ([textField.text integerValue]*10+[string integerValue] >= 65535) {
        if ([string isEqualToString:@""]) {
            return YES;
        }
        if ([textField.text isEqualToString:@"6553"] && [string isEqualToString:@"5"]) {
            return YES;
        }
        return NO;
    } else {
        return YES;
    }
}
#pragma mark - UITextViewDelegate
- (void)textViewDidChange:(UITextView *)textView {
    self.bytesIndex = 0;
    self.chineseCount = 0;
    [self checkBytes];
    if (!self.hexSend.on) {
        self.textBytesLabel.text = [NSString stringWithFormat:@"%d",textView.text.length+self.chineseCount*2];
    } else {
        self.textBytesLabel.text = [NSString stringWithFormat:@"%d",(textView.text.length-self.bytesIndex)/2];
    }
}
//输入框空格检测
- (void)checkBytes {
    for (int i = 0; i < self.sendTextView.text.length; i++) {
        if ([[self.sendTextView.text substringWithRange:NSMakeRange(i, 1)] isEqualToString:@" "]) {
            self.bytesIndex++;
        }
        //判断是否有中文
        int a = [self.sendTextView.text characterAtIndex:i];
        if(a > 0x4e00 && a < 0x9fff) {
            self.chineseCount++;
        }
    }
}
//- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
//    if (self.hexSend.on) {
//        if ([self isHexString:text]) {
//            return YES;
//        } else {
//            return NO;
//        }
//    } else {
//        return YES;
//    }
//}
//检查输入的是否为16进制(不分大小写)
- (BOOL)isHexString:(NSString *)string {
    if ([string isEqualToString:@"A"]) {
        return YES;
    } else if ([string isEqualToString:@"B"]) {
        return YES;
    } else if ([string isEqualToString:@"C"]) {
        return YES;
    } else if ([string isEqualToString:@"D"]) {
        return YES;
    } else if ([string isEqualToString:@"E"]) {
        return YES;
    } else if ([string isEqualToString:@"F"]) {
        return YES;
    } else if ([string isEqualToString:@"a"]) {
        return YES;
    } else if ([string isEqualToString:@"b"]) {
        return YES;
    } else if ([string isEqualToString:@"c"]) {
        return YES;
    } else if ([string isEqualToString:@"d"]) {
        return YES;
    } else if ([string isEqualToString:@"e"]) {
        return YES;
    } else if ([string isEqualToString:@"f"]) {
        return YES;
    } else if ([string isEqualToString:@"0"]) {
        return YES;
    } else if ([string isEqualToString:@"1"]) {
        return YES;
    } else if ([string isEqualToString:@"2"]) {
        return YES;
    } else if ([string isEqualToString:@"3"]) {
        return YES;
    } else if ([string isEqualToString:@"4"]) {
        return YES;
    } else if ([string isEqualToString:@"5"]) {
        return YES;
    } else if ([string isEqualToString:@"6"]) {
        return YES;
    } else if ([string isEqualToString:@"7"]) {
        return YES;
    } else if ([string isEqualToString:@"8"]) {
        return YES;
    } else if ([string isEqualToString:@"9"]) {
        return YES;
    } else if ([string isEqualToString:@""]){
        return YES;
    } else {
        return NO;
    }
}

//右滑断开连接
- (void)didMoveToParentViewController:(UIViewController*)parent{
    [super didMoveToParentViewController:parent];
    //    NSLog(@"%s,%@",__FUNCTION__,parent);
    if(!parent){
        self.isBack = YES;
        self.shouldReconnect = NO;
        NSLog(@"右滑断开");
        [self.api disconnect];
    }
}

#pragma mark - 键盘配置
//第三种键盘弹起方法（调整view的约束）
//键盘弹出设置
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    //    self.navigationController.navigationBarHidden = NO;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showKeyboard:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(closeKeyboard:) name:UIKeyboardWillHideNotification object:nil];
    self.intervalSendTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reflashIntervalSend) userInfo:nil repeats:YES];
    
}
-(void)showKeyboard:(NSNotification *)notification{
    // 读取userInfo中的动画种类
    NSInteger option = [notification.userInfo[UIKeyboardAnimationCurveUserInfoKey] integerValue];
    // 读取userInfo中的动画时长
    NSTimeInterval duration = [notification.userInfo[UIKeyboardAnimationDurationUserInfoKey] floatValue];
    // 获取弹起的键盘的frame中的左顶点位置的y
    CGFloat height = [notification.userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue].size.height;
    self.layout_bottom.constant = height;
    [UIView animateWithDuration:duration delay:0 options:option animations:^{
        [self.view layoutIfNeeded];
    } completion:nil];
}
-(void)closeKeyboard:(NSNotification *)notification{
    if (IsiPhoneX) {
        self.layout_bottom.constant = TABBARHEIGHT_iPhoneX;
    } else {
        self.layout_bottom.constant = 0;
    }
    [self.view layoutIfNeeded];
}
//键盘收回设置
-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    if (self.isSendingFile && !self.speed_timer.isValid) {
        self.speed_timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(speedTimerGoing) userInfo:nil repeats:YES];//开启速率计时器
    }
    self.isStopReViTread = NO;
    [self.reflashViewThread start];
    //清空特征数组
    //    [self.characteristicReceiveArrM removeAllObjects];
    dispatch_async(dispatch_queue_create("delay", DISPATCH_QUEUE_SERIAL), ^{
        [NSThread sleepForTimeInterval:1];
        dispatch_async(dispatch_get_main_queue(), ^{
            //            NSLog(@"2先走");
            self.changeServicesBtn.userInteractionEnabled = YES;
        });
    });
}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    if (self.isSendingFile) [self.speed_timer invalidate];
    self.isStopReViTread = YES;
    [self.readRssiTimer invalidate];
    [self.writeDataTimer invalidate];
    [self.byte_speed_timer invalidate];
    [self.intervalSendTimer invalidate];
    [self.intervalSendThread cancel];
    self.interval = NO;
    [self.api stopSend];
    [self.api clearCache];
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.sendTextView resignFirstResponder];
    [self.intervalTextField resignFirstResponder];
    for (UITouch *touch in touches) {
        if (touch.view == self.sendFileView && [self.totalLabel.text isEqualToString:FELocalizedString(@"clickToHidden")]) {
            self.sendFileView.hidden = YES;
        }
    }
}

-(NSMutableArray *)services{
    if (!_services) {
        _services = [NSMutableArray array];
    }
    return _services;
}

-(NSMutableArray *)reDataArr{
    if (!_reDataArr) {
        _reDataArr = [NSMutableArray array];
    }
    return _reDataArr;
}

- (void)dealloc{
    NSLog(@"注销通知");
    self.isFirstConnect = NO;
    reByte = 0;
    rePackage = 0;
    crcRe = 0;
    self.memoryInfo.index = 0;
    self.memoryInfo.firstConnect = YES;
    [[NSNotificationCenter defaultCenter] removeObserver:self];
//    [[FscEaSessionApi sharedFscEaSessionApi] disconnect];
}

-(NSString *)fan_dataToHexString:(NSData *)data{
    Byte *bytehex =(Byte *) data.bytes;
    NSMutableString *hexString=[[NSMutableString alloc]init];
    for (int i=0; i<data.length; i++) {
        Byte b=bytehex[i];
        [hexString appendFormat:@"%02x",b];
    }
    return hexString;
}

- (BOOL)navigationShouldPopOnBackButton {
    //    NSLog(@"-------------");
    self.isClickBack = YES;
    self.shouldReconnect = NO;
    [self.api disconnect];
    NSLog(@"返回断开");
    [[NSUserDefaults standardUserDefaults] setValue:self.sendData forKey:@"sendData"];
    [[NSUserDefaults standardUserDefaults] setValue:self.intervalTextField.text forKey:@"intervalTime"];
    return YES;
}


@end

