//
//  FECommunicationChatViewController.h
//  FeasycomLE
//
//  Created by 余明悦 on 16/7/20.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <ExternalAccessory/ExternalAccessory.h>
//#import <CoreBluetooth/CoreBluetooth.h>
#import "FEShareBt.h"
//#import "FeasycomLE/FBPeripheralItem.h"
#import "FscBleCentralApi.h"
@interface FECommunicationChatViewController : UIViewController
@property (nonatomic, strong) UIStoryboard *sto;
//中心管理者
@property (nonatomic, strong) FscBleCentralApi *api;
@property(nonatomic, strong) EAAccessory *accessory;

- (instancetype)initWithAdvertisementData:(NSDictionary *)advertisementData type:(NSInteger)type;

@end

