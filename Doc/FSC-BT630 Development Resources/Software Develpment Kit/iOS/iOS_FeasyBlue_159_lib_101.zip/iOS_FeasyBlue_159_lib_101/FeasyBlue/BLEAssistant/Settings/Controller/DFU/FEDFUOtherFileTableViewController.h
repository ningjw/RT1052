//
//  FEDFUOtherFileTableViewController.h
//  BLEAssistant
//
//  Created by yumingyue on 2016/11/22.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import <UIKit/UIKit.h>
@class FEDFUOtherFileTableViewController;
@protocol FEDFUOtherFileTableViewControllerDelegate <NSObject>
-(void)selectFirmwareUrl:(NSURL *)url;
@optional //可选实现

@end

@interface FEDFUOtherFileTableViewController : UITableViewController
@property(nonatomic,weak)id<FEDFUOtherFileTableViewControllerDelegate> delegate;

@end
