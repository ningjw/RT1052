//
//  UIColor+FEColor.h
//  BLEAssistant
//
//  Created by ericj on 2018/6/6.
//  Copyright © 2018年 feasycom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (FEColor)

+ (UIColor *)colorWithHexString:(NSString *)color;

@end
