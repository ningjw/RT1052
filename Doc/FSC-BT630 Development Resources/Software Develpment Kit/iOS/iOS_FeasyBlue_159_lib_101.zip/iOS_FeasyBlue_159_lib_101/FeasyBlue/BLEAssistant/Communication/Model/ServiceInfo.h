//
//  PeripheralInfo.h
//  BabyBluetoothAppDemo
//
//  Created by 刘彦玮 on 15/8/6.
//  Copyright (c) 2015年 刘彦玮. All rights reserved.
//

#define IsiPhoneX ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1125, 2436), [[UIScreen mainScreen] currentMode].size) : NO)
#define NAVIGATIONHEIGHT_iPhoneX 88
#define NAVIGATIONHEIGHT         64
#define TABBARHEIGHT_iPhoneX     84
#define TABBARHEIGHT             49

#define NOTIFICATIONREAD                        @"notificationRead"
#define NOTIFICATIONNOTIFY                      @"notificationNotify"
#define NOTIFICATIONINDICATE                    @"notificationIndicate"
#define NOTIFICATIONWRITE                       @"notification"
#define NOTIFICATIONWRITEWITHOUTRESPONSE        @"notificationWriteWithoutResponse"
#define NOTIFICATIONCHANGESERVICE               @"notificationChangeService"
#define NOTIFICATIONCHANGECHARACTERISTICS       @"notificationChangeCharacteristics"
#define NOTIFITATIONREADCHARACTERISTICVALUE     @"notifitationReadCharacteristicValue"
#define NOTIFICATIONCHARACTERISTICCOMPARE       @"notificationCharacteristicCompare"
#define NOTIFICATIONUPDATECHARACTERISTICS       @"notificationUpdateCharacteristics"
#define NOTIFICATIONRECEIVECHARACTERISTICVALUE  @"notificationReceiveCharacteristicValue"
#define NOTIFICATIONCHANGEMTU                   @"notificationChangeMtu"
#define NOTIFICATIONSTARTOTAUPDATE              @"notificationOTAUpdate"
#define NOTIFICATIONURL                         @"notificationUrl"
#define NOTIFICATIONFILENAME                    @"notificationFileName"
#define NOTIFICATIONSYNC                        @"notificationSync"

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

@interface ServiceInfo : NSObject

@property (nonatomic,strong) CBService *service;
@property (nonatomic,strong) NSMutableArray *characteristicArrayM;
@property (nonatomic,strong) NSMutableArray *notifyArrM;
@property (nonatomic,strong) NSMutableArray *readCharacteristics;
@property (nonatomic,strong) NSMutableArray *readNoReCharacteristics;
@property (nonatomic,strong) NSMutableArray *writeCharacteristics;
@property (nonatomic,strong) NSMutableArray *writeNoReCharacteristics;
@property (nonatomic,strong) NSArray *characteristics;

- (id)initWithService:(CBService*)service;
- (void)reflashCharacteristics;
@end
