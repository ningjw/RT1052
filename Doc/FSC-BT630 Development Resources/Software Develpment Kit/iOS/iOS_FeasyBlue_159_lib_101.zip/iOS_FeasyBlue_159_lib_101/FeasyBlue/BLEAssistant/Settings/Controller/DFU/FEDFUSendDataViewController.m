//
//  FEDFUSendDataViewController.m
//  BLEAssistant
//
//  Created by ericj on 2017/12/14.
//  Copyright © 2017年 feasycom. All rights reserved.
//


#import "FEDFUSendDataViewController.h"
#import "Masonry.h"
#import "XLCircleProgress.h"
#import "NSString+FEString.h"

@interface FEDFUSendDataViewController ()//<FEBluetoothDelegate>
@property (nonatomic, copy) NSString *fileName;
@property (nonatomic, strong) FscBleCentralApi *api;
@property (nonatomic, strong) XLCircleProgress *circle;
@property (nonatomic, weak) UILabel *updateLabel;
@property (nonatomic, strong) CBPeripheral *peripheral;
@property (nonatomic, assign) CGFloat progress;

@end

@implementation FEDFUSendDataViewController
- (instancetype)initWithFileName:(NSString *)fileName withPeripheral:(CBPeripheral *)peripheral {
    if (self = [super init]) {
        self.fileName = fileName;
        self.peripheral = peripheral;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
//    self.api = [FscBleCentralApi defaultFscBleCentralApi];
    //设置类型
    self.api.moduleType = BLEMODULE;
    [self setDelegate];
    [self setupUI];
    //连接
    [self.api connect:self.peripheral];
}

- (void)viewWillDisappear:(BOOL)animated {
    self.api = nil;
    [super viewWillDisappear:animated];
}

- (void)setDelegate {
    
    [self.api isBtEnabled:^(CBCentralManager *central) {
        NSLog(@"蓝牙打开");
    }];
    
    __weak typeof(self) weakself = self;
    [self.api packetReceived:^(CBPeripheral *peripheral, CBCharacteristic *characteristic, NSError *error) {
        
    }];
    
    [self.api blePeripheralConnected:^(CBCentralManager *central, CBPeripheral *peripheral) {
        //升级
        [weakself.api startOTA:self.fileName withRestoreDefaultSettings:self.restore];
    }];
    
    [self.api otaProgressUpdate:^(CGFloat percentage, int status) {
        NSLog(@"%f",percentage);
        weakself.progress = percentage;
        [weakself updateStatistics];
    }];
    
}


- (void)updateStatistics {
    self.circle.progress = self.progress;
    self.updateLabel.text = [NSString stringWithFormat:@"%.2f%@",self.progress*100.0,@"%"];
}

- (void)setupUI {
    self.view.backgroundColor = [UIColor whiteColor];
    //进度图
    self.circle = [[XLCircleProgress alloc] initWithFrame:CGRectMake(self.view.frame.size.width/2.0-100, 200, 200, 200)];
    [self.view addSubview:self.circle];
    UILabel *updateLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.view.frame.size.width/2.0-100, 200, 200, 200)];
    updateLabel.font = [UIFont systemFontOfSize:40];
    updateLabel.textAlignment = NSTextAlignmentCenter;
    updateLabel.text = @"0.00%";
    [self.view addSubview:updateLabel];
    self.updateLabel = updateLabel;
    
}


@end
