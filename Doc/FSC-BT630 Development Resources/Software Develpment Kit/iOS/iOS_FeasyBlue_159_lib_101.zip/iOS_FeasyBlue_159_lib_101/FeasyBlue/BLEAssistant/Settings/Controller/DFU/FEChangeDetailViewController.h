//
//  FEChangeDetailViewController.h
//  BLEAssistant
//
//  Created by ericj on 2018/2/8.
//  Copyright © 2018年 feasycom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FEChangeDetailViewController : UIViewController

@property (nonatomic, strong) NSArray *commandsArray;

@property (nonatomic, copy) NSString *peripheralString;

@property (nonatomic, copy) NSString *name;

@end
