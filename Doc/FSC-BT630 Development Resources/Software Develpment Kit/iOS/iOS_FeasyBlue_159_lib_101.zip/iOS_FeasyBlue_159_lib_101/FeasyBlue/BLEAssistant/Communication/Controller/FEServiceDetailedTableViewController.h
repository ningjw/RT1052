//
//  FEServiceDetailedTableViewController.h
//  BLEAssistant
//
//  Created by ericj on 2018/1/8.
//  Copyright © 2018年 feasycom. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ServiceInfo.h"

@interface FEServiceDetailedTableViewController : UITableViewController
@property (nonatomic, strong) NSArray *services;
@property (nonatomic, assign) BOOL priority;
@property (nonatomic, copy) void(^saveCharacteristicBlock)(NSString *string);
@property (nonatomic, copy) NSString *characteristicUUID;
@property (nonatomic, copy) NSString *characteristic_UUID_new;

- (id)initWithServiceUUID:(NSString *)serviceUUID withCharacteristic:(CBCharacteristic *)characteristic;

@end
