//
//  FEFilterModel.m
//  BLEAssistant
//
//  Created by ericj on 2018/6/13.
//  Copyright © 2018年 feasycom. All rights reserved.
//

#import "FEFilterModel.h"

@implementation FEFilterModel

@end
