//
//  FEDFUUpdateDetailViewController.m
//  BLEAssistant
//
//  Created by ericj on 2018/1/26.
//  Copyright © 2018年 feasycom. All rights reserved.
//

#define NAVIGATIONHEIGHT 64
#define IPHONEXNAVIGATIONHEIGHT 88
#define TABBARHEIGHT 49
#define IPHONEXTABBARHEIGHT 83
#define IsiPhoneX ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1125, 2436), [[UIScreen mainScreen] currentMode].size) : NO)

#import "FEDFUUpdateDetailViewController.h"
#import "Masonry.h"
#import "FEDFUOtherFileTableViewController.h"
#import "FEDFUSelectionListTableViewController.h"
#import "FEDFUSendDataViewController.h"
#import "FscBleCentralApi.h"
#import "ServiceInfo.h"
#import "FEDFUFileTableViewController.h"

@interface FEDFUUpdateDetailViewController ()

@property (nonatomic, copy) NSString *fileName;
@property (nonatomic, weak) UILabel *updateLabel;
@property (nonatomic, weak) UILabel *updateProgressLabel;
@property (nonatomic, weak) UIProgressView *progressView;
@property (nonatomic, weak) UILabel *fileNameLabel;
@property (nonatomic, weak) UILabel *updateModuleLabel;
@property (nonatomic, weak) UILabel *updateAppLabel;
@property (nonatomic, weak) UILabel *updateBlLabel;
@property (nonatomic, weak) UILabel *moduleNameLabel;
@property (nonatomic, weak) UISwitch *restoreSwitch;
@property (nonatomic, strong) CBPeripheral *peripheral;
@property (nonatomic, strong) FscBleCentralApi *api;
@property (nonatomic, weak) UIButton *otaUpdateButton;
@property (nonatomic, weak) UIButton *selectFileButton;
@property (nonatomic, strong) NSDictionary *infoDict;
@property (nonatomic, copy) NSString *file;
@property (nonatomic, assign) BOOL isUpdating;

@end

@implementation FEDFUUpdateDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.isUpdating = NO;
    
    self.navigationItem.title = FELocalizedString(@"firmwareUpgrade");
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:FELocalizedString(@"back") style:UIBarButtonItemStylePlain target:nil action:nil];
    self.api = [FscBleCentralApi defaultFscBleCentralApi];
    self.api.moduleType = BLEMODULE;
    [self setupUI];
    [self setDelegate];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(startOTAUpdate) name:NOTIFICATIONSTARTOTAUPDATE object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getFilePath:) name:NOTIFICATIONURL object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getLocalFileName:) name:NOTIFICATIONFILENAME object:nil];
}

- (void)getFilePath:(NSNotification *)noti {
    NSString *str = noti.userInfo[@"url"];
    NSArray *arr = [str componentsSeparatedByString:@"/"];
    self.file = arr.lastObject;
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    [def setValue:arr.lastObject forKey:@"fileName"];
    if ([str hasSuffix:@".bin"]) {
        self.fileName = str;
        self.infoDict = [self.api checkDfuFile:str];
    }
    [self reflashView];
}

- (void)getLocalFileName:(NSNotification *)noti {
    NSString *str = noti.userInfo[@"fileName"];
    self.fileName = str;
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    self.updateProgressLabel.text = @"0%";
    self.progressView.progress = 0.0f;
    self.updateLabel.text = FELocalizedString(@"waitForTheUpgrade");
}

// 设置代理
- (void)setDelegate {
    
    __weak typeof(self) weakself = self;
    // 升级进度回调函数
    [self.api otaProgressUpdate:^(CGFloat percentage, int status) {
        if (percentage >= 0 && percentage <= 1) {
            [weakself updateStatistics:percentage];
        }
    }];
    
    [self.api blePeripheralDisonnected:^(CBCentralManager *central, CBPeripheral *peripheral, NSError *error) {
        NSLog(@"断开连接");
        if ((int)weakself.progressView.progress != 1) {
            weakself.updateLabel.text = FELocalizedString(@"updateFailed");
            weakself.updateLabel.textColor = [UIColor redColor];
            weakself.selectFileButton.userInteractionEnabled = YES;
            weakself.restoreSwitch.userInteractionEnabled = YES;
            weakself.otaUpdateButton.userInteractionEnabled = YES;
        }
        weakself.selectFileButton.userInteractionEnabled = YES;
        weakself.restoreSwitch.userInteractionEnabled = YES;
        weakself.otaUpdateButton.userInteractionEnabled = YES;
    }];
}

- (void)disconnectPeripheral {
    if (!self.isUpdating) {
        self.updateLabel.text = FELocalizedString(@"updateFailed");
        self.updateLabel.textColor = [UIColor redColor];
        self.selectFileButton.userInteractionEnabled = YES;
        self.restoreSwitch.userInteractionEnabled = YES;
        self.otaUpdateButton.userInteractionEnabled = YES;
    }
}

- (void)startOTAUpdate {
    self.updateLabel.hidden = NO;
    self.updateProgressLabel.hidden = NO;
    self.progressView.hidden = NO;
    self.selectFileButton.userInteractionEnabled = NO;
    self.restoreSwitch.userInteractionEnabled = NO;
    self.otaUpdateButton.userInteractionEnabled = NO;
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(disconnectPeripheral) userInfo:nil repeats:NO];
    self.updateLabel.textColor = [UIColor blackColor];
    [self.api startOTA:self.fileName withRestoreDefaultSettings:self.restoreSwitch.on];
}

- (void)updateStatistics:(CGFloat)progress {
    self.progressView.progress = progress;
    self.isUpdating = YES;
    NSLog(@"progress = %f",progress);
    if ((int)progress == 1) {
        self.updateLabel.text = FELocalizedString(@"updateCompleted");
        self.selectFileButton.userInteractionEnabled = YES;
        self.restoreSwitch.userInteractionEnabled = YES;
        self.otaUpdateButton.userInteractionEnabled = YES;
    } else {
        self.updateLabel.text = FELocalizedString(@"updating");
    }
    self.updateProgressLabel.text = [NSString stringWithFormat:@"%.f%@",progress*100.0,@"%"];
}

// 升级界面设置
- (void)setupUI {
    
    self.view.backgroundColor = [UIColor whiteColor];
    UILabel *updateProgressL = [self createLabelWithText:FELocalizedString(@"waitForTheUpgrade") withFontOfSize:14];
    [self.view addSubview:updateProgressL];
    UILabel *progressL = [self createLabelWithText:@"0%" withFontOfSize:14];
    [self.view addSubview:progressL];
    UIProgressView *progressV = [[UIProgressView alloc] init];
    [self.view addSubview:progressV];
    
    UIButton *filebButton = [[UIButton alloc] init];
    [filebButton setBackgroundImage:[UIImage imageNamed:@"button"] forState:UIControlStateNormal];
    [filebButton setTitle:FELocalizedString(@"selectFirmware") forState:UIControlStateNormal];
    filebButton.titleLabel.font = [UIFont systemFontOfSize:14];
    [self.view addSubview:filebButton];
    [filebButton addTarget:self action:@selector(clickToSelectFile:) forControlEvents:UIControlEventTouchUpInside];
    filebButton.adjustsImageWhenHighlighted = NO;
    
    UILabel *fileLabel = [self createLabelWithText:FELocalizedString(@"selectedFirmware") withFontOfSize:14];
    [self.view addSubview:fileLabel];
    UILabel *nameLabel = [self createLabelWithText:FELocalizedString(@"unselectedFirmware") withFontOfSize:14];
    nameLabel.numberOfLines = 0;
    [self.view addSubview:nameLabel];
    UILabel *currentLabel = [self createLabelWithText:FELocalizedString(@"currentModule") withFontOfSize:14];
    [self.view addSubview:currentLabel];
    UILabel *updateFileLabel = [self createLabelWithText:FELocalizedString(@"upgradeFirmware") withFontOfSize:14];
    [self.view addSubview:updateFileLabel];
    UILabel *appVersionLabel = [self createLabelWithText:FELocalizedString(@"appVersion") withFontOfSize:14];
    [self.view addSubview:appVersionLabel];
    UILabel *blLabel = [self createLabelWithText:FELocalizedString(@"blVersion") withFontOfSize:14];
    [self.view addSubview:blLabel];
    UILabel *moduleLabel = [self createLabelWithText:FELocalizedString(@"model") withFontOfSize:14];
    [self.view addSubview:moduleLabel];
    UILabel *currentModuleLabel = [self createLabelWithText:@"-" withFontOfSize:14];
    [self.view addSubview:currentModuleLabel];
    UILabel *currentAPPLabel = [self createLabelWithText:@"-" withFontOfSize:14];
    [self.view addSubview:currentAPPLabel];
    UILabel *currentBlLabel = [self createLabelWithText:@"-" withFontOfSize:14];
    [self.view addSubview:currentBlLabel];
    UILabel *fileModuleLabel = [self createLabelWithText:@"-" withFontOfSize:14];
    [self.view addSubview:fileModuleLabel];
    UILabel *fileAPPLabel = [self createLabelWithText:@"-" withFontOfSize:14];
    [self.view addSubview:fileAPPLabel];
    UILabel *fileBlLabel = [self createLabelWithText:@"-" withFontOfSize:14];
    [self.view addSubview:fileBlLabel];
    
    UIButton *updateButton = [[UIButton alloc] init];
    [updateButton setTitle:FELocalizedString(@"startTheUpgrade") forState:UIControlStateNormal];
    updateButton.titleLabel.font = [UIFont systemFontOfSize:17];
    [updateButton addTarget:self action:@selector(gotoOTAUpdate:) forControlEvents:UIControlEventTouchUpInside];
    [updateButton setBackgroundImage:[UIImage imageNamed:@"button"] forState:UIControlStateNormal];
    updateButton.adjustsImageWhenHighlighted = NO;
    [self.view addSubview:updateButton];
    UISwitch *reSwitch = [[UISwitch alloc] init];
    [self.view addSubview:reSwitch];
    UILabel *reLabel = [self createLabelWithText:FELocalizedString(@"upgradeAndRestoreFactorySettings") withFontOfSize:14];
    [self.view addSubview:reLabel];
    
    [updateProgressL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).offset((IsiPhoneX?IPHONEXNAVIGATIONHEIGHT:NAVIGATIONHEIGHT)+8);
        make.left.equalTo(self.view).offset(8);
    }];
    
    [progressL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.view).offset(-8);
        make.bottom.equalTo(updateProgressL);
    }];
    
    [progressV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(updateProgressL.mas_bottom).offset(15);
        make.left.equalTo(updateProgressL);
        make.right.equalTo(progressL);
        make.height.mas_equalTo(3);
    }];
    
    [filebButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(progressV).offset(20);
        make.left.equalTo(self.view).offset(8);
    }];
    
    [fileLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(filebButton);
        make.top.equalTo(filebButton.mas_bottom).offset(8);
    }];
    
    [nameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(fileLabel.mas_right).offset(8);
        make.top.equalTo(fileLabel);
        make.right.equalTo(self.view).offset(-8);
    }];
    //设置优先级
    [fileLabel setContentHuggingPriority:UILayoutPriorityDefaultHigh forAxis:UILayoutConstraintAxisHorizontal];;
    [nameLabel setContentCompressionResistancePriority:UILayoutPriorityDefaultHigh forAxis:UILayoutConstraintAxisHorizontal];
    
    [currentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(nameLabel.mas_bottom).offset(80);
        make.left.equalTo(filebButton);
    }];
    
    [updateFileLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(currentLabel.mas_bottom).offset(20);
        make.left.equalTo(currentLabel);
    }];
    [moduleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(nameLabel.mas_bottom).offset(50);
        make.left.equalTo(nameLabel).offset(10);
    }];
    [appVersionLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(moduleLabel.mas_right).offset(30);
        make.top.equalTo(moduleLabel);
    }];
    [blLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(appVersionLabel);
        make.left.equalTo(appVersionLabel.mas_right).offset(30);
    }];
    [fileModuleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(moduleLabel);
        make.centerY.equalTo(updateFileLabel);
    }];
    [fileAPPLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(appVersionLabel);
        make.centerY.equalTo(fileModuleLabel);
    }];
    [fileBlLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(blLabel);
        make.centerY.equalTo(fileAPPLabel);
    }];
    [currentModuleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(fileModuleLabel);
        make.centerY.equalTo(currentLabel);
    }];
    [currentAPPLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(fileAPPLabel);
        make.centerY.equalTo(currentModuleLabel);
    }];
    [currentBlLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(fileBlLabel);
        make.centerY.equalTo(currentAPPLabel);
    }];
    [updateButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view).offset(8);
        make.right.equalTo(self.view).offset(-8);
        make.bottom.equalTo(self.view).offset(-((IsiPhoneX?IPHONEXTABBARHEIGHT:TABBARHEIGHT)+8));
        make.height.mas_equalTo(44);
    }];
    [reSwitch mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view).offset(8);
        make.bottom.equalTo(updateButton.mas_top).offset(-8);
    }];
    [reLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(reSwitch.mas_right).offset(8);
        make.centerY.equalTo(reSwitch);
    }];
    
    updateProgressL.hidden = YES;
    progressL.hidden = YES;
    progressV.hidden = YES;
    self.updateLabel = updateProgressL;
    self.updateProgressLabel = progressL;
    self.progressView = progressV;
    self.fileNameLabel = nameLabel;
    self.updateModuleLabel = fileModuleLabel;
    self.updateAppLabel = fileAPPLabel;
    self.updateBlLabel = fileBlLabel;
    self.restoreSwitch = reSwitch;
    self.otaUpdateButton = updateButton;
    self.selectFileButton = filebButton;
}

// 进行升级
- (void)gotoOTAUpdate:(UIButton *)sender {
    if (self.fileName) {
        FEDFUSelectionListTableViewController *vc = [[FEDFUSelectionListTableViewController alloc] init];
        vc.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:vc animated:YES];
    }
}

// 选择升级文件
- (void)clickToSelectFile:(UIButton *)sender {
    FEDFUFileTableViewController *vc = [[FEDFUFileTableViewController alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)reflashView {
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    [def setObject:self.infoDict forKey:@"infoDict"];
    self.fileNameLabel.text = self.file;
    self.updateBlLabel.text = self.infoDict[@"Bootloader"];
    self.updateAppLabel.text = self.infoDict[@"Software"];
    self.updateModuleLabel.text = self.infoDict[@"Module"];
}

- (UILabel *)createLabelWithText:(NSString *)text withFontOfSize:(CGFloat)size {
    UILabel *label = [[UILabel alloc] init];
    label.text = text;
    label.font = [UIFont systemFontOfSize:size];
    return label;
}

- (void)dealloc {
    NSLog(@"升级界面被释放");
    if (self.api.peripheral) {
        [self.api disconnect];
    }
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end


