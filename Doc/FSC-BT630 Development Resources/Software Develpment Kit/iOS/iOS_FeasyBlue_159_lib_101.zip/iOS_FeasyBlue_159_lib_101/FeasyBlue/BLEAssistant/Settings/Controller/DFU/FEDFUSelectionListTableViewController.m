//
//  FEDFUSelectionListTableViewController.m
//  BLEAssistant
//
//  Created by ericj on 2018/1/26.
//  Copyright © 2018年 feasycom. All rights reserved.
//

#import "FEDFUSelectionListTableViewController.h"
#import "FECommunicationTableViewCell.h"
#import <MJRefresh.h>
#import "ServiceInfo.h"
#import "FEChangeDetailViewController.h"
#import "MemoryInfo.h"
#import "Masonry.h"
#import "FEFilterViewController.h"

@interface FEDFUSelectionListTableViewController ()<UIAlertViewDelegate,UITextFieldDelegate,UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) FscBleCentralApi *api;
@property (nonatomic, strong) NSMutableArray *peripherals;
@property (nonatomic, strong) NSMutableArray *advertisementDatas;
@property (nonatomic, strong) NSMutableArray *RSSIs;
@property (nonatomic, strong) MemoryInfo *memoryInfo;
@property (nonatomic, strong) UITableView *selectTableView;
@property (nonatomic, assign) NSInteger count;
@property (nonatomic, weak) UIButton *button;
@property (nonatomic, assign) int minimumRSSI;

@end

@implementation FEDFUSelectionListTableViewController

- (instancetype)init {
    if (self = [super init]) {
//        _isChange = NO;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    //自定义导航栏
    [self createCustomView];
    //设置界面
    [self setupUI];
    
    self.api = [FscBleCentralApi defaultFscBleCentralApi];
    self.api.moduleType = BLEMODULE;
    self.memoryInfo = [MemoryInfo shareMemoryInfo];
    [self setDelegate];
    [self.api startScan];
    self.peripherals = [NSMutableArray array];
    self.advertisementDatas = [NSMutableArray array];
    self.RSSIs = [NSMutableArray array];
    self.selectTableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        self.selectTableView.userInteractionEnabled = NO;
        //        [self.api stopScan];
        [self.peripherals removeAllObjects];
        [self.advertisementDatas removeAllObjects];
        [self.RSSIs removeAllObjects];
        [self.selectTableView reloadData];
        [self.selectTableView.mj_header endRefreshing];
        [self.api startScan];
        self.selectTableView.userInteractionEnabled = YES;
    }];

    NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
    BOOL enable;
    float f;
    if (self.isChange) {
        enable = [user boolForKey:@"enable_parameter"];
        f = [user floatForKey:@"minimumRSSI_parameter"];
    } else {
        enable = [user boolForKey:@"enable_update"];
        f = [user floatForKey:@"minimumRSSI_update"];
    }
    if ((int)f < 0 && enable) {
        self.minimumRSSI = (int)f;
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeCount) name:@"notifycationModify" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(RefreshPeripherals) name:NOTIFICATIONRELODATA object:nil];
}

- (void)clickToFilter {
    FEFilterViewController *filterVC = [[FEFilterViewController alloc] init];
    if (self.isChange) {
        filterVC.typeRssi = PARAMETER;
    } else {
        filterVC.typeRssi = UPDATE;
    }
    __weak typeof(self) weakself = self;
    filterVC.minimumRSSIBlock = ^(float RSSI) {
        weakself.minimumRSSI = (int)RSSI;
        [weakself.peripherals removeAllObjects];
        [weakself.selectTableView reloadData];
        [weakself.api startScan];
    };
    [self.navigationController pushViewController:filterVC animated:YES];
}

//排序
- (void)sort {
    for (int i = 0; i < self.peripherals.count; ++i) {
        //遍历数组的每一个索引（不包括最后一个,因为比较的是j+1）
        for (int j = 0; j < self.peripherals.count-1; ++j) {
            //根据索引的相邻两位进行比较
            if ([self.RSSIs[j] integerValue] < [self.RSSIs[j+1] integerValue]) {
                [self.peripherals exchangeObjectAtIndex:j withObjectAtIndex:j+1];
                [self.RSSIs exchangeObjectAtIndex:j withObjectAtIndex:j+1];
                [self.advertisementDatas exchangeObjectAtIndex:j withObjectAtIndex:j+1];
            }
        }
    }
    [self.selectTableView reloadData];
}

- (void)setupUI {
    UIView *buttonView = [[UIView alloc] initWithFrame:CGRectMake(0, IsiPhoneX?NAVIGATIONHEIGHT_iPhoneX:NAVIGATIONHEIGHT, self.view.frame.size.width, 44)];
    buttonView.backgroundColor = [UIColor groupTableViewBackgroundColor];
    [self.view addSubview:buttonView];
    UIView *sortView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, buttonView.frame.size.width/2.0, buttonView.frame.size.height)];
    [buttonView addSubview:sortView];
    UITapGestureRecognizer *tapSort = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(sort)];
    [sortView addGestureRecognizer:tapSort];
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"排序"]];
    [sortView addSubview:imageView];
    UILabel *sortLable = [[UILabel alloc] init];
    sortLable.text = @"排序";
    sortLable.font = [UIFont systemFontOfSize:17];
    [sortView addSubview:sortLable];
    
    UIView *filterView = [[UIView alloc] initWithFrame:CGRectMake(buttonView.frame.size.width/2.0, 0, buttonView.frame.size.width/2.0, buttonView.frame.size.height)];
    [buttonView addSubview:filterView];
    UITapGestureRecognizer *tapFilter = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clickToFilter)];
    [filterView addGestureRecognizer:tapFilter];
    UIImageView *filterImageV = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"过滤2"]];
    [filterView addSubview:filterImageV];
    UILabel *filterLable = [[UILabel alloc] init];
    filterLable.text = @"过滤";
    filterLable.font = [UIFont systemFontOfSize:17];
    [filterView addSubview:filterLable];
    UIView *lineView = [[UIView alloc] init];
    lineView.backgroundColor = [UIColor blackColor];
    [buttonView addSubview:lineView];
    
//    UIButton *button_L = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, buttonView.frame.size.width/2.0, buttonView.frame.size.height)];
//    [button_L setTitle:@"排序" forState:UIControlStateNormal];
//    button_L.titleLabel.font = [UIFont systemFontOfSize:17];
//    [button_L setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
//    [button_L addTarget:self action:@selector(sort) forControlEvents:UIControlEventTouchUpInside];
//    [buttonView addSubview:button_L];
//    UIButton *button_R = [[UIButton alloc] initWithFrame:CGRectMake(buttonView.frame.size.width/2.0, 0, buttonView.frame.size.width/2.0, buttonView.frame.size.height)];
//    [button_R setTitle:@"过滤" forState:UIControlStateNormal];
//    button_R.titleLabel.font = [UIFont systemFontOfSize:17];
//    [button_R setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
//    [button_R addTarget:self action:@selector(clickToFilter) forControlEvents:UIControlEventTouchUpInside];
//    [buttonView addSubview:button_R];
    
    // 创建tableView
    self.selectTableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    [self.view addSubview:self.selectTableView];
    
    [self.selectTableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(self.view);
        make.top.equalTo(buttonView.mas_bottom);
        make.bottom.equalTo(self.view);//.offset(-(IsiPhoneX?TABBARHEIGHT_iPhoneX:TABBARHEIGHT));
    }];
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(sortView).offset(12);
        make.bottom.equalTo(sortView).offset(-12);
        make.right.equalTo(sortView).offset(-(sortView.frame.size.width/2.0)-5);
        make.width.mas_equalTo(20*1.6);
    }];
    [sortLable mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(imageView);
        make.left.equalTo(sortView).offset((sortView.frame.size.width/2.0)+5);
    }];
    [filterImageV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.bottom.equalTo(imageView);
        make.right.equalTo(filterView).offset(-(filterView.frame.size.width/2.0)-8);
        make.width.mas_equalTo(20);
    }];
    [filterLable mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(filterImageV);
        make.left.equalTo(filterView).offset((filterView.frame.size.width/2.0)+5);
    }];
    [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(buttonView).offset(10);
        make.bottom.equalTo(buttonView).offset(-10);
        make.centerX.equalTo(buttonView);
        make.width.mas_equalTo(1);
    }];
    
    self.selectTableView.delegate = self;
    self.selectTableView.dataSource = self;
    //去掉列表分割线
    [self.selectTableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    //注册cell
    [self.selectTableView registerNib:[UINib nibWithNibName:@"FECommunicationTableViewCell"bundle:nil] forCellReuseIdentifier:@"CommCell"];
    [self.selectTableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"MyCell"];
}

- (void)changeCount {
    self.count++;
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    [def setInteger:self.count forKey:@"count"];
    [self.button setTitle:[NSString stringWithFormat:@"完成数:%ld",self.count] forState:UIControlStateNormal];
}

- (void)RefreshPeripherals {
    [self.peripherals removeAllObjects];
    [self.advertisementDatas removeAllObjects];
    [self.RSSIs removeAllObjects];
    [self.selectTableView reloadData];
    [self.api startScan];
}


- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}


- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//自定义导航栏
- (void)createCustomView {

//    UIBarButtonItem *buttonL = [[UIBarButtonItem alloc] initWithTitle:FELocalizedString(@"sort") style:UIBarButtonItemStylePlain target:self action:@selector(sort)];
//    UIButton * leftBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 40, 20)];
//    [leftBtn setTitle:FELocalizedString(@"filter") forState:UIControlStateNormal];
//    leftBtn.titleLabel.font = [UIFont systemFontOfSize:17];
//    [leftBtn setTitleColor:[UIColor colorWithRed:21/255.0 green:126/255.0 blue:251/255.0 alpha:1] forState:UIControlStateNormal];
//    [leftBtn setTitleColor:[UIColor colorWithRed:210/255.0 green:230/255.0 blue:245/255.0 alpha:1] forState:UIControlStateHighlighted];
//    [leftBtn addTarget:self action:@selector(clickToFilter) forControlEvents:UIControlEventTouchUpInside];
//    UIBarButtonItem * buttonL2 = [[UIBarButtonItem alloc] initWithCustomView:leftBtn];
//    self.navigationItem.rightBarButtonItems = @[buttonL,buttonL2];

    if (self.isChange) {
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 80, 40)];
        UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(0, 10, 80, 20)];
        [btn setTitle:FELocalizedString(@"parametricModify") forState:UIControlStateNormal];
        [btn.titleLabel setFont:[UIFont fontWithName:@"AmericanTypewriter-Bold" size:17]];
        [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(clickToChangeCount) forControlEvents:UIControlEventTouchUpInside];
        [view addSubview:btn];

        NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
        int count_new = (int)[def integerForKey:@"count"];
        self.count = count_new;
        UIButton *countBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 30, 80, 10)];
        [countBtn setTitle:[NSString stringWithFormat:@"完成数:%d",count_new!=0?count_new:0] forState:UIControlStateNormal];
        [countBtn.titleLabel setFont:[UIFont systemFontOfSize:11]];
        [countBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [countBtn addTarget:self action:@selector(clickToChangeCount) forControlEvents:UIControlEventTouchUpInside];
        [view addSubview:countBtn];
        self.button = countBtn;
        self.navigationItem.titleView = view;

    } else {
        self.navigationItem.title = @"空中升级";
    }

}

- (void)clickToChangeCount {
    UIAlertView *countView = [[UIAlertView alloc] initWithTitle:@"修改完成数" message:nil delegate:self cancelButtonTitle:FELocalizedString(@"cancel") otherButtonTitles:FELocalizedString(@"ok"), nil];
    [countView setAlertViewStyle:UIAlertViewStylePlainTextInput];
    UITextField *countText = [countView textFieldAtIndex:0];
    countText.keyboardType = UIKeyboardTypeNumberPad;
    countText.delegate = self;
    [countView show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 1) {
        UITextField *textField = [alertView textFieldAtIndex:0];
        self.count = [textField.text integerValue];
        NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
        [def setInteger:self.count forKey:@"count"];
        [self.button setTitle:[NSString stringWithFormat:@"完成数:%ld",[textField.text integerValue]] forState:UIControlStateNormal];
    }
}

- (void)setDelegate {

    __weak typeof(self) weakself = self;
    [self.api isBtEnabled:^(CBCentralManager *central) {
        NSLog(@"看看蓝牙打开没有");
        [weakself.api startScan];
    }];
    
    [self.api blePeripheralConnected:^(CBCentralManager *central, CBPeripheral *peripheral) {
        if (!weakself.isChange) {
            NSLog(@"连接成功返回");
            [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATIONSTARTOTAUPDATE object:nil];
            [weakself.navigationController popViewControllerAnimated:YES];
        } else {
            FEChangeDetailViewController *vc = [[FEChangeDetailViewController alloc] init];
            vc.peripheralString = weakself.api.peripheral.identifier.UUIDString;
            vc.commandsArray = weakself.infoArray;
            vc.name = weakself.api.peripheral.name;
            [weakself.navigationController pushViewController:vc animated:YES];
        }
    }];
    
    [self.api blePeripheralFound:^(CBCentralManager *central, CBPeripheral *peripheral, NSDictionary *advertisementData, NSNumber *RSSI) {
        if (self.minimumRSSI) {
            if ([RSSI integerValue]<0 && [RSSI integerValue]>self.minimumRSSI) {
                if (![weakself.peripherals containsObject:peripheral]) {
                    [weakself insertTableView:peripheral advertisementData:advertisementData RSSI:RSSI];
                }else{
                    NSInteger index = [weakself.peripherals indexOfObject:peripheral];
                    weakself.RSSIs[index] = RSSI;
                }
            }
        } else {
            if ([RSSI integerValue]<0 && [RSSI integerValue]>-100) {
                if (![weakself.peripherals containsObject:peripheral]) {
                    [weakself insertTableView:peripheral advertisementData:advertisementData RSSI:RSSI];
                }else{
                    NSInteger index = [weakself.peripherals indexOfObject:peripheral];
                    weakself.RSSIs[index] = RSSI;
                }
            }
        }
    }];
    
}

//插入table数据
-(void)insertTableView:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI{
    if ([RSSI integerValue]<-100 && [RSSI integerValue]>0) return;
    if(![self.peripherals containsObject:peripheral]) {
        if (!self.selectTableView.isDragging && !self.selectTableView.isTracking && !self.selectTableView.isDecelerating) {
            NSMutableArray *indexPaths = [[NSMutableArray alloc] init];
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:self.peripherals.count inSection:0];
            [indexPaths addObject:indexPath];
            [self.peripherals addObject:peripheral];
            [self.advertisementDatas addObject:advertisementData];
            [self.RSSIs addObject:RSSI];
            [self.selectTableView insertRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationAutomatic];
        }
    }else{
        NSInteger index = [self.peripherals indexOfObject:peripheral];
        self.RSSIs[index] = RSSI;
    }
}



#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.peripherals.count;
}

- (FECommunicationTableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    FECommunicationTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CommCell"];
    if(cell == nil) {
        cell = [FECommunicationTableViewCell new];
    }
    CBPeripheral *peripheral = [self.peripherals objectAtIndex:indexPath.row];
    //[cell reflashName:peripheral.name];
    NSDictionary *advertisementData = self.advertisementDatas[indexPath.row];
    if (advertisementData[CBAdvertisementDataLocalNameKey]) {
        [cell reflashName:[NSString stringWithFormat:@"%@",advertisementData[CBAdvertisementDataLocalNameKey]]];
    }else{
        [cell reflashName:peripheral.name];
    }
    [cell reflashRSSI:[self.RSSIs[indexPath.row] integerValue]];
    cell.UUIDLabel.text = peripheral.identifier.UUIDString;
    if ([advertisementData[@"kCBAdvDataServiceUUIDs"] componentsJoinedByString:@","]) {
        cell.serviceUUIDsLabel.text = [[NSString alloc] initWithFormat:@"%@",[advertisementData[@"kCBAdvDataServiceUUIDs"] componentsJoinedByString:@","]];
    }else{
        cell.serviceUUIDsLabel.text = @"";
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    self.api.peripheral = self.peripherals[indexPath.row];
    if (!self.memoryInfo.peripheralString) {
        if (self.memoryInfo.commandArray_record.count > 0) {
            [self.memoryInfo.commandArray_record removeAllObjects];
        }
        self.memoryInfo.peripheralString = self.api.peripheral.identifier.UUIDString;
    }
    [self.api connect:self.api.peripheral];
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 60;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

@end
