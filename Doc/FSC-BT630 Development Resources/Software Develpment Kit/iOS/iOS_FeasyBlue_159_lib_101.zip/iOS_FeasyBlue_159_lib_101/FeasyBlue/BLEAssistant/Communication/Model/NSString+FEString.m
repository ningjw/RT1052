//
//  NSString+FEString.m
//  BLEAssistant
//
//  Created by 余明悦 on 16/9/21.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import "NSString+FEString.h"

@implementation NSString (FEString)
-(NSData*) hexToData {
    NSMutableData* data = [NSMutableData data];
    int idx;
    NSString *str = [[[self stringByReplacingOccurrencesOfString:@" " withString:@""]
                     stringByReplacingOccurrencesOfString:@"\r" withString:@""]
                     stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    NSLog(@"%@", str);
    for (idx = 0; idx+2 <= str.length; idx+=2) {
        NSRange range = NSMakeRange(idx, 2);
        NSString* hexStr = [str substringWithRange:range];
        NSScanner* scanner = [NSScanner scannerWithString:hexStr];
        unsigned int intValue;
        [scanner scanHexInt:&intValue];
        [data appendBytes:&intValue length:1];
    }
    return data;
}

-(NSData *)UTF8ToData{
    return [self dataUsingEncoding:NSUTF8StringEncoding];
}

-(NSString *)dataToHex:(NSData *)data{
    if (data.length){
        NSString *string = [[[NSString stringWithFormat:@"%@",data]
                             stringByReplacingOccurrencesOfString: @"<" withString: @""]
                            stringByReplacingOccurrencesOfString: @">" withString: @""];
        return string.uppercaseString;
    }else{
        return @"";
    }
}

-(NSString *)dataToUTF8:(NSData *)data{
    return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
}

+ (NSString *)getHexByDecimal:(unsigned int)decimal {
    
    NSString *hex =@"";
    NSString *letter;
    NSInteger number;
    for (int i = 0; i<9; i++) {
        
        number = decimal % 16;
        decimal = decimal / 16;
        switch (number) {
                
            case 10:
                letter =@"A"; break;
            case 11:
                letter =@"B"; break;
            case 12:
                letter =@"C"; break;
            case 13:
                letter =@"D"; break;
            case 14:
                letter =@"E"; break;
            case 15:
                letter =@"F"; break;
            default:
                letter = [NSString stringWithFormat:@"%ld", (long)number];
        }
        hex = [letter stringByAppendingString:hex];
        if (decimal == 0) {
            
            break;
        }
    }
    return hex;
}

// 十六进制字符串转化为ASCII码对应的字符
+ (NSString *)getAddressFromHexString:(NSString *)string {
    NSString *str = @"";
    NSString *newStr = @"";
    for (int i = 0; i < string.length/2; i++) {
        str = [string substringWithRange:NSMakeRange(i*2, 2)];
        str = [NSString stringWithFormat:@"%ld",strtoul([str UTF8String],0,16)];
        str = [NSString stringWithFormat:@"%c",[str intValue]];
        newStr = [newStr stringByAppendingString:str];
    }
    return newStr;
}

// 十六进制数据转字符串
+(NSString *)fan_dataToHexString:(NSData *)data{
    Byte *bytehex =(Byte *) data.bytes;
    NSMutableString *hexString=[[NSMutableString alloc]init];
    for (int i=0; i<data.length; i++) {
        Byte b=bytehex[i];
        [hexString appendFormat:@"%02x",b];
    }
    return hexString;
}


@end
