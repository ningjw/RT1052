//
//  FEFilterRSSITableViewCell.h
//  BLEAssistant
//
//  Created by ericj on 2018/6/5.
//  Copyright © 2018年 feasycom. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FEFilterModel.h"

@interface FEFilterRSSITableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UISwitch *filterEnableSwitch;

@property (nonatomic, assign) TYPE_RSSI type;

@end
