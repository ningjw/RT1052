//
//  FESettingSearchTableViewCell.h
//  BLEAssistant
//
//  Created by 余明悦 on 16/9/28.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FESettingSearchTableViewCell : UITableViewCell
@property (unsafe_unretained, nonatomic) IBOutlet UILabel *serviceUUIDsLabel;
@property (weak, nonatomic) IBOutlet UILabel *nameBeforeLabel;
@property (weak, nonatomic) IBOutlet UILabel *nameAfterLabel;
@property (weak, nonatomic) IBOutlet UILabel *pinBeforeLabel;
@property (weak, nonatomic) IBOutlet UILabel *pinAfterLabel;
@property (weak, nonatomic) IBOutlet UILabel *baudBeforeLabel;
@property (weak, nonatomic) IBOutlet UILabel *baudAfterLabel;

- (void)reflashName:(NSString *)name;
- (void)reflashRSSI:(NSInteger)RSSI;
- (void)changeOK:(BOOL)success;
- (void)clear;
- (void)successed:(BOOL)success;
- (void)progressPersend:(NSInteger)persend;
@end
