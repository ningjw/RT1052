//
//  FEChangeServiceTableViewController.m
//  BLEAssistant
//
//  Created by yumingyue on 2016/11/20.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import "FEChangeServiceTableViewController.h"
#import "FEServiceDetailedTableViewController.h"
#import "NSString+FEString.h"
#import "FscBleCentralApi.h"
#import "MemoryInfo.h"
#import "Masonry.h"

#define INFODEVICE @"180A"

BOOL isFirst = YES;
BOOL isFirstNotify = YES;
BOOL firstNotify = YES;

@interface FEChangeServiceTableViewController ()<UITextFieldDelegate>
@property (nonatomic, strong) NSMutableArray<CBCharacteristic *>* infoCharacteristics;
@property (nonatomic) NSInteger sortIndex;
@property (nonatomic, strong) UITableViewCell *wrCell;
@property (nonatomic, strong) UITableViewCell *wrNoReCell;
@property (nonatomic, strong) NSMutableArray<CBCharacteristic *>*chaReArray;
@property (nonatomic, strong) NSMutableArray<CBCharacteristic *>*chaReadValueArray;
@property (nonatomic, strong) FscBleCentralApi *api;
@property (nonatomic, weak) UITextField *mtuTextField;
@property (nonatomic, strong) NSMutableArray *advertisementDataArrayM;
@property (nonatomic, copy) NSString *characteristic_UUID_new;
@property (nonatomic, strong) MemoryInfo *memoryInfo;
@property (nonatomic, strong) UISwitch *syncSwitch;


@end

@implementation FEChangeServiceTableViewController

typedef NS_ENUM(NSInteger, SegmentState) {
    N_read = 0,
    N_writeRe,
    N_write
};

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(notificationChangeService:) name:NOTIFICATIONCHANGESERVICE object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(writeWithResponse:) name:NOTIFICATIONWRITE object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(writeWithoutResponse:) name:NOTIFICATIONWRITEWITHOUTRESPONSE object:nil];
    //配置导航栏
    // 创建一个使用本来的样式进行渲染的图片
    NSMutableArray *array = [NSMutableArray new];
    [array addObject:FELocalizedString(@"n_read")];
    [array addObject:FELocalizedString(@"n_writeRe")];
    [array addObject:FELocalizedString(@"n_write")];
    
    self.advertisementDataArrayM = [NSMutableArray array];
    //解析广播数据
    [self loadAdvertisementDatas];
    //设置界面
    [self setupUI];
    
    //读取用户偏好设置
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    if (def) {
        self.mtuTextField.text = [NSString stringWithFormat:@"%ld",(long)[def integerForKey:@"mtu"]];
        self.syncSwitch.on = [def boolForKey:@"sync"];
    }
    
//    [self sortService];
    self.infoCharacteristics = [NSMutableArray new];
    self.chaReArray = [NSMutableArray new];
    self.chaReadValueArray = [NSMutableArray new];
    self.api = [FscBleCentralApi shareFscBleCentralApi];
    self.memoryInfo = [MemoryInfo shareMemoryInfo];
    self.memoryInfo.index++;
    ServiceInfo *info;
    for (info in self.services) {
//        NSLog(@"%@",info.service);
        if (self.api.peripheral.state != CBPeripheralStateDisconnected) {
            [info reflashCharacteristics];//必须更新特征
        }
        
        if ([info.service.UUID.UUIDString isEqualToString:INFODEVICE]) {
            [self.infoCharacteristics addObjectsFromArray:info.service.characteristics];
//            [self sortInfoCharacteristic];//排序
        }
        if ([info.service.UUID.UUIDString isEqualToString:@"FFF0"] && isFirstNotify) {
            isFirstNotify = NO;
            for (CBCharacteristic *c in info.service.characteristics) {
                if ([c.UUID.UUIDString isEqualToString:@"FFF1"] && c.properties & CBCharacteristicPropertyNotify) {
                    [self.memoryInfo.notifyArrM addObject:c.UUID.UUIDString];
                }
            }
        } else if (!self.priority && isFirstNotify) {
            for (CBCharacteristic *c in info.service.characteristics) {
                if (c.properties & CBCharacteristicPropertyNotify && firstNotify) {
                    firstNotify = NO;
                    [self.memoryInfo.notifyArrM addObject:c.UUID.UUIDString];
                }
            }
        }
    }
    
}

- (void)changePriority {
    if (!self.priority) {
        ServiceInfo *info;
        for (info in self.services) {
            for (CBCharacteristic *c in info.service.characteristics) {
                if (c.properties & CBCharacteristicPropertyWriteWithoutResponse && [c.UUID.UUIDString isEqualToString:@"FFF2"]) {
                    self.characteristic_UUID_new = c.UUID.UUIDString;
                    return;
                }
            }
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [self reloadData];
    //改变新的优先级
    if (isFirst) {
        [self changePriority];
    }
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    self.characteristic_UUID_new = nil;
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.services.count+1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return [self.advertisementDataArrayM.firstObject count];
    }
    ServiceInfo *info = self.services[section-1];
    if ([info.service.UUID.UUIDString isEqualToString:INFODEVICE]) {
        return self.characteristicReceiveArray.count;
    }
    return info.characteristicArrayM.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyCell"];
    if(cell ==nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"MyCell"];
        cell.textLabel.font = [UIFont systemFontOfSize:13];
        cell.detailTextLabel.font = [UIFont systemFontOfSize:10];
    }
    if (indexPath.section == 0) {
        cell.textLabel.text = [NSString stringWithFormat:@"%@",self.advertisementDataArrayM.lastObject[indexPath.row]];
        cell.detailTextLabel.text = [NSString stringWithFormat:@"%@",self.advertisementDataArrayM.firstObject[indexPath.row]];
    } else {
        ServiceInfo *info = self.services[indexPath.section-1];
        CBCharacteristic *characteristic = info.characteristicArrayM[indexPath.row];
        NSString *characteristicString;
        if(![info.service.UUID.UUIDString isEqualToString:INFODEVICE]){
            characteristicString = @"";
            if (characteristic.properties & CBCharacteristicPropertyRead){
                //拿到值可读的特征了
                [self.chaReadValueArray addObject:characteristic];
                characteristicString = [characteristicString stringByAppendingString:FELocalizedString(@"readValue")];
            }
            if (characteristic.properties & CBCharacteristicPropertyNotify){
                //拿到可读的无反馈特征了
                characteristicString = [characteristicString stringByAppendingString:FELocalizedString(@"readNoRe")];
            }
            if (characteristic.properties & CBCharacteristicPropertyIndicate){
                //拿到可读的特征了
                characteristicString = [characteristicString stringByAppendingString:FELocalizedString(@"readRe")];
            }
            if (characteristic.properties & CBCharacteristicPropertyWriteWithoutResponse){
                //拿到可写WithoutResponse的特征了
                characteristicString = [characteristicString stringByAppendingString:FELocalizedString(@"writeNoRe")];
                if (self.wrNoReCharacteristic == characteristic) {
                    self.wrNoReCell = cell;
                }
            }
            if (characteristic.properties & CBCharacteristicPropertyWrite){
                //拿到可写的特征了
                characteristicString = [characteristicString stringByAppendingString:FELocalizedString(@"writeRe")];
                if (self.wrCharacteristic == characteristic) {
                    self.wrCell = cell;
                }
            }
            cell.textLabel.text = characteristic.UUID.UUIDString;
            cell.detailTextLabel.text = [NSString stringWithFormat:@"Properties:%@",characteristicString];
            //把接收的特征加入接收特征的数组
            if (characteristic.properties & CBCharacteristicPropertyNotify || characteristic.properties & CBCharacteristicPropertyIndicate) {
                [self.chaReArray addObject:characteristic];
            }
        }else{
            //设备信息
            characteristic = self.characteristicReceiveArray[indexPath.row];
            cell.textLabel.text = [self characteristicName:characteristic];
            cell.detailTextLabel.text = [self characteristicValue:characteristic];
        }
    }
    cell.detailTextLabel.textColor = [UIColor grayColor];
    cell.detailTextLabel.font = [UIFont systemFontOfSize:10];
    cell.detailTextLabel.numberOfLines = 0;
    cell.textLabel.numberOfLines = 0;
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    return cell;
}

// 自定义行高
-(CGFloat)tableView:(UITableView*)tableView heightForRowAtIndexPath:(NSIndexPath*)indexPath{
    return 50;
}
//设置分区头区域的高度
-(CGFloat)tableView:(UITableView*)tableView heightForHeaderInSection:(NSInteger)section{
    return 40;
}
//分区头信息
-(NSString*)tableView:(UITableView*)tableView titleForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return @"ADVERTISEMENTDATAS";
    } else {
        ServiceInfo *info = self.services[section-1];
        if(![info.service.UUID.UUIDString isEqualToString:INFODEVICE]){
            NSString *serviceName = [NSString stringWithFormat:@"%@:%@",FELocalizedString(@"service"), info.service.UUID.UUIDString];
            return serviceName;
        }else{
            return FELocalizedString(@"deviceInformation");
        }
    }
}
// 设置分区头部
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UIView *view = [[UIView alloc] init];
    UILabel *lab = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, self.view.frame.size.width - 15, 40)];
    lab.font = [UIFont systemFontOfSize:15];
    lab.numberOfLines = 0;
    if (section == 0) {
        lab.text = @"Advertising Data";
    } else {
        ServiceInfo *info = self.services[section-1];
        if(![info.service.UUID.UUIDString isEqualToString:INFODEVICE]){
            NSString *serviceName = [NSString stringWithFormat:@"%@:%@",FELocalizedString(@"service"), info.service.UUID.UUIDString];
            lab.text = serviceName;
        }else{
            lab.text = FELocalizedString(@"deviceInformation");
        }
    }
    [view addSubview:lab];
    view.backgroundColor = [UIColor groupTableViewBackgroundColor];
    return view;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section != 0) {
        ServiceInfo *info = self.services[indexPath.section-1];
        //不是设备信息才处理
        if(![info.service.UUID.UUIDString isEqualToString:INFODEVICE]){
            CBCharacteristic *characteristic = info.characteristicArrayM[indexPath.row];
            FEServiceDetailedTableViewController *detailedVC = [[FEServiceDetailedTableViewController alloc] initWithServiceUUID:info.service.UUID.UUIDString withCharacteristic:characteristic];
            detailedVC.priority = self.priority;
            detailedVC.services = self.services.copy;
            detailedVC.characteristic_UUID_new = self.characteristic_UUID_new;
            __weak typeof(FEServiceDetailedTableViewController *) weakDetailedVC = detailedVC;
            detailedVC.saveCharacteristicBlock = ^(NSString *string) {
                weakDetailedVC.characteristicUUID = string;
            };
            [self.navigationController pushViewController:detailedVC animated:YES];
        }
    }
}

//当前行是否可以编辑
-(BOOL)tableView:(UITableView*)tableView canEditRowAtIndexPath:(NSIndexPath*)indexPath{
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    if ([cell.detailTextLabel.text containsString:FELocalizedString(@"readValue")]) {
        return YES;
    }
    return NO;
}
//当前行是什么编辑样式
-(UITableViewCellEditingStyle)tableView:(UITableView*)tableView editingStyleForRowAtIndexPath:(NSIndexPath*)indexPath{
    return UITableViewCellEditingStyleDelete;//删除
}
//设置左滑按钮
- (nullable NSArray<UITableViewRowAction *> *)tableView:(UITableView *)tableView editActionsForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *string = @"";
    UITableViewRowAction *act = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleDestructive title:FELocalizedString(@"read")
                                                                 handler:^(UITableViewRowAction * _Nonnull action, NSIndexPath * _Nonnull indexPath) {
                                                                     NSString *title = [NSString stringWithFormat:@"%@(%ld %@)\r\n0x%@",FELocalizedString(@"hex"),self.chaReadValueArray[indexPath.row].value.length,
                                                                                        FELocalizedString(@"bytes"), [string  dataToHex:self.chaReadValueArray[indexPath.row].value]];
                                                                     NSString *message =  [NSString stringWithFormat:@"%@%@",FELocalizedString(@"utf8"),[[NSString alloc] initWithData:self.chaReadValueArray[indexPath.row].value encoding:NSUTF8StringEncoding]];
                                                                     UIAlertView *lock =[[UIAlertView alloc]initWithTitle:title message:message delegate:self cancelButtonTitle:FELocalizedString(@"ok") otherButtonTitles: nil];
                                                                     [lock show];
                                                                 }];
    act.backgroundColor = [UIColor blueColor];
    return @[act];
}


-(NSString*)characteristicName:(CBCharacteristic*)characteristic{
    NSString *characteristicString = characteristic.UUID.UUIDString;
    if ([characteristicString isEqualToString:@"2A23"]) {
        return FELocalizedString(@"systemID");
    }else if ([characteristicString isEqualToString:@"2A24"]){
        return FELocalizedString(@"modelNumber");
    }else if ([characteristicString isEqualToString:@"2A25"]){
        return FELocalizedString(@"serialNumber");
    }else if ([characteristicString isEqualToString:@"2A26"]){
        return FELocalizedString(@"firmwareRevision");
    }else if ([characteristicString isEqualToString:@"2A27"]){
        return FELocalizedString(@"hardwareRevision");
    }else if ([characteristicString isEqualToString:@"2A28"]){
        return FELocalizedString(@"softwareRevision");
    }else if ([characteristicString isEqualToString:@"2A29"]){
        return FELocalizedString(@"manufacturerName");
    }else{
        characteristicString = [NSString stringWithFormat:@"%@",characteristic.description];
        NSRange range = [characteristicString rangeOfString:@"UUID = "];
        characteristicString = [characteristicString substringFromIndex:range.location+range.length];
        range = [characteristicString rangeOfString:@","];
        characteristicString = [characteristicString substringToIndex:range.location];
        characteristicString = [NSString stringWithFormat:@"%@(%@)",characteristicString, characteristic.UUID.UUIDString];
        return characteristicString;
    }
}


-(NSString*)characteristicValue:(CBCharacteristic*)characteristic{
    NSString *characteristicString = characteristic.UUID.UUIDString;
    NSString *string = [[NSString alloc] initWithData:characteristic.value encoding:NSUTF8StringEncoding];
    if ([characteristicString isEqualToString:@"2A25"]) {
        NSMutableString *stringTemp = [NSMutableString new];
        if (string.length == 12) {
            for (int i=0; i<12; i+=2) {
                [stringTemp appendString:[string substringWithRange:NSMakeRange(i, 2)]];
                [stringTemp appendString:@":"];
            }
            string = [stringTemp substringToIndex:stringTemp.length-1];
//            NSLog(@"%@",string);
        }
    }
    if (string == nil || [characteristicString isEqualToString:@"2A50"]) {
        return [NSString stringWithFormat:@"%@",characteristic.value];
    }
    return string;
}

- (void)loadAdvertisementDatas {
    NSMutableArray *keyArrayM = [NSMutableArray array];
    NSMutableArray *valueArrayM = [NSMutableArray array];
    
    if (self.advertisementData[@"kCBAdvDataIsConnectable"]) {
        if ([self.advertisementData[@"kCBAdvDataIsConnectable"] integerValue] == 1) {
            [valueArrayM addObject:@"YES"];
        } else {
            [valueArrayM addObject:@"NO"];
        }
        [keyArrayM addObject:@"Device Is Connectable"];
    }
    if (self.advertisementData[@"kCBAdvDataLocalName"]) {
        [valueArrayM addObject:self.advertisementData[@"kCBAdvDataLocalName"]];
        [keyArrayM addObject:@"Local Name"];
    }
    if (self.advertisementData[@"kCBAdvDataManufacturerData"]) {
        [valueArrayM addObject:self.advertisementData[@"kCBAdvDataManufacturerData"]];
        [keyArrayM addObject:@"Manufacturer Data"];
    }
    if (self.advertisementData[@"kCBAdvDataServiceUUIDs"]) {
        NSArray *arr = self.advertisementData[@"kCBAdvDataServiceUUIDs"];
        NSString *str = @"";
        for (int i = 0; i < arr.count; i++) {
            if (i != 0) {
                str = [[NSString stringWithFormat:@"%@",str] stringByAppendingString:@", "];
            }
            str = [[NSString stringWithFormat:@"%@",str] stringByAppendingString:[NSString stringWithFormat:@"%@",arr[i]]];
        }
        [valueArrayM addObject:str];
        [keyArrayM addObject:@"Service UUIDs"];
    }
    if (self.advertisementData[@"kCBAdvDataTxPowerLevel"]) {
        [valueArrayM addObject:self.advertisementData[@"kCBAdvDataTxPowerLevel"]];
        [keyArrayM addObject:@"Tx Power Level"];
    }
    
    [self.advertisementDataArrayM addObject:keyArrayM];
    [self.advertisementDataArrayM addObject:valueArrayM];
}

//设置界面
- (void)setupUI {
    //添加表头
    UIView *headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 50)];
    self.tableView.tableHeaderView = headView;
    UILabel *mtuLabel = [[UILabel alloc] init];//WithFrame:CGRectMake(15, 8, 50, 34)];
    mtuLabel.font = [UIFont systemFontOfSize:13];
    mtuLabel.text = @"MTU:";
    [headView addSubview:mtuLabel];
    UITextField *mtuField = [[UITextField alloc] init];//WithFrame:CGRectMake(65, 10, self.view.frame.size.width-150, 30)];
    mtuField.borderStyle = UITextBorderStyleRoundedRect;
    mtuField.font = [UIFont systemFontOfSize:13];
    [headView addSubview:mtuField];
    self.mtuTextField = mtuField;
    self.mtuTextField.delegate = self;
    
    UISwitch *sySwitch = [[UISwitch alloc] init];
    sySwitch.transform = CGAffineTransformMakeScale(0.8, 0.8);
    [sySwitch addTarget:self action:@selector(clickSync:) forControlEvents:UIControlEventTouchUpInside];
    [headView addSubview:sySwitch];
    self.syncSwitch = sySwitch;
    
    UILabel *syLabel = [[UILabel alloc] init];
    syLabel.text = @"sync";
    syLabel.textAlignment = NSTextAlignmentRight;
    syLabel.font = [UIFont systemFontOfSize:15];
    [headView addSubview:syLabel];
    
    [sySwitch mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(headView);
        make.right.equalTo(headView).offset(-15);
    }];
    
    [syLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(sySwitch);
        make.width.mas_equalTo(40);
        make.right.equalTo(sySwitch.mas_left).offset(-5);
    }];
    
    [mtuLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(headView).offset(15);
        make.width.mas_equalTo(40);
        make.centerY.equalTo(headView);
    }];
    
    [mtuField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(mtuLabel.mas_right).offset(5);
        make.centerY.equalTo(mtuLabel);
        make.height.mas_equalTo(30);
        make.right.equalTo(syLabel.mas_left).offset(-15);
    }];
    
//    UILabel *adLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 50, self.view.frame.size.width, 40)];
//    adLabel.backgroundColor = [UIColor groupTableViewBackgroundColor];
//    adLabel.text = @"    ADVERTISEMENTDATA";
//    adLabel.font = [UIFont systemFontOfSize:15];
//    [headView addSubview:adLabel];
}

- (void)clickSync:(UISwitch *)sender {
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    [def setBool:sender.on forKey:@"sync"];
    [def synchronize];
    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATIONSYNC object:nil userInfo:@{@"sync":@(sender.on)}];
}

#pragma mark - uitextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [self.mtuTextField resignFirstResponder];
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    NSInteger value = [textField.text integerValue];
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    [def setInteger:value forKey:@"mtu"];
    [def synchronize];
    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATIONCHANGEMTU object:nil userInfo:@{@"mtu":@(value)}];
}

#pragma mark - notification
- (void)notificationChangeService:(NSNotification *)noti {
    self.priority = NO;
    self.serviceUUID = noti.userInfo[@"serviceUUID"];
}
- (void)writeWithoutResponse:(NSNotification *)noti {
    isFirst = NO;
}
- (void)writeWithResponse:(NSNotification *)noti {
    isFirst = NO;
}

-(void)clickStateSegment{
    [self reloadData];
}

-(void)reloadData{
    //刷新列表前要清空数组
    [self.chaReArray removeAllObjects];
    [self.chaReadValueArray removeAllObjects];
    [self.tableView reloadData];
}

//排序
-(void)sortService{
    if (self.services) {
        ServiceInfo *info;
        for (int i=0; i<self.services.count; i++) {
            info = self.services[i];
            if ([info.service.UUID.UUIDString isEqualToString:INFODEVICE]) {
                [self.services removeObject:info];
                [self.services addObject:info];
                break;
            }
        }
    }
}
-(void)sortInfoCharacteristic{
    self.sortIndex = 0;
    [self replaceSortByString:@"2A24"];//型号
    [self replaceSortByString:@"2A29"];//制造商
    [self replaceSortByString:@"2A25"];//地址码
    [self replaceSortByString:@"2A27"];//硬件版本
    [self replaceSortByString:@"2A28"];//软件版本
}
-(void)replaceSortByString:(NSString*)string{
    CBCharacteristic *characteristic;
    for (NSInteger i=self.sortIndex; i<self.infoCharacteristics.count; i++) {
        characteristic = self.infoCharacteristics[i];
        if ([characteristic.UUID.UUIDString isEqualToString:string]) {//型号
            [self.infoCharacteristics removeObject:characteristic];
            [self.infoCharacteristics insertObject:characteristic atIndex:self.sortIndex];
            self.sortIndex++;
            break;
        }
    }
}

// 16进制字符串转nadata
- (NSData *)convertHexStrToData:(NSString *)str {
    if (!str || [str length] == 0) {
        return nil;
    }
    NSMutableData *hexData = [[NSMutableData alloc] initWithCapacity:8];
    NSRange range;
    if ([str length] % 2 == 0) {
        range = NSMakeRange(0, 2);
    } else {
        range = NSMakeRange(0, 1);
    }
    for (NSInteger i = range.location; i < [str length]; i += 2) {
        unsigned int anInt;
        NSString *hexCharStr = [str substringWithRange:range];
        NSScanner *scanner = [[NSScanner alloc] initWithString:hexCharStr];
        
        [scanner scanHexInt:&anInt];
        NSData *entity = [[NSData alloc] initWithBytes:&anInt length:1];
        [hexData appendData:entity];
        
        range.location += range.length;
        range.length = 2;
    }
    return hexData;
}

- (void)dealloc {
//    NSLog(@"注销通知");
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

@end


