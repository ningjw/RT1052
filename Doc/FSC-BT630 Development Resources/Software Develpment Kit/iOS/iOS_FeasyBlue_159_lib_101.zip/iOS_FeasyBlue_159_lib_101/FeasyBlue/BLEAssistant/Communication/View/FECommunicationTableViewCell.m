//
//  FECommunicationTableViewCell.m
//  FeasycomLE
//
//  Created by 余明悦 on 16/7/20.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import "FECommunicationTableViewCell.h"


@interface FECommunicationTableViewCell()
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (unsafe_unretained, nonatomic) IBOutlet UILabel *RSSILabel;
@property (weak, nonatomic) IBOutlet UIProgressView *RSSIProgerssView;
@property (weak, nonatomic) IBOutlet UIProgressView *progressView;
@property (weak, nonatomic) IBOutlet UILabel *progressLabel;

@end
@implementation FECommunicationTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)reflashName:(NSString *)name{
    if (name) {
        self.nameLabel.text = name;
    }else{
        self.nameLabel.text = FELocalizedString(@"unname");
    }
}

- (void)reflashRSSI:(NSInteger)RSSI {
    self.RSSILabel.text = [NSString stringWithFormat:@"%ld", RSSI];
    [self.RSSIProgerssView setProgress:(100+RSSI) / 100.0 animated:YES];
}


-(void)showProgress{
    self.progressView.hidden = NO;
    self.progressLabel.hidden = NO;
}
-(void)hideProgress{
    self.progressView.hidden = YES;
    self.progressLabel.hidden = YES;
}
-(void)progressPersend:(CGFloat)persend{
    self.progressLabel.text = [NSString stringWithFormat:@"%.2f %%", persend];
    self.progressView.progress = persend * 0.01;
}


@end
