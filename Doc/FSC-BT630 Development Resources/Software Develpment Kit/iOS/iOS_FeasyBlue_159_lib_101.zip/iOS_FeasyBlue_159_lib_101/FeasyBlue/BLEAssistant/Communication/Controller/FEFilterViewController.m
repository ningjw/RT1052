//
//  FEFilterViewController.m
//  BLEAssistant
//
//  Created by ericj on 2018/6/5.
//  Copyright © 2018年 feasycom. All rights reserved.
//

#import "FEFilterViewController.h"
#import "FEFilterRSSITableViewCell.h"
#import "FEMinimumRSSITableViewCell.h"

static NSString *cellID = @"cellID";

@interface FEFilterViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) FEMinimumRSSITableViewCell *cell;
@property (nonatomic, assign) float RSSI;
@property (nonatomic, assign) BOOL enable;
@property (nonatomic, strong) UISwitch *enableSwitch;
@property (nonatomic, strong) UISlider *rssiSlider;

@end

@implementation FEFilterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor clearColor];
    self.navigationItem.title = FELocalizedString(@"filter");
    
    NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
    BOOL en;
    float f;
    if (self.typeRssi == COMMUNICATION) {
        en = [user boolForKey:@"enable"];
        f = [user floatForKey:@"minimumRSSI"];
    } else if (self.typeRssi == PARAMETER) {
        en = [user boolForKey:@"enable_parameter"];
        f = [user floatForKey:@"minimumRSSI_parameter"];
    } else {
        en = [user boolForKey:@"enable_update"];
        f = [user floatForKey:@"minimumRSSI_update"];
    }
    self.enable = en;
    self.RSSI = f;
    
    [self setupUI];
}

- (void)setupUI {
    self.tableView = [[UITableView alloc] initWithFrame:self.view.frame style:UITableViewStylePlain];
    [self.view addSubview:self.tableView];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:cellID];
    self.tableView.backgroundColor = [UIColor colorWithRed:239/255.0 green:239/255.0 blue:244/255.0 alpha:1];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    //表头
    UIView *headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 60)];
    headView.backgroundColor = [UIColor colorWithRed:239/255.0 green:239/255.0 blue:244/255.0 alpha:1];
//    UILabel *propertiesLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 30, self.view.frame.size.width, 30)];
//    propertiesLabel.text = @"PERIPHERALS";
//    propertiesLabel.font = [UIFont systemFontOfSize:12];
//    [headView addSubview:propertiesLabel];
    self.tableView.tableHeaderView = headView;
    //表尾
    UIView *footView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 50)];
    self.tableView.tableFooterView = footView;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0) {
        FEFilterRSSITableViewCell *filterCell = [[[NSBundle mainBundle] loadNibNamed:@"FEFilterRSSITableViewCell" owner:self options:nil] firstObject];
        [filterCell.filterEnableSwitch addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
        filterCell.filterEnableSwitch.on = self.enable;
        self.enableSwitch = filterCell.filterEnableSwitch;
        return filterCell;
    } else {
        FEMinimumRSSITableViewCell *minimumCell = [[[NSBundle mainBundle] loadNibNamed:@"FEMinimumRSSITableViewCell" owner:self options:nil] firstObject];
        [minimumCell.minimumRSSISlider addTarget:self action:@selector(settingRSSI:) forControlEvents:UIControlEventValueChanged];
        minimumCell.minimumRSSILabel.text = [NSString stringWithFormat:@"%.f dB",self.RSSI];
        self.rssiSlider = minimumCell.minimumRSSISlider;
        self.cell = minimumCell;
        return minimumCell;
    }
}

- (void)click:(UISwitch *)sender {
    self.enable = sender.on;
    NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
    if (self.typeRssi == COMMUNICATION) {
        [user setBool:sender.on forKey:@"enable"];
    } else if (self.typeRssi == PARAMETER) {
        [user setBool:sender.on forKey:@"enable_parameter"];
    } else if (self.typeRssi == UPDATE) {
        [user setBool:sender.on forKey:@"enable_update"];
    }
    [user synchronize];
}

- (void)settingRSSI:(UISlider *)slider {
    self.RSSI = slider.value;
    self.cell.minimumRSSILabel.text = [NSString stringWithFormat:@"%.f dB",slider.value];
    NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
    if (self.typeRssi == COMMUNICATION) {
        [user setFloat:slider.value forKey:@"minimumRSSI"];
    } else if (self.typeRssi == PARAMETER) {
        [user setFloat:slider.value forKey:@"minimumRSSI_parameter"];
    } else if (self.typeRssi == UPDATE) {
        [user setFloat:slider.value forKey:@"minimumRSSI_update"];
    }
    [user synchronize];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 1) {
        return 88.0;
    } else {
        return 44.0;
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    if (self.enable) {
        self.minimumRSSIBlock(self.RSSI);
    } else {
        self.minimumRSSIBlock(0);
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
