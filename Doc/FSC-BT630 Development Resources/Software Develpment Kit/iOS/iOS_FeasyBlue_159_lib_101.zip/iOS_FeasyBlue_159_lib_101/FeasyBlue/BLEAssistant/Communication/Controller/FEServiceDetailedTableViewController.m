//
//  FEServiceDetailedTableViewController.m
//  BLEAssistant
//
//  Created by ericj on 2018/1/8.
//  Copyright © 2018年 feasycom. All rights reserved.
//

#define cellID @"cellID"

#import "FEServiceDetailedTableViewController.h"
#import "MemoryInfo.h"

//BOOL write_select = YES;

@interface FEServiceDetailedTableViewController ()

@property (nonatomic, strong) CBCharacteristic *characteristic;
@property (nonatomic, strong) NSMutableArray *characteristicsArrM;
@property (nonatomic, copy) NSString *serviceUUIDString;
@property (nonatomic, assign) BOOL notify;
@property (nonatomic, assign) BOOL response;
@property (nonatomic, assign) BOOL listen;
//@property (nonatomic, assign) BOOL write;
@property (nonatomic, assign) BOOL writeDefault;
@property (nonatomic, strong) CBCharacteristic *characteristic_read;
@property (nonatomic, weak) UILabel *characteristicValueLabel;
@property (nonatomic, strong) NSMutableArray *notifyArrayM;
@property (nonatomic, strong) MemoryInfo *info;

@end

@implementation FEServiceDetailedTableViewController
- (id)initWithServiceUUID:(NSString *)serviceUUID withCharacteristic:(CBCharacteristic *)characteristic {
    if (self = [super init]) {
        self.serviceUUIDString = serviceUUID;
        self.characteristic = characteristic;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.writeDefault = NO;
    self.characteristicsArrM = [NSMutableArray array];
    self.notifyArrayM = [NSMutableArray array];
    self.info = [MemoryInfo shareMemoryInfo];
    
    [self setCharacteristic];
    //设置界面
    [self setupUI];
    //注册通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getCharacteristicValue:) name:NOTIFITATIONREADCHARACTERISTICVALUE object:nil];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}

- (void)setCharacteristic {
    if (self.characteristic.properties & CBCharacteristicPropertyNotify){
        [self.characteristicsArrM addObject:@"Notify"];
    }
    if (self.characteristic.properties & CBCharacteristicPropertyIndicate) {
        [self.characteristicsArrM addObject:@"Indicate"];
    }
    if (self.characteristic.properties & CBCharacteristicPropertyWrite){
        [self.characteristicsArrM addObject:@"Write"];
    }
    if (self.characteristic.properties & CBCharacteristicPropertyWriteWithoutResponse){
        [self.characteristicsArrM addObject:@"Write Without Response"];
    }
    if (self.characteristic.properties & CBCharacteristicPropertyRead){
        [self.characteristicsArrM addObject:@"Read"];
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.characteristicsArrM.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID forIndexPath:indexPath];
    cell.textLabel.text = self.characteristicsArrM[indexPath.row];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    if ([self.characteristicsArrM[indexPath.row] isEqualToString:@"Notify"]) {
        if ([self.info.notifyArrM containsObject:self.characteristic.UUID.UUIDString] || (self.priority && [self.characteristic.service.UUID.UUIDString isEqualToString:@"FFF0"])) {
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
        }
    } else if ([self.characteristicsArrM[indexPath.row] isEqualToString:@"Indicate"]) {
        if ([self.info.indicateArrM containsObject:self.characteristic.UUID.UUIDString]) {
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
        }
    } else if ([self.characteristicsArrM[indexPath.row] isEqualToString:@"Write"]) {
        if ([self.info.writeCharacteristicUUID isEqualToString:self.characteristic.UUID.UUIDString] && self.info.writeResponse && !self.priority) {
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
        }
    } else if ([self.characteristicsArrM[indexPath.row] isEqualToString:@"Write Without Response"]) {
        if (([self.info.writeCharacteristicUUID isEqualToString:self.characteristic.UUID.UUIDString] && !self.info.writeResponse) || (self.priority && [self.characteristic.service.UUID.UUIDString isEqualToString:@"FFF0"]) || [self.characteristic_UUID_new isEqualToString:self.characteristic.UUID.UUIDString]) {
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
        }
        if (!self.priority && [self.characteristic.service isEqual:[self.services.firstObject service]] && self.info.write_select) {
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
        }
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    //只要点击了就发送切换服务通知并把点击的特征UUID传出去
    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATIONCHANGECHARACTERISTICS object:nil userInfo:@{@"characteristic":self.characteristic.UUID.UUIDString}];
    //告诉外部特征被点击并把服务UUID传出去
    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATIONCHANGESERVICE object:nil userInfo:@{@"serviceUUID":self.serviceUUIDString}];
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    if ([self.characteristicsArrM[indexPath.row] isEqualToString:@"Notify"]) {
//        NSLog(@"点击了notify");
        BOOL notify_new;
        if (cell.accessoryType == UITableViewCellAccessoryCheckmark) {
            notify_new = NO;
            for (int i = 0; i < self.info.notifyArrM.count; i++) {
                if ([self.info.notifyArrM[i] isEqualToString:self.characteristic.UUID.UUIDString]) {
                    [self.info.notifyArrM removeObjectAtIndex:i];
                }
            }
            cell.accessoryType = UITableViewCellAccessoryNone;
        } else {
            notify_new = YES;
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
            [self.info.notifyArrM addObject:self.characteristic.UUID.UUIDString];
            for (int i = 0; i < self.info.indicateArrM.count; i++) {
                if ([self.info.indicateArrM[i] isEqualToString:self.characteristic.UUID.UUIDString]) {
                    [self.info.indicateArrM removeObjectAtIndex:i];
                }
            }
            for (int i = 0; i < self.characteristicsArrM.count; i++) {
                if ([self.characteristicsArrM[i] isEqualToString:@"Indicate"]) {
                    NSIndexPath *indexPath_new = [NSIndexPath indexPathForRow:i inSection:indexPath.section];
                    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath_new];
                    cell.accessoryType = UITableViewCellAccessoryNone;
                }
            }
        }
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATIONNOTIFY object:nil  userInfo:@{@"serviceUUID":self.serviceUUIDString,@"characteristicUUID":self.characteristic.UUID.UUIDString,@"notify":@(notify_new)}];
        
    } else if ([self.characteristicsArrM[indexPath.row] isEqualToString:@"Indicate"]) {
//        NSLog(@"点击了indicate");
        BOOL notify_new;
        if (cell.accessoryType == UITableViewCellAccessoryCheckmark) {
            notify_new = NO;
            for (int i = 0; i < self.info.indicateArrM.count; i++) {
                if ([self.info.indicateArrM[i] isEqualToString:self.characteristic.UUID.UUIDString]) {
                    [self.info.indicateArrM removeObjectAtIndex:i];
                }
            }
            cell.accessoryType = UITableViewCellAccessoryNone;
        } else {
            notify_new = YES;
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
            [self.info.indicateArrM addObject:self.characteristic.UUID.UUIDString];
            for (int i = 0; i < self.info.notifyArrM.count; i++) {
                if ([self.info.notifyArrM[i] isEqualToString:self.characteristic.UUID.UUIDString]) {
                    [self.info.notifyArrM removeObjectAtIndex:i];
                }
            }
            for (int i = 0; i < self.characteristicsArrM.count; i++) {
                if ([self.characteristicsArrM[i] isEqualToString:@"Notify"]) {
                    NSIndexPath *indexPath_new = [NSIndexPath indexPathForRow:i inSection:indexPath.section];
                    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath_new];
                    cell.accessoryType = UITableViewCellAccessoryNone;
                }
            }
        }
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATIONINDICATE object:nil  userInfo:@{@"serviceUUID":self.serviceUUIDString,@"characteristicUUID":self.characteristic.UUID.UUIDString,@"indicate":@(notify_new)}];
        
    } else if ([self.characteristicsArrM[indexPath.row] isEqualToString:@"Write"]) {
//        NSLog(@"点击了write");
        self.info.write_select = NO;
        self.info.writeCharacteristicUUID = self.characteristic.UUID.UUIDString;
        self.info.writeResponse = YES;
        if ([self saveCharacteristicBlock]) {
            self.saveCharacteristicBlock(self.characteristic.UUID.UUIDString);
        }
        BOOL write_with_response;
        if (cell.accessoryType == UITableViewCellAccessoryCheckmark) {
            return;
        } else {
            write_with_response = YES;
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
            for (int i = 0; i < self.characteristicsArrM.count; i++) {
                if ([self.characteristicsArrM[i] isEqualToString:@"Write Without Response"]) {
                    NSIndexPath *indexPath_new = [NSIndexPath indexPathForRow:i inSection:indexPath.section];
                    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath_new];
                    cell.accessoryType = UITableViewCellAccessoryNone;
                }
            }
        }
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATIONWRITE object:nil userInfo:@{@"serviceUUID":self.serviceUUIDString,@"characteristicUUID":self.characteristic.UUID.UUIDString,@"write":@(write_with_response)}];
        
    } else if ([self.characteristicsArrM[indexPath.row] isEqualToString:@"Write Without Response"]) {
//        NSLog(@"点击了write_without_response");
        self.info.write_select = NO;
        self.info.writeCharacteristicUUID = self.characteristic.UUID.UUIDString;
        self.info.writeResponse = NO;
        BOOL write_without_response;
        if (cell.accessoryType == UITableViewCellAccessoryCheckmark) {
            return;
        } else {
            write_without_response = YES;
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
            for (int i = 0; i < self.characteristicsArrM.count; i++) {
                if ([self.characteristicsArrM[i] isEqualToString:@"Write"]) {
                    NSIndexPath *indexPath_new = [NSIndexPath indexPathForRow:i inSection:indexPath.section];
                    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath_new];
                    cell.accessoryType = UITableViewCellAccessoryNone;
                }
            }
        }
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATIONWRITEWITHOUTRESPONSE object:nil userInfo:@{@"serviceUUID":self.serviceUUIDString,@"characteristicUUID":self.characteristic.UUID.UUIDString,@"write_without":@(write_without_response)}];
        
    } else {
//        NSLog(@"点击了read");
        self.characteristicValueLabel.text = [NSString stringWithFormat:@"%@",self.characteristic_read.value];
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATIONREAD object:nil userInfo:@{@"characteristic":self.characteristic}];
    }
}

- (void)getCharacteristicValue:(NSNotification *)noti {
//    NSLog(@"走了通知");
    self.characteristic_read = noti.userInfo[@"characteristicValue"];
}

- (void)setupUI {
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:cellID];
    self.tableView.backgroundColor = [UIColor colorWithRed:239/255.0 green:239/255.0 blue:244/255.0 alpha:1];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    //表头
    UIView *headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 120)];
    headView.backgroundColor = [UIColor colorWithRed:239/255.0 green:239/255.0 blue:244/255.0 alpha:1];
    UILabel *uuidLabel = [[UILabel alloc] initWithFrame:CGRectMake(8, 8, headView.frame.size.width - 16, 50)];
    [uuidLabel setNumberOfLines:0];
    uuidLabel.text = [NSString stringWithFormat:@"UUID:%@",self.characteristic.UUID.UUIDString];
    [headView addSubview:uuidLabel];
    UILabel *propertiesLabel = [[UILabel alloc] initWithFrame:CGRectMake(8, 80, uuidLabel.frame.size.width, 30)];
    propertiesLabel.text = @"PROPERTIES";
    propertiesLabel.font = [UIFont systemFontOfSize:12];
    [headView addSubview:propertiesLabel];
    self.tableView.tableHeaderView = headView;
    //表尾
    UIView *footView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 50)];
    UILabel *dataLabel = [[UILabel alloc] initWithFrame:CGRectMake(8, 8, headView.frame.size.width - 16, 50)];
    dataLabel.text = @"";
    dataLabel.numberOfLines = 0;
    [footView addSubview:dataLabel];
    self.characteristicValueLabel = dataLabel;
    self.tableView.tableFooterView = footView;
}

- (void)dealloc {
//    NSLog(@"注销通知");
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}


@end


