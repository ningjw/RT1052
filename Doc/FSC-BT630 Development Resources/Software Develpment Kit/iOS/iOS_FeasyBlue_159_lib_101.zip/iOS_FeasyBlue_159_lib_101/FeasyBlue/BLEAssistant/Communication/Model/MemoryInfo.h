//
//  MemoryInfo.h
//  BLEAssistant
//
//  Created by ericj on 2018/1/17.
//  Copyright © 2018年 feasycom. All rights reserved.
//

#import <Foundation/Foundation.h>

#define NOTIFICATIONRELODATA     @"notificationRelodata"

@interface MemoryInfo : NSObject

@property (nonatomic, strong) NSMutableArray *notifyArrM;
@property (nonatomic, strong) NSMutableArray *indicateArrM;
@property (nonatomic, copy) NSString *writeCharacteristicUUID;
@property (nonatomic, assign) BOOL writeResponse;
@property (nonatomic, strong) NSArray *characteristicArray;
@property (nonatomic, strong) NSData *sendData;
@property (nonatomic, assign) BOOL write_select;
@property (nonatomic, assign) NSInteger index;
@property (nonatomic, copy) NSString *peripheralString;
@property (nonatomic, strong) NSMutableArray *commandArray_record;
@property (nonatomic, assign) BOOL firstConnect;

+ (instancetype)shareMemoryInfo;

@end


