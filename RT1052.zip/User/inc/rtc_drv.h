#ifndef __RTC_DRV_H
#define __RTC_DRV_H



void RTC_Config(void);

#endif
