#ifndef __PROTOCOL_H
#define __PROTOCOL_H

extern snvs_lp_srtc_datetime_t sampTime;

uint8_t* ParseProtocol(uint8_t *pMsg);

#endif
